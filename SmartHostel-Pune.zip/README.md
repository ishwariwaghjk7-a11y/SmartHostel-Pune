# SmartHostel – Smart Student Accommodation Finder
> **Tagline:** Find. Compare. Connect. Live Better.  
> **Final Year BSc Computer Science Project**  
> **Geographic Focus:** Deccan Gymkhana, F.C. Road, Shivajinagar & Pune Hubs (Centred on Fergusson College, Pune)

---

## 📖 Executive Summary
SmartHostel is a full-stack web application developed to modernize the off-campus student housing search in Pune. It replaces unverified broker listings with a direct student-to-owner connection, live MongoDB geospatial distance calculations (`$geoNear`), and an explainable 5-factor accommodation recommendation engine.

---

## 🛠️ Technology Stack
- **Frontend (`client/`):** React 18, Vite, Tailwind CSS, React Router v6, Axios, Lucide Icons, Recharts, Leaflet & OpenStreetMap (with seamless Google Maps fallback).
- **Backend (`server/`):** Node.js, Express.js, MongoDB (Mongoose) with GeoJSON `2dsphere` spatial indexes.
- **Authentication & Security:** JSON Web Tokens (JWT) stored in HTTP-only cookies, bcrypt password hashing, Helmet security headers, CORS with credentials, express-rate-limit, and mongo-sanitize against NoSQL injection.
- **Data Flow:** Strictly database-driven: `MongoDB -> Express -> Axios -> React`. No hardcoded mock arrays.

---

## 🚀 Quick Start (Two Commands)

### 1. Backend Setup
```bash
cd server
npm install
npm run seed     # Seeds Fergusson College, Demo Hostels, Rooms, Reviews & Accounts
npm run dev      # Runs Express API on http://localhost:5000
```

### 2. Frontend Setup (in a new terminal)
```bash
cd client
npm install
npm run dev      # Runs Vite React App on http://localhost:5173
```

Visit **http://localhost:5173** in your web browser.

---

## 🔑 Demo Login Credentials
For convenience during project viva and evaluation, the login page features **1-Click Demo Sign In** buttons, or you can log in manually:

| Role | Email | Password | Primary Capabilities |
|---|---|---|---|
| **👑 Admin** | `admin@smarthostel.com` | `Admin@123` | Moderate/approve/reject hostels, view platform analytics, inspect user directory |
| **🏠 Owner 1** | `owner1@smarthostel.com` | `Owner@123` | Manage Deccan & FC Road hostels, update room vacancies, respond to enquiries |
| **🏠 Owner 2** | `owner2@smarthostel.com` | `Owner@123` | Manage Law College & SB Road hostels, submit new hostels |
| **🎓 Student 1** | `student1@smarthostel.com` | `Student@123` | Search, bookmark favorites, submit room enquiries, submit reviews |
| **🎓 Student 2** | `student2@smarthostel.com` | `Student@123` | Search, compare accommodations, track booking status |

---

## ⚙️ Environment Variables

### `server/.env`
```env
PORT=5000
NODE_ENV=development
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.example.mongodb.net/smarthostel?retryWrites=true&w=majority
JWT_SECRET=smarthostel_super_secure_jwt_secret_key_2026_pune
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

### `client/.env`
```env
VITE_API_URL=http://localhost:5000/api
# Leave empty to automatically use Leaflet + OpenStreetMap (No API key needed!)
# Or enter Google Maps API key to activate Google Maps JavaScript API
VITE_GOOGLE_MAPS_API_KEY=
```

---

## 📐 Geospatial Indexing & Distance Query (`$geoNear`)
Fergusson College is indexed at `coordinates: [73.8415, 18.5236]` (GeoJSON `[lng, lat]`). Hostels store coordinates with a Mongoose `2dsphere` index.

The live nearby search query executes native spherical geometry calculation:
```javascript
const pipeline = [
  {
    $geoNear: {
      near: { type: 'Point', coordinates: [longitude, latitude] },
      distanceField: 'distanceMeters',
      maxDistance: radiusKm * 1000,
      query: { verificationStatus: 'approved' },
      spherical: true,
    },
  },
  {
    $addFields: {
      distanceKm: { $round: [{ $divide: ['$distanceMeters', 1000] }, 1] },
    },
  },
];
```
Distance is computed directly by the database engine, never hardcoded.

---

## 🧠 Recommendation Engine Formula (Viva Explanation)
Implemented in `server/services/recommendationService.js`:

$$\text{matchScore} = (\text{budget} \times 0.30) + (\text{distance} \times 0.25) + (\text{amenities} \times 0.20) + (\text{rating} \times 0.15) + (\text{roomPreference} \times 0.10)$$

- **Budget (30%):** 100 points if rent $\le$ student budget, decaying gracefully up to 25% over budget.
- **Distance (25%):** 100 points if within 1.0 km of Fergusson College, scaling across radius.
- **Amenities (20%):** Proportion of student's preferred amenities available.
- **Rating (15%):** Normalized 5-star rating $(\text{rating} / 5) \times 100$.
- **Room Preference (10%):** 100 points if preferred sharing type has vacant beds.

The API returns both the numerical `matchScore` and human-readable explanation bullets (e.g. *"Only 0.4 km from Fergusson College"*, *"Within your budget of ₹8,000"*).

---

## 🎙️ 5-Minute Viva Demo Script

1. **Introduction (30s):**
   - *"SmartHostel solves student accommodation uncertainty in Pune around Fergusson College by replacing unverified listings with geospatial proximity search, objective comparison, and multi-role verification."*

2. **Landing Page & Geospatial Search (60s):**
   - Open home page `http://localhost:5173`.
   - Highlight Fergusson College default coordinates and budget filter.
   - Demonstrate **"Find Hostels Near Me"** geolocation button and radius selector (3 km).

3. **3-Column Search Page & Interactive Map (60s):**
   - Show the 3 columns: Filters, Results feed, and Leaflet Map.
   - Click a map pin: observe card scroll and highlight.
   - Adjust budget slider: observe real-time database query filtering.
   - Sort by **Smart Match Score** to explain the recommendation algorithm.

4. **Objective Comparison Tool (45s):**
   - Select 2 or 3 hostels using the compare checkbox.
   - Navigate to `/compare`: show neutral side-by-side comparison of rent, deposit, room types, and amenities with no biased winner label.

5. **Student Journey & Enquiry (45s):**
   - Click **1-Click Demo Login -> Student**.
   - Open *Deccan Student Homes*, view room vacancy breakdown and student reviews.
   - Submit an Enquiry for a double sharing room.
   - Navigate to `/enquiries` to show live status badge.

6. **Owner & Admin Verification Flow (60s):**
   - Log out, click **Quick Sign In -> Admin**.
   - Show Recharts analytics (area distribution, gender distribution, rent ranges).
   - In the pending queue, find *Prabhat Sanskriti Girls PG*.
   - Click **Approve**: show status updating to verified and confirm the hostel immediately appears on the live search map near Fergusson College!
