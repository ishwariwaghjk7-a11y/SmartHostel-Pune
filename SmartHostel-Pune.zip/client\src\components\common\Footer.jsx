import React from 'react';
import { Building2, Heart, ShieldCheck, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800 text-sm">
          {/* Brand Column */}
          <div className="md:col-span-1 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-white font-bold">
                <Building2 className="w-4 h-4" />
              </div>
              <span className="text-lg font-extrabold text-white tracking-tight">
                Smart<span className="text-brand-400">Hostel</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Find. Compare. Connect. Live Better.
              Smart student accommodation finder specifically tailored for Pune colleges.
            </p>
            <div className="flex items-center gap-2 text-xs text-brand-400 pt-1">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span>Centred around Fergusson College, Pune</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100 mb-3">
              Explore
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/search" className="hover:text-white transition">
                  Search Hostels & PGs
                </Link>
              </li>
              <li>
                <Link to="/compare" className="hover:text-white transition">
                  Hostel Comparison Tool
                </Link>
              </li>
              <li>
                <Link to="/search?radius=3" className="hover:text-white transition">
                  Near Fergusson College (3 km)
                </Link>
              </li>
            </ul>
          </div>

          {/* Pune Student Hubs */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100 mb-3">
              Popular Areas
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link to="/search?area=Deccan+Gymkhana" className="hover:text-white transition">
                  Deccan Gymkhana
                </Link>
              </li>
              <li>
                <Link to="/search?area=F.C.+Road" className="hover:text-white transition">
                  Fergusson College (F.C.) Road
                </Link>
              </li>
              <li>
                <Link to="/search?area=Shivajinagar" className="hover:text-white transition">
                  Shivajinagar
                </Link>
              </li>
              <li>
                <Link to="/search?area=Law+College+Road" className="hover:text-white transition">
                  Law College Road
                </Link>
              </li>
            </ul>
          </div>

          {/* Academic Project Info */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-100 mb-3">
              Project Info
            </h4>
            <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/50 space-y-1.5 text-xs text-slate-400">
              <div className="text-slate-200 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                BSc Computer Science Final Year
              </div>
              <p className="text-[11px] leading-relaxed">
                Full-stack MERN with Geospatial MongoDB Indexing & Multi-factor Recommendation Engine.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} SmartHostel Pune. Student Accommodation Network.</p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                if (window.confirm('Reset database back to default Fergusson College seed state?')) {
                  localStorage.clear();
                  window.location.reload();
                }
              }}
              className="text-slate-400 hover:text-brand-300 transition underline"
            >
              Reset Database Cache
            </button>
            <span className="text-slate-600">•</span>
            <p className="flex items-center gap-1">
              Built for Pune students with <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
