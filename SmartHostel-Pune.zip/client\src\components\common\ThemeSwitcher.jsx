import React, { useState, useRef, useEffect } from 'react';
import { Palette, Check } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const ThemeSwitcher = ({ compact = false }) => {
  const { theme, setTheme, themes, currentThemeMeta } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center gap-2 px-2.5 py-1.5 rounded-full border border-brand-200/80 bg-white/80 hover:bg-white text-slate-700 shadow-xs hover:shadow-sm transition-all duration-150 ${
          compact ? 'text-xs' : 'text-xs sm:text-sm'
        }`}
        title={`Current theme: ${currentThemeMeta.name}`}
      >
        <span
          className="w-3.5 h-3.5 rounded-full shadow-inner ring-2 ring-white flex-shrink-0"
          style={{ backgroundColor: currentThemeMeta.accent }}
        />
        {!compact && (
          <span className="hidden sm:inline font-medium text-slate-700 text-xs">
            {currentThemeMeta.name}
          </span>
        )}
        <Palette className="w-3.5 h-3.5 text-slate-400" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white shadow-xl border border-slate-100 py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
          <div className="px-3 py-1.5 border-b border-slate-100 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Pastel Color Themes
          </div>
          <div className="p-1 space-y-0.5">
            {themes.map((t) => {
              const isActive = theme === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => {
                    setTheme(t.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-brand-50 text-brand-900 font-semibold shadow-xs'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-4 h-4 rounded-full shadow-inner ring-2 ring-white flex-shrink-0"
                      style={{ backgroundColor: t.accent }}
                    />
                    <div className="text-left">
                      <div className="font-semibold">{t.name}</div>
                      <div className="text-[10px] text-slate-400">{t.description}</div>
                    </div>
                  </div>
                  {isActive && <Check className="w-3.5 h-3.5 text-brand-600 flex-shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default ThemeSwitcher;
