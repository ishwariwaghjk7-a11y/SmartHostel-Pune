import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
} from 'recharts';

const COLORS = ['#8b5cf6', '#10b981', '#f59e0b', '#f43f5e', '#6366f1', '#06b6d4'];

const TOOLTIP_STYLE = {
  backgroundColor: 'rgba(255, 255, 255, 0.95)',
  color: '#0f172a',
  borderRadius: '14px',
  border: '1px solid rgba(226, 232, 240, 0.9)',
  boxShadow: '0 10px 25px -5px rgba(124, 58, 237, 0.1), 0 8px 10px -6px rgba(124, 58, 237, 0.05)',
  fontSize: '12px',
  fontWeight: '600',
  padding: '8px 12px',
};

export const AreaBarChart = ({ data = [] }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        No geographic data available
      </div>
    );
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis
            dataKey="area"
            tick={{ fontSize: 11, fill: '#64748b' }}
            interval={0}
            angle={-25}
            textAnchor="end"
          />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
          <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: 'rgba(124, 58, 237, 0.04)' }} />
          <Bar dataKey="count" fill="#8b5cf6" radius={[8, 8, 0, 0]} name="Hostels" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export const GenderPieChart = ({ data = [] }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        No demographic data available
      </div>
    );
  }

  const formattedData = data.map((d) => ({
    name: d.gender === 'female' ? 'Girls Only' : d.gender === 'male' ? 'Boys Only' : d.gender === 'coed' ? 'Co-ed' : d.gender,
    value: d.count,
  }));

  return (
    <div className="h-64 w-full flex flex-col items-center">
      <ResponsiveContainer width="100%" height="80%">
        <PieChart>
          <Pie
            data={formattedData}
            cx="50%"
            cy="50%"
            innerRadius={45}
            outerRadius={75}
            paddingAngle={5}
            dataKey="value"
          >
            {formattedData.map((_, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip contentStyle={TOOLTIP_STYLE} />
        </PieChart>
      </ResponsiveContainer>
      <div className="flex flex-wrap justify-center gap-4 text-xs pt-1">
        {formattedData.map((item, index) => (
          <div key={item.name} className="flex items-center gap-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: COLORS[index % COLORS.length] }}
            />
            <span className="text-slate-600 font-semibold">{item.name} ({item.value})</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const RentRangesChart = ({ data = [] }) => {
  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        No rent data available
      </div>
    );
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
          <XAxis
            dataKey="range"
            tick={{ fontSize: 11, fill: '#64748b' }}
            interval={0}
            angle={-15}
            textAnchor="end"
          />
          <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
          <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: 'rgba(16, 185, 129, 0.04)' }} />
          <Bar dataKey="count" fill="#10b981" radius={[8, 8, 0, 0]} name="Hostels" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
