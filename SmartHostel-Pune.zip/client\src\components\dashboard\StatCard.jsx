import React from 'react';

const StatCard = ({ title, value, subtitle, icon: Icon, color = 'brand' }) => {
  const colorMap = {
    brand: 'bg-brand-50 text-brand-700 border-brand-200/80',
    emerald: 'bg-mint-50 text-mint-700 border-mint-200/80',
    amber: 'bg-honey-50 text-honey-800 border-honey-200/80',
    rose: 'bg-blush-50 text-blush-700 border-blush-200/80',
    indigo: 'bg-brand-50/70 text-indigo-700 border-indigo-200/80',
    purple: 'bg-purple-50 text-purple-700 border-purple-200/80',
  };

  return (
    <div className="glass-card rounded-2xl border border-brand-100/70 p-5 shadow-soft hover:shadow-soft-hover transition-all">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            {title}
          </p>
          <h3 className="text-2xl font-black text-slate-900 tracking-tight">
            {value}
          </h3>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-1 font-medium">{subtitle}</p>
          )}
        </div>

        {Icon && (
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center border shadow-2xs ${
              colorMap[color] || colorMap.brand
            }`}
          >
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>
    </div>
  );
};

export default StatCard;
