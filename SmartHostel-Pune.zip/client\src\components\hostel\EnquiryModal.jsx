import React, { useState } from 'react';
import { X, Send, Calendar, Phone, MessageSquare, Building2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const EnquiryModal = ({ hostel, isOpen, onClose, onSuccess }) => {
  const { user, isAuthenticated } = useAuth();
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    roomType: 'double',
    moveInDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    durationMonths: 6,
    phone: user?.phone || '',
    message: 'Hello, I am interested in this hostel accommodation and would like to schedule a visit.',
  });

  const [submitting, setSubmitting] = useState(false);

  if (!isOpen || !hostel) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!isAuthenticated) {
      showToast('Please sign in as a student to send an enquiry', 'warning');
      return;
    }

    if (user?.role !== 'student') {
      showToast('Only student accounts can enquire about hostel rooms', 'info');
      return;
    }

    if (!formData.phone) {
      showToast('Please provide your contact phone number', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.post('/enquiries', {
        hostelId: hostel._id,
        ...formData,
      });

      if (res.data?.success) {
        showToast(res.data.message || 'Enquiry submitted successfully!', 'success');
        if (onSuccess) onSuccess(res.data.enquiry);
        onClose();
      }
    } catch (err) {
      showToast(err.message || 'Failed to submit enquiry', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 relative animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-100">
          <div className="w-10 h-10 rounded-xl bg-brand-50 text-brand-600 flex items-center justify-center">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">Enquire with Owner</h3>
            <p className="text-xs text-slate-500 line-clamp-1">{hostel.name} • {hostel.area}</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Room Type */}
          <div>
            <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider">
              Preferred Room Type
            </label>
            <select
              value={formData.roomType}
              onChange={(e) => setFormData({ ...formData, roomType: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="single">Single Private Room</option>
              <option value="double">Double Sharing (2 Beds)</option>
              <option value="triple">Triple Sharing (3 Beds)</option>
              <option value="four">Four Sharing (4 Beds)</option>
            </select>
          </div>

          {/* Move-in Date & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider flex items-center gap-1">
                <Calendar className="w-3 h-3 text-brand-600" />
                Target Move-In Date
              </label>
              <input
                type="date"
                required
                value={formData.moveInDate}
                onChange={(e) => setFormData({ ...formData, moveInDate: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider">
                Stay Duration (Months)
              </label>
              <select
                value={formData.durationMonths}
                onChange={(e) => setFormData({ ...formData, durationMonths: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value={3}>3 Months (Short Term)</option>
                <option value={6}>6 Months (Semester)</option>
                <option value={10}>10 Months (Academic Year)</option>
                <option value={12}>12 Months (Full Year)</option>
              </select>
            </div>
          </div>

          {/* Contact Phone */}
          <div>
            <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider flex items-center gap-1">
              <Phone className="w-3 h-3 text-brand-600" />
              Your Contact Phone Number
            </label>
            <input
              type="tel"
              required
              placeholder="+91 98765 43210"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>

          {/* Message */}
          <div>
            <label className="block font-bold text-slate-700 mb-1 uppercase tracking-wider flex items-center gap-1">
              <MessageSquare className="w-3 h-3 text-brand-600" />
              Message to Owner
            </label>
            <textarea
              rows={3}
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Mention your college, course, visit timing preference..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-3 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 transition"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={submitting}
              className="flex items-center gap-1.5 bg-gradient-to-r from-brand-600 to-indigo-700 hover:from-brand-700 hover:to-indigo-800 text-white font-bold px-5 py-2.5 rounded-xl shadow-md transition disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              {submitting ? 'Submitting...' : 'Send Enquiry'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EnquiryModal;
