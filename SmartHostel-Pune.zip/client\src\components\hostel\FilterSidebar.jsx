import React from 'react';
import { RotateCcw, Filter, IndianRupee, MapPin, Users, Home, Star } from 'lucide-react';

const AMENITIES_LIST = [
  'WiFi',
  'Mess / Food',
  'CCTV',
  'Laundry',
  'Power Backup',
  'Gym',
  'Study Room',
  'Hot Water',
  'Biometric Entry',
];

const FilterSidebar = ({
  filters,
  onChange,
  onReset,
  colleges = [],
  totalResults = 0,
}) => {
  const handleAmenityToggle = (amenity) => {
    const current = filters.amenities ? filters.amenities.split(',').filter(Boolean) : [];
    let updated;
    if (current.includes(amenity)) {
      updated = current.filter((a) => a !== amenity);
    } else {
      updated = [...current, amenity];
    }
    onChange({ amenities: updated.join(',') });
  };

  const selectedAmenities = filters.amenities ? filters.amenities.split(',') : [];

  return (
    <div className="bg-white rounded-3xl border border-brand-100/80 p-5 shadow-soft space-y-6 text-sm">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-brand-100/60">
        <div className="flex items-center gap-2 font-bold text-slate-900">
          <div className="w-7 h-7 rounded-xl bg-brand-100 flex items-center justify-center text-brand-600">
            <Filter className="w-3.5 h-3.5" />
          </div>
          <span>Refine Search</span>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-brand-50 text-brand-700">
            {totalResults}
          </span>
        </div>

        <button
          onClick={onReset}
          className="text-xs text-brand-600 hover:text-brand-800 font-semibold flex items-center gap-1 transition"
        >
          <RotateCcw className="w-3 h-3" />
          Reset
        </button>
      </div>

      {/* College Reference Selector */}
      <div>
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-blush-500" />
          Reference Landmark / College
        </label>
        <select
          value={filters.collegeId || ''}
          onChange={(e) => onChange({ collegeId: e.target.value })}
          className="w-full bg-slate-50/80 border border-brand-100 rounded-2xl px-3.5 py-2.5 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-400"
        >
          {colleges.map((c) => (
            <option key={c._id} value={c._id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* Distance Radius */}
      <div>
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
          Distance from Fergusson Gate
        </label>
        <div className="grid grid-cols-4 gap-1.5">
          {[1, 3, 5, 10].map((km) => (
            <button
              key={km}
              type="button"
              onClick={() => onChange({ radius: km })}
              className={`py-2 rounded-xl text-xs font-bold transition text-center ${
                Number(filters.radius) === km
                  ? 'bg-brand-600 text-white shadow-xs'
                  : 'bg-brand-50/60 text-brand-900 hover:bg-brand-100'
              }`}
            >
              {km} km
            </button>
          ))}
        </div>
      </div>

      {/* Monthly Budget Slider */}
      <div>
        <div className="flex justify-between items-center mb-1">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
            <IndianRupee className="w-3 h-3 text-mint-600" />
            Max Monthly Rent
          </label>
          <span className="text-xs font-extrabold text-brand-700 bg-brand-50 px-2.5 py-0.5 rounded-full border border-brand-100">
            ₹{Number(filters.budget || 20000).toLocaleString('en-IN')}/mo
          </span>
        </div>
        <input
          type="range"
          min="4000"
          max="25000"
          step="500"
          value={filters.budget || 20000}
          onChange={(e) => onChange({ budget: e.target.value })}
          className="w-full accent-brand-600 cursor-pointer h-2 bg-brand-100 rounded-lg mt-2"
        />
        <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-medium">
          <span>₹4,000</span>
          <span>₹15,000</span>
          <span>₹25,000+</span>
        </div>
      </div>

      {/* Gender Policy */}
      <div>
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1">
          <Users className="w-3.5 h-3.5 text-brand-600" />
          Living / Gender Policy
        </label>
        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'all', label: 'All Stays (50)' },
            { id: 'male', label: '👨 Boys Hostels (25)' },
            { id: 'female', label: '👩 Girls Hostels (25)' },
            { id: 'coed', label: '👥 Co-ed Stays' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onChange({ gender: item.id })}
              className={`py-2 px-2.5 rounded-xl text-xs font-medium transition text-left border ${
                (filters.gender || 'all') === item.id
                  ? 'bg-brand-50 border-brand-400 text-brand-700 font-bold'
                  : 'bg-white border-slate-200/80 text-slate-600 hover:border-brand-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Room Sharing Type */}
      <div>
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1">
          <Home className="w-3.5 h-3.5 text-brand-600" />
          Sharing Type
        </label>
        <select
          value={filters.roomType || 'all'}
          onChange={(e) => onChange({ roomType: e.target.value })}
          className="w-full bg-slate-50/80 border border-brand-100 rounded-2xl px-3 py-2 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-400"
        >
          <option value="all">Any Room Type</option>
          <option value="single">Single Private Room</option>
          <option value="double">Double Sharing (2 Beds)</option>
          <option value="triple">Triple Sharing (3 Beds)</option>
          <option value="four">Four Sharing (4 Beds)</option>
        </select>
      </div>

      {/* Minimum Rating */}
      <div>
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1">
          <Star className="w-3.5 h-3.5 text-honey-500 fill-honey-500" />
          Minimum Rating
        </label>
        <div className="flex gap-1.5">
          {[
            { label: 'All', val: '' },
            { label: '3.5★+', val: '3.5' },
            { label: '4.0★+', val: '4.0' },
            { label: '4.5★+', val: '4.5' },
          ].map((r) => (
            <button
              key={r.label}
              type="button"
              onClick={() => onChange({ minRating: r.val })}
              className={`flex-1 py-1.5 px-1.5 rounded-xl text-xs font-bold transition text-center border ${
                (filters.minRating || '') === r.val
                  ? 'bg-honey-100 border-honey-400 text-honey-800'
                  : 'bg-white border-slate-200/80 text-slate-600 hover:border-slate-300'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* Amenities Multi-select */}
      <div>
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
          Key Amenities
        </label>
        <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
          {AMENITIES_LIST.map((amenity) => {
            const isChecked = selectedAmenities.includes(amenity);
            return (
              <label
                key={amenity}
                className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer hover:text-brand-700 select-none py-1 px-1.5 rounded-lg hover:bg-brand-50/50"
              >
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleAmenityToggle(amenity)}
                  className="rounded text-brand-600 focus:ring-brand-400 border-slate-300 w-3.5 h-3.5 accent-brand-600"
                />
                <span className="font-medium">{amenity}</span>
              </label>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FilterSidebar;
