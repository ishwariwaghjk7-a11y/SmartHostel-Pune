import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Star,
  MapPin,
  CheckCircle,
  Heart,
  Layers,
  Bed,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import api from '../../services/api';

const HostelCard = ({
  hostel,
  isSelected = false,
  onHover,
  isCompared = false,
  onToggleCompare,
  isFavoriteInitial = false,
}) => {
  const { user, isAuthenticated } = useAuth();
  const { showToast } = useToast();
  const [isFavorite, setIsFavorite] = useState(isFavoriteInitial);
  const [favoriteLoading, setFavoriteLoading] = useState(false);

  // Compute total available beds across all rooms
  const totalAvailableBeds = (hostel.rooms || []).reduce((acc, room) => {
    const avail =
      room.availableBeds !== undefined
        ? room.availableBeds
        : Math.max(0, room.capacity - (room.occupiedBeds || 0));
    return acc + avail;
  }, 0);

  const handleFavoriteClick = async (e) => {
    e.preventDefault();
    e.stopPropagation();

    if (!isAuthenticated) {
      showToast('Please sign in as a student to save favorites', 'warning');
      return;
    }

    if (user?.role !== 'student') {
      showToast('Only students can save hostels to favorites', 'info');
      return;
    }

    setFavoriteLoading(true);
    try {
      const res = await api.post(`/favorites/${hostel._id}`);
      if (res.data?.success) {
        setIsFavorite(res.data.isFavorited);
        showToast(res.data.message, 'success');
      }
    } catch (err) {
      showToast(err.message || 'Failed to update favorites', 'error');
    } finally {
      setFavoriteLoading(false);
    }
  };

  const handleCompareClick = (e) => {
    e.stopPropagation();
    if (onToggleCompare) {
      onToggleCompare(hostel);
    }
  };

  const primaryImage =
    hostel.images && hostel.images.length > 0
      ? hostel.images[0]
      : 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80';

  return (
    <div
      onMouseEnter={() => onHover && onHover(hostel._id)}
      className={`group bg-white rounded-3xl border transition-all duration-300 overflow-hidden flex flex-col ${
        isSelected
          ? 'border-brand-500 ring-2 ring-brand-400/30 shadow-soft-hover'
          : 'border-brand-100/70 hover:border-brand-300 hover:shadow-soft-hover hover:-translate-y-0.5'
      }`}
    >
      {/* Image & Badges Header */}
      <div className="relative h-48 sm:h-52 w-full overflow-hidden bg-slate-100">
        <img
          src={primaryImage}
          alt={hostel.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Soft Contrast Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 via-black/20 to-black/30" />

        {/* Top Badges (Pastel Mint & Lavender) */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 items-center">
          {hostel.verificationStatus === 'approved' && (
            <span className="inline-flex items-center gap-1 bg-mint-50/95 text-mint-800 text-[11px] font-bold px-2.5 py-1 rounded-full backdrop-blur border border-mint-200/80 shadow-xs">
              <CheckCircle className="w-3.5 h-3.5 text-mint-600" />
              Verified Listing
            </span>
          )}

          {hostel.gender === 'male' && (
            <span className="inline-flex items-center gap-1 bg-sky-50/95 text-sky-800 text-[11px] font-bold px-2.5 py-1 rounded-full backdrop-blur border border-sky-200/80 shadow-xs">
              👨 Boys Hostel
            </span>
          )}
          {hostel.gender === 'female' && (
            <span className="inline-flex items-center gap-1 bg-rose-50/95 text-rose-800 text-[11px] font-bold px-2.5 py-1 rounded-full backdrop-blur border border-rose-200/80 shadow-xs">
              👩 Girls Hostel
            </span>
          )}
          {hostel.gender === 'coed' && (
            <span className="inline-flex items-center gap-1 bg-brand-50/95 text-brand-800 text-[11px] font-bold px-2.5 py-1 rounded-full backdrop-blur border border-brand-200/80 shadow-xs">
              👥 Co-ed Stay
            </span>
          )}
        </div>

        {/* Action buttons (Favorite & Compare) */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleFavoriteClick}
            disabled={favoriteLoading}
            className={`p-2.5 rounded-full backdrop-blur transition shadow-sm ${
              isFavorite
                ? 'bg-blush-500 text-white shadow-blush-500/30'
                : 'bg-white/95 text-slate-600 hover:text-blush-500 hover:bg-blush-50'
            }`}
            aria-label="Save to favorites"
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Rating and Distance Banner at image bottom */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs font-semibold">
          <div className="flex items-center gap-1 bg-black/45 backdrop-blur px-2.5 py-1 rounded-xl border border-white/10">
            <MapPin className="w-3.5 h-3.5 text-blush-400" />
            <span>{hostel.area}</span>
            {hostel.distanceKm !== undefined && (
              <span className="text-white/80 font-normal">
                • {hostel.distanceKm} km from FC Gate
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 bg-honey-100/95 text-honey-800 px-2.5 py-1 rounded-xl shadow-xs border border-honey-200/80 font-bold">
            <Star className="w-3.5 h-3.5 fill-honey-500 text-honey-500" />
            <span>{hostel.rating > 0 ? hostel.rating.toFixed(1) : 'New'}</span>
            {hostel.reviewCount > 0 && (
              <span className="text-[10px] font-medium text-honey-700">({hostel.reviewCount})</span>
            )}
          </div>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Recommendation Match Score Pill if present */}
          {hostel.matchScore !== undefined && (
            <div className="mb-3 flex items-center justify-between bg-brand-50 border border-brand-200/70 rounded-xl px-3 py-1.5 shadow-xs">
              <span className="text-xs font-bold text-brand-700 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-brand-600" />
                {hostel.matchScore}% Match
              </span>
              <span className="text-[11px] text-brand-600 font-medium truncate max-w-[150px]">
                {hostel.matchReasons?.[0] || 'Top choice'}
              </span>
            </div>
          )}

          {/* Title */}
          <Link to={`/hostels/${hostel._id}`}>
            <h3 className="font-bold text-base text-slate-900 group-hover:text-brand-600 transition-colors line-clamp-1 mb-1">
              {hostel.name}
            </h3>
          </Link>

          <p className="text-xs text-slate-500 line-clamp-2 mb-3.5 leading-relaxed">
            {hostel.description}
          </p>

          {/* Top Amenities Pills */}
          <div className="flex flex-wrap gap-1.5 mb-3.5">
            {(hostel.amenities || []).slice(0, 4).map((amenity, idx) => (
              <span
                key={idx}
                className="text-[11px] font-medium bg-brand-50/70 text-brand-800 px-2.5 py-1 rounded-lg border border-brand-100"
              >
                {amenity}
              </span>
            ))}
            {(hostel.amenities || []).length > 4 && (
              <span className="text-[11px] font-medium text-slate-400 px-1 py-0.5">
                +{hostel.amenities.length - 4} more
              </span>
            )}
          </div>
        </div>

        {/* Footer: Price, Bed Availability, Compare checkbox & View Details */}
        <div className="pt-3.5 border-t border-slate-100 space-y-3">
          <div className="flex items-end justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
                Monthly Rent
              </span>
              <div className="text-base font-extrabold text-brand-700">
                ₹{hostel.rentFrom?.toLocaleString('en-IN')}
                {hostel.rentTo && hostel.rentTo !== hostel.rentFrom && (
                  <span className="text-xs font-normal text-slate-500">
                    {' '}- ₹{hostel.rentTo?.toLocaleString('en-IN')}
                  </span>
                )}
                <span className="text-xs font-normal text-slate-500">/mo</span>
              </div>
            </div>

            <div className="text-right">
              <span
                className={`inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-xl ${
                  totalAvailableBeds > 0
                    ? 'bg-mint-50 text-mint-700 border border-mint-200'
                    : 'bg-blush-50 text-blush-700 border border-blush-200'
                }`}
              >
                <Bed className="w-3.5 h-3.5" />
                {totalAvailableBeds > 0 ? `${totalAvailableBeds} beds open` : 'Waitlist only'}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            {/* Compare Checkbox */}
            <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer select-none hover:text-brand-700">
              <input
                type="checkbox"
                checked={isCompared}
                onChange={handleCompareClick}
                className="w-4 h-4 rounded text-brand-600 focus:ring-brand-400 border-slate-300 accent-brand-600"
              />
              <span className="font-semibold">Compare</span>
            </label>

            {/* View Details Button */}
            <Link
              to={`/hostels/${hostel._id}`}
              className="inline-flex items-center gap-1 text-xs font-bold text-white bg-gradient-to-r from-brand-600 to-brand-500 hover:from-brand-700 hover:to-brand-600 px-4 py-2 rounded-xl transition shadow-xs hover:shadow"
            >
              View Details
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HostelCard;
