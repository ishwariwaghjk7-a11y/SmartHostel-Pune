import React, { useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { MapPin } from 'lucide-react';

const pickerIcon = L.divIcon({
  html: `
    <div style="
      background-color: #4f46e5;
      color: white;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 3px solid white;
      box-shadow: 0 4px 12px rgba(79, 70, 229, 0.5);
    ">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
        <circle cx="12" cy="10" r="3"></circle>
      </svg>
    </div>
  `,
  className: 'location-picker-marker',
  iconSize: [36, 36],
  iconAnchor: [18, 36],
});

function MapClickHandler({ onLocationSelect }) {
  useMapEvents({
    click(e) {
      onLocationSelect(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

const LocationPicker = ({ lat, lng, onChange, height = '280px' }) => {
  const initialPosition = [lat || 18.5236, lng || 73.8415];

  const handleDragEnd = (e) => {
    const marker = e.target;
    const position = marker.getLatLng();
    onChange(position.lat, position.lng);
  };

  const handleMapClick = (clickLat, clickLng) => {
    onChange(clickLat, clickLng);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span className="flex items-center gap-1 font-medium">
          <MapPin className="w-3.5 h-3.5 text-brand-600" />
          Click on map or drag pin to fine-tune location:
        </span>
        <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-700">
          Lat: {Number(lat || 18.5236).toFixed(4)}, Lng: {Number(lng || 73.8415).toFixed(4)}
        </span>
      </div>

      <div style={{ height }} className="rounded-xl overflow-hidden border border-slate-300 relative shadow-inner">
        <MapContainer
          center={initialPosition}
          zoom={15}
          scrollWheelZoom={false}
          className="h-full w-full"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <Marker
            draggable={true}
            eventHandlers={{
              dragend: handleDragEnd,
            }}
            position={[lat || 18.5236, lng || 73.8415]}
            icon={pickerIcon}
          />
          <MapClickHandler onLocationSelect={handleMapClick} />
        </MapContainer>
      </div>
    </div>
  );
};

export default LocationPicker;
