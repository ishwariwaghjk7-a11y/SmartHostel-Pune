import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Star, MapPin, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

// Fix Leaflet's default marker icon paths in Vite bundles
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Create custom branded markers for Hostels
const createHostelIcon = (isSelected, isApproved = true) => {
  const bgColor = isSelected ? '#7c3aed' : isApproved ? '#6366f1' : '#f59e0b';
  const size = isSelected ? 40 : 32;

  const html = `
    <div style="
      background: ${bgColor};
      color: white;
      width: ${size}px;
      height: ${size}px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 3px solid white;
      box-shadow: 0 8px 16px rgba(124, 58, 237, 0.28);
      cursor: pointer;
      transition: all 0.2s ease;
    ">
      <svg width="${isSelected ? '18' : '15'}" height="${isSelected ? '18' : '15'}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
        <polyline points="9 22 9 12 15 12 15 22"></polyline>
      </svg>
    </div>
  `;

  return L.divIcon({
    html,
    className: 'custom-leaflet-marker',
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2],
  });
};

// Create custom landmark marker for Colleges
const createCollegeIcon = () => {
  const html = `
    <div style="
      background-color: #dc2626;
      color: white;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 3px solid white;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    ">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
        <path d="M22 10v6M2 10l10-5 10 5-10 5z"></path>
        <path d="M6 12v5c3 3 9 3 12 0v-5"></path>
      </svg>
    </div>
  `;

  return L.divIcon({
    html,
    className: 'college-leaflet-marker',
    iconSize: [36, 36],
    iconAnchor: [18, 18],
    popupAnchor: [0, -18],
  });
};

// Helper component to smoothly center map when coordinates change
function MapCenterUpdater({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.flyTo(center, zoom || 14, { duration: 1.2 });
    }
  }, [center, zoom, map]);
  return null;
}

const MapView = ({
  hostels = [],
  center = [18.5236, 73.8415], // Default: Fergusson College Pune
  zoom = 14,
  selectedHostelId = null,
  onMarkerClick,
  college = null,
  height = '100%',
}) => {
  const googleApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  const googleMapRef = useRef(null);

  // If Google Maps API Key is configured and valid, use Google Maps API
  if (googleApiKey && googleApiKey.trim() !== '') {
    useEffect(() => {
      const scriptId = 'google-maps-script';
      if (!document.getElementById(scriptId)) {
        const script = document.createElement('script');
        script.id = scriptId;
        script.src = `https://maps.googleapis.com/maps/api/js?key=${googleApiKey}&libraries=places`;
        script.async = true;
        script.onload = initGoogleMap;
        document.body.appendChild(script);
      } else if (window.google) {
        initGoogleMap();
      }

      function initGoogleMap() {
        if (!googleMapRef.current || !window.google) return;

        const map = new window.google.maps.Map(googleMapRef.current, {
          center: { lat: center[0], lng: center[1] },
          zoom: zoom,
          styles: [
            {
              featureType: 'poi',
              elementType: 'labels',
              stylers: [{ visibility: 'off' }],
            },
          ],
        });

        // Add markers for hostels
        hostels.forEach((h) => {
          const lat = h.location?.coordinates?.[1];
          const lng = h.location?.coordinates?.[0];
          if (!lat || !lng) return;

          const marker = new window.google.maps.Marker({
            position: { lat, lng },
            map,
            title: h.name,
          });

          const infoWindow = new window.google.maps.InfoWindow({
            content: `
              <div style="padding: 6px; font-family: sans-serif;">
                <h4 style="font-weight: 700; margin: 0 0 4px 0;">${h.name}</h4>
                <p style="margin: 0; color: #4f46e5; font-weight: 600;">₹${h.rentFrom?.toLocaleString('en-IN')}/mo</p>
                <p style="margin: 2px 0 0 0; font-size: 12px; color: #64748b;">${h.area}</p>
              </div>
            `,
          });

          marker.addListener('click', () => {
            infoWindow.open(map, marker);
            if (onMarkerClick) onMarkerClick(h);
          });
        });
      }
    }, [googleApiKey, center, zoom, hostels, onMarkerClick]);

    return (
      <div
        ref={googleMapRef}
        style={{ height, width: '100%' }}
        className="rounded-xl overflow-hidden shadow-inner border border-slate-200"
      />
    );
  }

  // Fallback: Leaflet + OpenStreetMap (No API key required, reliable, offline-ready)
  const mapCenter = center && center[0] && center[1] ? center : [18.5236, 73.8415];

  return (
    <div style={{ height, width: '100%' }} className="relative rounded-xl overflow-hidden shadow-sm border border-slate-200">
      <MapContainer
        center={mapCenter}
        zoom={zoom}
        scrollWheelZoom={true}
        className="h-full w-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapCenterUpdater center={mapCenter} zoom={zoom} />

        {/* Reference College Marker (e.g. Fergusson College) */}
        {college && college.location?.coordinates && (
          <Marker
            position={[college.location.coordinates[1], college.location.coordinates[0]]}
            icon={createCollegeIcon()}
          >
            <Popup>
              <div className="p-3 text-center min-w-[180px]">
                <span className="inline-block px-2 py-0.5 text-xs font-bold uppercase rounded bg-red-100 text-red-700 mb-1">
                  Reference College
                </span>
                <h4 className="font-bold text-slate-900 text-sm">{college.name}</h4>
                <p className="text-xs text-slate-500 mt-0.5">{college.address}</p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Hostels Markers */}
        {hostels.map((hostel) => {
          const lat = hostel.location?.coordinates?.[1];
          const lng = hostel.location?.coordinates?.[0];
          if (!lat || !lng) return null;

          const isSelected = selectedHostelId === hostel._id;
          const isApproved = hostel.verificationStatus === 'approved';

          return (
            <Marker
              key={hostel._id}
              position={[lat, lng]}
              icon={createHostelIcon(isSelected, isApproved)}
              eventHandlers={{
                click: () => {
                  if (onMarkerClick) onMarkerClick(hostel);
                },
              }}
            >
              <Popup>
                <div className="w-60 p-1">
                  {hostel.images && hostel.images.length > 0 && (
                    <img
                      src={hostel.images[0]}
                      alt={hostel.name}
                      className="w-full h-28 object-cover rounded-xl mb-2 shadow-2xs"
                    />
                  )}
                  <div className="px-1.5 pb-1 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-500">{hostel.area}</span>
                      <span className="flex items-center text-honey-800 bg-honey-50 border border-honey-200 px-2 py-0.5 rounded-full font-bold text-[11px]">
                        <Star className="w-3 h-3 fill-honey-400 text-honey-400 mr-0.5" />
                        {hostel.rating > 0 ? hostel.rating.toFixed(1) : 'New'}
                      </span>
                    </div>

                    <h4 className="font-extrabold text-slate-900 text-sm line-clamp-1">
                      {hostel.name}
                    </h4>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">Starting from</span>
                        <div className="text-sm font-black text-brand-700">
                          ₹{hostel.rentFrom?.toLocaleString('en-IN')}<span className="text-[10px] font-normal text-slate-500">/mo</span>
                        </div>
                      </div>
                      <Link
                        to={`/hostels/${hostel._id}`}
                        className="inline-flex items-center gap-1 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-soft hover:shadow-soft-hover transition"
                      >
                        Details
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </div>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
};

export default MapView;
