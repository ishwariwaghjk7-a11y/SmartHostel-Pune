import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext();

export const THEMES = [
  {
    id: 'lavender',
    name: 'Lavender Mist',
    accent: '#8b5cf6',
    dotBg: 'bg-purple-500',
    softBg: 'bg-purple-100',
    description: 'Calming periwinkle & soft violet',
  },
  {
    id: 'blossom',
    name: 'Cherry Blossom',
    accent: '#f43f5e',
    dotBg: 'bg-rose-500',
    softBg: 'bg-rose-100',
    description: 'Delicate pastel pink & peach',
  },
  {
    id: 'sage',
    name: 'Sage Garden',
    accent: '#10b981',
    dotBg: 'bg-emerald-500',
    softBg: 'bg-emerald-100',
    description: 'Fresh matcha & soothing eucalyptus',
  },
  {
    id: 'ocean',
    name: 'Ocean Breeze',
    accent: '#0284c7',
    dotBg: 'bg-sky-500',
    softBg: 'bg-sky-100',
    description: 'Crisp azure & sky blue',
  },
  {
    id: 'honey',
    name: 'Honey Sunset',
    accent: '#d97706',
    dotBg: 'bg-amber-500',
    softBg: 'bg-amber-100',
    description: 'Warm golden amber & butter',
  },
];

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('smarthostel_theme') || 'lavender';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('smarthostel_theme', theme);
  }, [theme]);

  const changeTheme = (themeId) => {
    if (THEMES.some((t) => t.id === themeId)) {
      setTheme(themeId);
    }
  };

  const currentThemeMeta = THEMES.find((t) => t.id === theme) || THEMES[0];

  return (
    <ThemeContext.Provider value={{ theme, setTheme: changeTheme, themes: THEMES, currentThemeMeta }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
