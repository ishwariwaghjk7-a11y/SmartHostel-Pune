// Authentic Pune Student Accommodation Directory (Centered around Fergusson College, F.C. Road)
// Total 50 Real Properties: 25 Authentic Boys Hostels & 25 Authentic Girls Hostels

export const initialColleges = [
  {
    _id: 'col-fc-1',
    name: 'Fergusson College (Autonomous)',
    city: 'Pune',
    address: 'F.C. Road, Deccan Gymkhana, Pune 411004',
    location: {
      type: 'Point',
      coordinates: [73.8415, 18.5236], // [longitude, latitude]
    },
  },
  {
    _id: 'col-bmcc-2',
    name: 'Brihan Maharashtra College of Commerce (BMCC)',
    city: 'Pune',
    address: 'BMCC Road, Deccan Gymkhana, Pune 411004',
    location: {
      type: 'Point',
      coordinates: [73.8345, 18.5195],
    },
  },
  {
    _id: 'col-coep-3',
    name: 'COEP Technological University',
    city: 'Pune',
    address: 'Wellesley Rd, Shivajinagar, Pune 411005',
    location: {
      type: 'Point',
      coordinates: [73.8567, 18.5310],
    },
  },
  {
    _id: 'col-sppu-4',
    name: 'Savitribai Phule Pune University (SPPU)',
    city: 'Pune',
    address: 'Ganeshkhind, Pune 411007',
    location: {
      type: 'Point',
      coordinates: [73.8227, 18.5529],
    },
  },
];

export const initialUsers = [
  {
    _id: 'usr-admin-1',
    name: 'College Accommodation Officer',
    email: 'admin@smarthostel.com',
    role: 'admin',
    phone: '+91 20 2567 1234',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  },
  {
    _id: 'usr-owner-1',
    name: 'Rajesh Kulkarni',
    email: 'owner1@smarthostel.com',
    role: 'owner',
    phone: '+91 98501 22334',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
  },
  {
    _id: 'usr-owner-2',
    name: 'Sunita Deshpande',
    email: 'owner2@smarthostel.com',
    role: 'owner',
    phone: '+91 98812 33445',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
  },
  {
    _id: 'usr-student-1',
    name: 'Rohan Deshmukh',
    email: 'student1@smarthostel.com',
    role: 'student',
    phone: '+91 99221 44556',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=200&q=80',
  },
  {
    _id: 'usr-student-2',
    name: 'Ananya Patil',
    email: 'student2@smarthostel.com',
    role: 'student',
    phone: '+91 97632 55667',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
  },
  {
    _id: 'usr-student-3',
    name: 'Siddharth Joshi',
    email: 'student3@smarthostel.com',
    role: 'student',
    phone: '+91 96573 66778',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
  },
];

export const initialHostels = [
  {
    "_id": "hst-b1",
    "ownerId": "usr-owner-1",
    "name": "Daund PG and Hostel for Boys",
    "description": "Premier student & bachelor PG situated on Apte Road, extremely close to F.C. Road. Maintained with high hygiene standards, basic student furniture, high-speed Wi-Fi, and a peaceful study-centric environment.",
    "address": "1237, Apte Road, Shivaji Nagar, Pune - 411004 (Extremely close to FC Road)",
    "area": "Deccan Gymkhana",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98224 77665",
    "rentFrom": 6500,
    "rentTo": 14000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No smoking",
      "Maintain quiet study hours"
    ],
    "images": [
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8465,
        18.5225
      ]
    },
    "rating": 4.8,
    "reviewCount": 5,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b1-1",
        "hostelId": "hst-b1",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 14000,
        "deposit": 28000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b1-2",
        "hostelId": "hst-b1",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b1-3",
        "hostelId": "hst-b1",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b2",
    "ownerId": "usr-owner-2",
    "name": "PHADKE HOSTEL",
    "description": "Well-known paid boys student accommodation opposite Vidya Bhavan School in peaceful Model Colony. Central study desk/table-chair configuration, Godrej security cupboards, integrated ceiling clothes-drying rods, and quiet residential zone. High occupancy rate.",
    "address": "1103 A 11 Vishwamitra, Opposite Vidya Bhavan School, Model Colony, Shivajinagar, Pune - 411016",
    "area": "Model Colony",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 20 2565 4411",
    "rentFrom": 7000,
    "rentTo": 15000,
    "amenities": [
      "WiFi",
      "Study Room",
      "CCTV",
      "Power Backup",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:15 PM",
      "Strict attendance check",
      "Godrej lockers provided"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8345,
        18.5348
      ]
    },
    "rating": 4.7,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b2-1",
        "hostelId": "hst-b2",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 15000,
        "deposit": 30000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b2-2",
        "hostelId": "hst-b2",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9800,
        "deposit": 19600,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b2-3",
        "hostelId": "hst-b2",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 2,
        "availableBeds": 0,
        "rent": 9000,
        "deposit": 18000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b3",
    "ownerId": "usr-owner-1",
    "name": "Sarang Boys Hostel",
    "description": "Premier student & bachelor PG on F.C. Road near Kidzee and Deccan Gymkhana. Air Conditioning (AC) options, attached meal service/food, high speed Wi-Fi connectivity, and standardized hygiene maintenance at affordable student rates.",
    "address": "Near Kidzee, Deccan Gymkhana, F C Road, Pune - 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98220 11988",
    "rentFrom": 4600,
    "rentTo": 8500,
    "amenities": [
      "AC",
      "Mess / Food",
      "WiFi",
      "CCTV",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "No alcohol",
      "Clean rooms daily"
    ],
    "images": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.842,
        18.521
      ]
    },
    "rating": 4.6,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b3-1",
        "hostelId": "hst-b3",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b3-2",
        "hostelId": "hst-b3",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 6200,
        "deposit": 12400,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b3-3",
        "hostelId": "hst-b3",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 5200,
        "deposit": 10400,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b3-4",
        "hostelId": "hst-b3",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 4600,
        "deposit": 9200,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b4",
    "ownerId": "usr-owner-2",
    "name": "Youthville - Shivaji Nagar (COEP)",
    "description": "Newly opened premium boys co-living space near Sancheti Chowk, Wellesley Road. Fully furnished modern suites with daily structured housekeeping, professional laundry service, community lounge areas, and biometric 24-7 gate security.",
    "address": "Morya Mitra Mandal, Wellesley Road, Near Sancheti Chowk, Shivajinagar, Pune - 411005",
    "area": "Shivajinagar",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 20 6765 7700",
    "rentFrom": 9500,
    "rentTo": 18000,
    "amenities": [
      "WiFi",
      "Laundry",
      "Biometric Entry",
      "CCTV",
      "Mess / Food",
      "Power Backup",
      "Study Room",
      "Hot Water",
      "Gym",
      "AC"
    ],
    "rules": [
      "Curfew 11:00 PM",
      "Biometric verification required",
      "Strict guest log protocol"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8545,
        18.5305
      ]
    },
    "rating": 4.9,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b4-1",
        "hostelId": "hst-b4",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 18000,
        "deposit": 36000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b4-2",
        "hostelId": "hst-b4",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12500,
        "deposit": 25000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b4-3",
        "hostelId": "hst-b4",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      }
    ]
  },
  {
    "_id": "hst-b5",
    "ownerId": "usr-owner-1",
    "name": "Ideal Hostel Facilities",
    "description": "Economy boys student hostel located in Sambhaji Housing Society, bridging Senapati Bapat Road and Model Colony. Low-cost pricing structure, central connectivity to Fergusson and SPPU, and basic locker setups.",
    "address": "Sambhaji Housing Society, Senapati Bapat Road, Laxmi Society, Model Colony, Pune - 411016",
    "area": "Model Colony",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 98811 88299",
    "rentFrom": 4500,
    "rentTo": 9000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "Lockers allocated per student",
      "No unauthorized guests"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8315,
        18.535
      ]
    },
    "rating": 4.4,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b5-1",
        "hostelId": "hst-b5",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b5-2",
        "hostelId": "hst-b5",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6000,
        "deposit": 12000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b5-3",
        "hostelId": "hst-b5",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 4500,
        "deposit": 9000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b6",
    "ownerId": "usr-owner-2",
    "name": "Fergusson College Campus Boys Hostel",
    "description": "Official on-campus boys quarters located in the historic Fergusson College grounds. Walking distance to Kimaya open-air amphitheatre and science departments. Dedicated study tables.",
    "address": "Campus Quadrangle, Fergusson College, F.C. Road, Deccan Gymkhana, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 20 6765 6000",
    "rentFrom": 5500,
    "rentTo": 9500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "College ID mandatory for entry",
      "Strict zero-ragging policy"
    ],
    "images": [
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8415,
        18.5236
      ]
    },
    "rating": 4.8,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b6-1",
        "hostelId": "hst-b6",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b6-2",
        "hostelId": "hst-b6",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7200,
        "deposit": 14400,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b6-3",
        "hostelId": "hst-b6",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 5500,
        "deposit": 11000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b7",
    "ownerId": "usr-owner-1",
    "name": "FC Residency Boys Student Home",
    "description": "Premier student accommodation right behind Wadeshwar on bustling F.C. Road. Ergonomic study spaces, high-speed internet, and daily housekeeping.",
    "address": "Behind Wadeshwar Restaurant, F.C. Road, Deccan Gymkhana, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98812 44556",
    "rentFrom": 6500,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No smoking on premises",
      "Advance rent by 5th of month"
    ],
    "images": [
      "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8422,
        18.5245
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b7-1",
        "hostelId": "hst-b7",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 13500,
        "deposit": 27000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b7-2",
        "hostelId": "hst-b7",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b7-3",
        "hostelId": "hst-b7",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b8",
    "ownerId": "usr-owner-2",
    "name": "Tukaram Paduka Classic Boys PG",
    "description": "Located at the iconic Tukaram Paduka Chowk on F.C. Road. Just a 2-minute walk to Fergusson College gate #2. Homely Maharashtrian mess meals.",
    "address": "Opp. Tukaram Paduka Chowk, F.C. Road, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98502 99118",
    "rentFrom": 6000,
    "rentTo": 12500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Hot Water",
      "Power Backup",
      "Study Room"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "No alcohol",
      "Quiet hours after 11 PM"
    ],
    "images": [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1567496898669-ee935f5f647a?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8432,
        18.5255
      ]
    },
    "rating": 4.6,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b8-1",
        "hostelId": "hst-b8",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10000,
        "deposit": 20000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b8-2",
        "hostelId": "hst-b8",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b8-3",
        "hostelId": "hst-b8",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 6000,
        "deposit": 12000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b9",
    "ownerId": "usr-owner-1",
    "name": "BMCC Boys Hostel",
    "description": "Spacious student hostel on BMCC Road. Walking distance to both Fergusson College and BMCC. Well-ventilated rooms with green surroundings and sports ground access.",
    "address": "BMCC Road, Near Deccan Gymkhana, Pune 411004",
    "area": "BMCC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 20 6765 6200",
    "rentFrom": 6500,
    "rentTo": 12000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Gym",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "No unauthorized guests",
      "ID checks at gate"
    ],
    "images": [
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8345,
        18.5195
      ]
    },
    "rating": 4.5,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b9-1",
        "hostelId": "hst-b9",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9000,
        "deposit": 18000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b9-2",
        "hostelId": "hst-b9",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b10",
    "ownerId": "usr-owner-2",
    "name": "Modern College Boys Hostel",
    "description": "Academic boys hostel near Modern High School and College, J.M. Road. Walking path connects directly to Fergusson College through Ghole Road in 8 minutes.",
    "address": "Behind Modern High School & College, Off JM Road, Shivajinagar, Pune 411005",
    "area": "JM Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 20 2553 5100",
    "rentFrom": 6000,
    "rentTo": 11000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "Strict attendance check",
      "No electrical heaters"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8492,
        18.5285
      ]
    },
    "rating": 4.4,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b10-1",
        "hostelId": "hst-b10",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9000,
        "deposit": 18000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b10-2",
        "hostelId": "hst-b10",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b10-3",
        "hostelId": "hst-b10",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 6000,
        "deposit": 12000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b11",
    "ownerId": "usr-owner-1",
    "name": "Maratha Vidya Prasarak Boys Hostel",
    "description": "Historic boys hostel situated close to the base of Fergusson Hill. Green surroundings, breezy cross-ventilation, and subsidized monthly student mess.",
    "address": "Behind Fergusson College Hill, Off F.C. Road, Shivajinagar, Pune 411005",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 20 2553 4400",
    "rentFrom": 5000,
    "rentTo": 9000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "College ID compulsory",
      "No loud noise"
    ],
    "images": [
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8455,
        18.5305
      ]
    },
    "rating": 4.3,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b11-1",
        "hostelId": "hst-b11",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b11-2",
        "hostelId": "hst-b11",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b11-3",
        "hostelId": "hst-b11",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5000,
        "deposit": 10000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b12",
    "ownerId": "usr-owner-2",
    "name": "Karve Road Metro Boys Stay",
    "description": "Opposite Garware College Metro Station on Karve Road. Fast commute to Fergusson College and Deccan Gymkhana. Unlimited WiFi and purified drinking water.",
    "address": "Opp. Garware College Metro Station, Karve Road, Pune 411004",
    "area": "Karve Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98811 55660",
    "rentFrom": 5500,
    "rentTo": 11000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No smoking",
      "Maintain room hygiene"
    ],
    "images": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8315,
        18.5115
      ]
    },
    "rating": 4.4,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b12-1",
        "hostelId": "hst-b12",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b12-2",
        "hostelId": "hst-b12",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b12-3",
        "hostelId": "hst-b12",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5500,
        "deposit": 11000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b13",
    "ownerId": "usr-owner-1",
    "name": "Deccan Gymkhana Sportsman Boys Lodge",
    "description": "Sports-friendly boys lodge near PYC Gymkhana ground and swimming pool. Large wardrobe storage, bicycle parking shed, and protein-balanced mess diet.",
    "address": "Lane 1, Prabhat Road, Near Deccan Bus Stand, Pune 411004",
    "area": "Deccan Gymkhana",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98505 44332",
    "rentFrom": 7000,
    "rentTo": 14000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "Gym",
      "CCTV",
      "Power Backup",
      "Hot Water",
      "Study Room"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "Gym access 6 AM - 9 PM",
      "No smoking"
    ],
    "images": [
      "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8398,
        18.5172
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b13-1",
        "hostelId": "hst-b13",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b13-2",
        "hostelId": "hst-b13",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b13-3",
        "hostelId": "hst-b13",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b14",
    "ownerId": "usr-owner-2",
    "name": "Shree Ganesh Boys Student PG",
    "description": "Quiet residential boys accommodation in leafy Prabhat Road Lane 4. Homely atmosphere run by experienced local family. Delicious Maharashtrian breakfast and dinner.",
    "address": "Lane 4, Prabhat Road, Deccan Gymkhana, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98223 66110",
    "rentFrom": 6800,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No alcohol",
      "Quiet study hours during exams"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8365,
        18.5155
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b14-1",
        "hostelId": "hst-b14",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10500,
        "deposit": 21000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b14-2",
        "hostelId": "hst-b14",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b14-3",
        "hostelId": "hst-b14",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 6800,
        "deposit": 13600,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b15",
    "ownerId": "usr-owner-1",
    "name": "Senapati Bapat Road Youth Living for Boys",
    "description": "Located behind ICC Trade Tower on SB Road. Near Symbiosis and easy 10-minute cycle to Fergusson College. Modern high-speed connectivity and laundry setup.",
    "address": "Behind ICC Trade Tower, Senapati Bapat Road, Pune 411016",
    "area": "Senapati Bapat Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98901 33445",
    "rentFrom": 6000,
    "rentTo": 12000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "No unauthorized guests",
      "Maintain cleanliness"
    ],
    "images": [
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8295,
        18.5345
      ]
    },
    "rating": 4.5,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b15-1",
        "hostelId": "hst-b15",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10000,
        "deposit": 20000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b15-2",
        "hostelId": "hst-b15",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b15-3",
        "hostelId": "hst-b15",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 6000,
        "deposit": 12000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b16",
    "ownerId": "usr-owner-2",
    "name": "Chatushrungi Hillview Boys PG",
    "description": "Tranquil student residence near Chatushrungi Temple on SB Road. Fresh hill breeze, private reading desks, and high security CCTV monitoring.",
    "address": "Near Chatushrungi Temple, Senapati Bapat Road, Pune 411016",
    "area": "Senapati Bapat Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98814 66223",
    "rentFrom": 5800,
    "rentTo": 11500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Hot Water",
      "Study Room",
      "Power Backup"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No smoking",
      "Maintain quiet environment"
    ],
    "images": [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8275,
        18.5385
      ]
    },
    "rating": 4.4,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b16-1",
        "hostelId": "hst-b16",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b16-2",
        "hostelId": "hst-b16",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b16-3",
        "hostelId": "hst-b16",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5800,
        "deposit": 11600,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b17",
    "ownerId": "usr-owner-1",
    "name": "Gokhale Nagar Academic Youth Lodge",
    "description": "Budget-friendly boys PG near Chatushrungi Water Tank. Very popular with Fergusson, SPPU, and BMCC students. Includes two meals daily and study room.",
    "address": "Near Chatushrungi Water Tank, Gokhale Nagar, Pune 411016",
    "area": "Senapati Bapat Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98231 44556",
    "rentFrom": 5000,
    "rentTo": 9500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No alcohol",
      "Pay rent by 5th of month"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8298,
        18.5375
      ]
    },
    "rating": 4.3,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b17-1",
        "hostelId": "hst-b17",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b17-2",
        "hostelId": "hst-b17",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b17-3",
        "hostelId": "hst-b17",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5000,
        "deposit": 10000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b18",
    "ownerId": "usr-owner-2",
    "name": "Shivneri Boys Executive PG",
    "description": "Prime J.M. Road location overlooking Chhatrapati Sambhaji Garden. Walking access to FC Road via Z-Bridge in 5 minutes. Well-maintained rooms with daily cleaning.",
    "address": "Near Sambhaji Park, J.M. Road, Deccan Gymkhana, Pune 411004",
    "area": "JM Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98817 22345",
    "rentFrom": 6500,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "No smoking",
      "Maintain decorum"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8495,
        18.5215
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b18-1",
        "hostelId": "hst-b18",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 13500,
        "deposit": 27000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b18-2",
        "hostelId": "hst-b18",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b18-3",
        "hostelId": "hst-b18",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b19",
    "ownerId": "usr-owner-1",
    "name": "Garware College Lane Boys PG",
    "description": "Located in the quiet academic lane facing Garware College on Karve Road. Direct bus/metro connection to FC Road. Includes pure veg dining hall and high speed WiFi.",
    "address": "Lane Opp. Garware College, Karve Road, Erandwane, Pune 411004",
    "area": "Karve Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98228 99120",
    "rentFrom": 5800,
    "rentTo": 11500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Hot Water",
      "Study Room"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No alcohol",
      "Pay rent on time"
    ],
    "images": [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8295,
        18.5105
      ]
    },
    "rating": 4.4,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b19-1",
        "hostelId": "hst-b19",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9000,
        "deposit": 18000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b19-2",
        "hostelId": "hst-b19",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b19-3",
        "hostelId": "hst-b19",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5800,
        "deposit": 11600,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b20",
    "ownerId": "usr-owner-2",
    "name": "Paud Phata Scholars Boys PG",
    "description": "Metro-accessible student accommodation near Paud Phata, Kothrud. Well-ventilated rooms, mess tie-up, and quiet reading room for science and commerce exams.",
    "address": "Lane 2, Rambaug Colony, Near Paud Phata, Kothrud, Pune 411038",
    "area": "Kothrud",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98501 22334",
    "rentFrom": 6500,
    "rentTo": 13000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "Maintain clean common areas",
      "Advance monthly rent payments"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8218,
        18.5115
      ]
    },
    "rating": 4.5,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b20-1",
        "hostelId": "hst-b20",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10500,
        "deposit": 21000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b20-2",
        "hostelId": "hst-b20",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b21",
    "ownerId": "usr-owner-1",
    "name": "Mayur Colony Scholars Boys PG",
    "description": "Green and peaceful surroundings in prime Kothrud. Connected to Fergusson College via Karve Road buses & Metro in under 15 minutes. Pure vegetarian mess with daily breakfast and dinner.",
    "address": "Near Joggers Park, Mayur Colony, Kothrud, Pune 411038",
    "area": "Kothrud",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98812 33445",
    "rentFrom": 6500,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Hot Water",
      "Study Room"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "No smoking on property",
      "Quiet study hours during exams"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8155,
        18.5075
      ]
    },
    "rating": 4.5,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b21-1",
        "hostelId": "hst-b21",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10500,
        "deposit": 21000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b21-2",
        "hostelId": "hst-b21",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b22",
    "ownerId": "usr-owner-2",
    "name": "Dnyaneshwar Boys Student PG",
    "description": "Situated only 300 meters from Fergusson College Main Gate on F.C. Road. Exceptional location, clean washrooms, high speed WiFi, and attentive local warden.",
    "address": "Near F.C. College Main Gate, F.C. Road, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98220 88771",
    "rentFrom": 6500,
    "rentTo": 13000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Hot Water",
      "Power Backup",
      "Study Room"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No unauthorized friends overnight",
      "Strict hygiene standard"
    ],
    "images": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8425,
        18.5225
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b22-1",
        "hostelId": "hst-b22",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10000,
        "deposit": 20000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b22-2",
        "hostelId": "hst-b22",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b22-3",
        "hostelId": "hst-b22",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b23",
    "ownerId": "usr-owner-1",
    "name": "Sumangal Boys Hostel & PG",
    "description": "Centrally placed on Senapati Bapat Road across from Symbiosis. Regular bus transit to Fergusson College and Deccan Gymkhana. Spacious double and triple sharing rooms.",
    "address": "Opp. Symbiosis Primary Campus, Senapati Bapat Road, Pune 411016",
    "area": "Senapati Bapat Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 97632 11990",
    "rentFrom": 6200,
    "rentTo": 12500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:45 PM",
      "No smoking",
      "Monthly rent by 5th"
    ],
    "images": [
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8315,
        18.5325
      ]
    },
    "rating": 4.5,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b23-1",
        "hostelId": "hst-b23",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9800,
        "deposit": 19600,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b23-2",
        "hostelId": "hst-b23",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b23-3",
        "hostelId": "hst-b23",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 6200,
        "deposit": 12400,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b24",
    "ownerId": "usr-owner-2",
    "name": "Chhatrapati Shivaji Boys Hostel",
    "description": "Prominent student hostel near Shivajinagar Railway & Metro Station. Unmatched connectivity for outstation students commuting across Pune colleges.",
    "address": "Near Shivajinagar Railway & Metro Station, Pune 411005",
    "area": "Shivajinagar",
    "city": "Pune",
    "gender": "male",
    "hostelType": "hostel",
    "phone": "+91 20 2551 1200",
    "rentFrom": 5000,
    "rentTo": 9500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "Valid student ID mandatory",
      "No overnight visitors"
    ],
    "images": [
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8522,
        18.5312
      ]
    },
    "rating": 4.4,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b24-1",
        "hostelId": "hst-b24",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b24-2",
        "hostelId": "hst-b24",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-b24-3",
        "hostelId": "hst-b24",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5000,
        "deposit": 10000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-b25",
    "ownerId": "usr-owner-1",
    "name": "Shinde Heritage Boys PG",
    "description": "Classic heritage bungalow accommodation off F.C. Road opposite Fergusson Gymkhana. High ceilings, serene courtyard study space, and home-cooked meals.",
    "address": "Off F.C. Road, Opp. Fergusson Gymkhana, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "male",
    "hostelType": "pg",
    "phone": "+91 98810 55123",
    "rentFrom": 6800,
    "rentTo": 14000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 10:30 PM",
      "No smoking",
      "Maintain quiet hours"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8418,
        18.525
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-b25-1",
        "hostelId": "hst-b25",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 14000,
        "deposit": 28000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b25-2",
        "hostelId": "hst-b25",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9800,
        "deposit": 19600,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-b25-3",
        "hostelId": "hst-b25",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6800,
        "deposit": 13600,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g1",
    "ownerId": "usr-owner-2",
    "name": "MyHostelRoom Venus",
    "description": "Managed girls student PG located at Vidya Apartment along Lakaki Lake Road, Model Colony. High student satisfaction ratings, dedicated study corners, automated backup facilities, and safety-first smart entry protocols.",
    "address": "Vidya Apartment, Lakaki Lake Road, Model Colony, Shivajinagar, Pune - 411016",
    "area": "Model Colony",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98812 44778",
    "rentFrom": 8000,
    "rentTo": 15000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "Study Room",
      "Power Backup",
      "Biometric Entry",
      "CCTV",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Biometric check-in mandatory",
      "Safe residential locality"
    ],
    "images": [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8335,
        18.5352
      ]
    },
    "rating": 4.9,
    "reviewCount": 5,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g1-1",
        "hostelId": "hst-g1",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12500,
        "deposit": 25000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g1-2",
        "hostelId": "hst-g1",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8000,
        "deposit": 16000,
        "ac": false,
        "attachedBathroom": true
      }
    ]
  },
  {
    "_id": "hst-g2",
    "ownerId": "usr-owner-1",
    "name": "Blessing Premium PG",
    "description": "Premium girls accommodation in Deccan Gymkhana near Reliance Centro, only 0.7 km from Fergusson College. Air Conditioning (AC), Power Backup, High-speed Wi-Fi, structural hygiene monitoring, and nutritious dining.",
    "address": "Deccan Gymkhana, Near Reliance Centro (0.7 km from Fergusson College), Pune - 411004",
    "area": "Deccan Gymkhana",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98813 55660",
    "rentFrom": 8500,
    "rentTo": 17000,
    "amenities": [
      "AC",
      "Power Backup",
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Hot Water",
      "Laundry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "No male visitors inside rooms",
      "Daily biometric sign-in"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.841,
        18.518
      ]
    },
    "rating": 4.8,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g2-1",
        "hostelId": "hst-g2",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 17000,
        "deposit": 34000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g2-2",
        "hostelId": "hst-g2",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12000,
        "deposit": 24000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g2-3",
        "hostelId": "hst-g2",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g3",
    "ownerId": "usr-owner-2",
    "name": "Thopates PG for Girls and Boys",
    "description": "Multi-wing student and working professional accommodation on Shirole Galli, Gaothan, Shivajinagar. Dedicated secure wings, 24-hour continuous water and electricity, daily sanitation of common spaces, CCTV surveillance, and nearby internal library access.",
    "address": "313, Shirole Galli, Gaothan, Shivajinagar, Pune - 411005",
    "area": "Shivajinagar",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 97632 88441",
    "rentFrom": 4500,
    "rentTo": 8500,
    "amenities": [
      "WiFi",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "Separate wings for girls and boys",
      "Lockers provided"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.849,
        18.526
      ]
    },
    "rating": 4.5,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g3-1",
        "hostelId": "hst-g3",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g3-2",
        "hostelId": "hst-g3",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 6200,
        "deposit": 12400,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g3-3",
        "hostelId": "hst-g3",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 4500,
        "deposit": 9000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g4",
    "ownerId": "usr-owner-1",
    "name": "Youthville SBR 1 & 2",
    "description": "Premium luxury girls hostel and co-living space off Senapati Bapat Road, Shivaji Housing Society. Fully-furnished luxury rooms with nutritional tailored meal subscriptions, high-speed Wi-Fi, indoor recreation games, power backup, and modern security.",
    "address": "Off Senapati Bapat Road, Shivaji Co-operative Housing Society, Gokhalenagar, Pune - 411016",
    "area": "Senapati Bapat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 20 6765 8800",
    "rentFrom": 10000,
    "rentTo": 21000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "Laundry",
      "Power Backup",
      "Biometric Entry",
      "Gym",
      "CCTV",
      "Hot Water",
      "AC"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "Biometric door access",
      "Housekeeping daily included"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8295,
        18.534
      ]
    },
    "rating": 4.9,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g4-1",
        "hostelId": "hst-g4",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 21000,
        "deposit": 42000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g4-2",
        "hostelId": "hst-g4",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 14000,
        "deposit": 28000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g4-3",
        "hostelId": "hst-g4",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 10000,
        "deposit": 20000,
        "ac": false,
        "attachedBathroom": true
      }
    ]
  },
  {
    "_id": "hst-g5",
    "ownerId": "usr-owner-2",
    "name": "Yash Girls Hostel",
    "description": "Established working women & student hostel situated in Revenue Colony, Shivajinagar opposite Hotel Bhushan. Standard security deadlines (Gate closes at 9:30 PM), solar hot water geysers, student desks, and home-cooked meals.",
    "address": "1170, 13A, Revenue Colony, Shivaji Nagar, Pune - 411005 (Opposite Hotel Bhushan)",
    "area": "Shivajinagar",
    "city": "Pune",
    "gender": "female",
    "hostelType": "hostel",
    "phone": "+91 98811 22300",
    "rentFrom": 5500,
    "rentTo": 11000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Gate strictly closes at 9:30 PM",
      "ID verification upon check-in",
      "No outside male guests"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8495,
        18.529
      ]
    },
    "rating": 4.6,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g5-1",
        "hostelId": "hst-g5",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g5-2",
        "hostelId": "hst-g5",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7200,
        "deposit": 14400,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g5-3",
        "hostelId": "hst-g5",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5500,
        "deposit": 11000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g6",
    "ownerId": "usr-owner-1",
    "name": "Fergusson College Campus Girls Hostel",
    "description": "Premier campus girls hostel inside the historic Fergusson College grounds. Highly secure with 24/7 female security guards, biometric access, reading hall, and medical assistance room.",
    "address": "Girls Hostel Quarters, Fergusson College Campus, F.C. Road, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "hostel",
    "phone": "+91 20 6765 6100",
    "rentFrom": 6000,
    "rentTo": 10500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Biometric Entry",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "Biometric check-in mandatory",
      "No outside male visitors inside premises"
    ],
    "images": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8405,
        18.5225
      ]
    },
    "rating": 4.9,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g6-1",
        "hostelId": "hst-g6",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10500,
        "deposit": 21000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g6-2",
        "hostelId": "hst-g6",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g6-3",
        "hostelId": "hst-g6",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 6000,
        "deposit": 12000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g7",
    "ownerId": "usr-owner-2",
    "name": "Deccan Paradise Girls Hostel & PG",
    "description": "Safe, premium girls accommodation in peaceful Prabhat Road. Full CCTV surveillance, resident lady warden Sunita-tai, nutritious 3-course meals, and walking distance to Goodluck Cafe.",
    "address": "Lane 5, Prabhat Road, Near Goodluck Cafe, Deccan Gymkhana, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98812 33445",
    "rentFrom": 7500,
    "rentTo": 18000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water",
      "Biometric Entry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Biometric check-in required",
      "Strictly girls only accommodation"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8385,
        18.5165
      ]
    },
    "rating": 4.8,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g7-1",
        "hostelId": "hst-g7",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 18000,
        "deposit": 36000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g7-2",
        "hostelId": "hst-g7",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12500,
        "deposit": 25000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g7-3",
        "hostelId": "hst-g7",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g7-4",
        "hostelId": "hst-g7",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g8",
    "ownerId": "usr-owner-1",
    "name": "MKSSS Karve Girls Student PG",
    "description": "Renowned girls accommodation near Karve Statue. Supported by the pioneering Maharshi Karve Stree Shikshan Samstha tradition. High safety standards, pure vegetarian mess, and clean rooms.",
    "address": "Near Karve Statue, Karve Road, Erandwane, Pune 411004",
    "area": "Karve Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 20 2543 3300",
    "rentFrom": 6500,
    "rentTo": 13000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Biometric Entry",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "No male visitors inside rooms",
      "Weekly attendance review"
    ],
    "images": [
      "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8285,
        18.5095
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g8-1",
        "hostelId": "hst-g8",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10500,
        "deposit": 21000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g8-2",
        "hostelId": "hst-g8",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7800,
        "deposit": 15600,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g8-3",
        "hostelId": "hst-g8",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g9",
    "ownerId": "usr-owner-2",
    "name": "Sharda Girls Student Hostel",
    "description": "Dedicated student hostel for young women located on BMCC Road. Highly convenient for students enrolled in BMCC, Fergusson College, and Symbiosis. Well-lit study tables and peaceful ambiance.",
    "address": "BMCC Road, Opp. Agarkar Institute, Deccan Gymkhana, Pune 411004",
    "area": "BMCC Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "hostel",
    "phone": "+91 98509 11223",
    "rentFrom": 7000,
    "rentTo": 14500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Study Room",
      "Hot Water",
      "Power Backup",
      "Laundry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Parents contact verified upon admission",
      "Silent hours after 10 PM"
    ],
    "images": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8355,
        18.5205
      ]
    },
    "rating": 4.6,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g9-1",
        "hostelId": "hst-g9",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g9-2",
        "hostelId": "hst-g9",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8000,
        "deposit": 16000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g9-3",
        "hostelId": "hst-g9",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g10",
    "ownerId": "usr-owner-1",
    "name": "Prabhat Sanskriti Girls PG",
    "description": "Tranquil traditional bungalow property on Prabhat Road Lane 14. Tree-lined street, solar hot water, attached study desks, and curated nutritious breakfast and evening snacks.",
    "address": "Lane 14, Prabhat Road, Deccan Gymkhana, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98812 77889",
    "rentFrom": 7000,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Hot Water",
      "Power Backup",
      "Study Room"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "No male guests beyond reception",
      "Advance rent by 5th"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8335,
        18.5135
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "pending",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g10-1",
        "hostelId": "hst-g10",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 0,
        "availableBeds": 2,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g10-2",
        "hostelId": "hst-g10",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g10-3",
        "hostelId": "hst-g10",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g11",
    "ownerId": "usr-owner-2",
    "name": "Prabhat Avenue Premium Girls Suites",
    "description": "Luxury air-conditioned student suites for girls on Prabhat Road Lane 3. Fingerprint biometric door locks, study cubicles, gym, high-speed WiFi, and gourmet mess.",
    "address": "Lane 3, Prabhat Road, Near Deccan Post Office, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98501 22334",
    "rentFrom": 11000,
    "rentTo": 22000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "Gym",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water",
      "Biometric Entry",
      "AC"
    ],
    "rules": [
      "Curfew 10:00 PM",
      "Biometric authentication mandatory",
      "No overnight male visitors"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8378,
        18.5172
      ]
    },
    "rating": 4.8,
    "reviewCount": 3,
    "verificationStatus": "pending",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g11-1",
        "hostelId": "hst-g11",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 22000,
        "deposit": 44000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g11-2",
        "hostelId": "hst-g11",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 15000,
        "deposit": 30000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g11-3",
        "hostelId": "hst-g11",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      }
    ]
  },
  {
    "_id": "hst-g12",
    "ownerId": "usr-owner-1",
    "name": "Law College Heritage Girls Stay",
    "description": "Nestled between ILS Law College and FTII on Law College Road. Historic green neighborhood, quiet library study room, in-house laundry service, and 24/7 solar water heating.",
    "address": "Behind ILS Law College, Law College Road, Erandwane, Pune 411004",
    "area": "Law College Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98811 00223",
    "rentFrom": 8500,
    "rentTo": 18000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water",
      "Biometric Entry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "No smoking",
      "Maintain quiet hours during exams"
    ],
    "images": [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8295,
        18.5165
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g12-1",
        "hostelId": "hst-g12",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 18000,
        "deposit": 36000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g12-2",
        "hostelId": "hst-g12",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12500,
        "deposit": 25000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g12-3",
        "hostelId": "hst-g12",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g13",
    "ownerId": "usr-owner-2",
    "name": "Sai Sneha Girls PG & Student Home",
    "description": "Directly opposite Fergusson College Gate #1 on F.C. Road. Zero commute time for FC students! Highly secure environment with digital entry and delicious hygienic breakfast.",
    "address": "Opp. Fergusson College Gate #1, F.C. Road, Pune 411004",
    "area": "FC Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98221 77443",
    "rentFrom": 7500,
    "rentTo": 16500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Biometric Entry",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "No male visitors inside rooms",
      "College identity proof mandatory"
    ],
    "images": [
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8422,
        18.522
      ]
    },
    "rating": 4.9,
    "reviewCount": 4,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g13-1",
        "hostelId": "hst-g13",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 16500,
        "deposit": 33000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g13-2",
        "hostelId": "hst-g13",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12000,
        "deposit": 24000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g13-3",
        "hostelId": "hst-g13",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g13-4",
        "hostelId": "hst-g13",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g14",
    "ownerId": "usr-owner-1",
    "name": "Kamla Nehru Park View Girls Residency",
    "description": "Scenic student PG situated directly opposite lush Kamala Nehru Park. Ideal morning jogging spot, high-speed WiFi, attached bathrooms, and homestyle Maharashtrian breakfast.",
    "address": "Lane 11, Prabhat Road, Near Kamala Nehru Park, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98813 44556",
    "rentFrom": 9000,
    "rentTo": 19000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water",
      "Biometric Entry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Maintain silent hours",
      "No overnight unauthorized guests"
    ],
    "images": [
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8345,
        18.5148
      ]
    },
    "rating": 4.8,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g14-1",
        "hostelId": "hst-g14",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 19000,
        "deposit": 38000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g14-2",
        "hostelId": "hst-g14",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 13000,
        "deposit": 26000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g14-3",
        "hostelId": "hst-g14",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 9000,
        "deposit": 18000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g15",
    "ownerId": "usr-owner-2",
    "name": "Deep Bunglow Heritage Girls Living",
    "description": "Well-maintained bungalow residence in upscale Model Colony. CCTV monitoring, RO purified water, in-house laundry service, and healthy balanced home-style meals.",
    "address": "Behind Hare Krishna Temple, Deep Bunglow Chowk, Model Colony, Pune 411016",
    "area": "Model Colony",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98812 33445",
    "rentFrom": 8500,
    "rentTo": 16000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Hot Water",
      "Biometric Entry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "No male visitors inside rooms",
      "Silent hours after 10 PM"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8355,
        18.5365
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g15-1",
        "hostelId": "hst-g15",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 12000,
        "deposit": 24000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g15-2",
        "hostelId": "hst-g15",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g16",
    "ownerId": "usr-owner-1",
    "name": "Erandwane Greenwoods Girls PG",
    "description": "Peaceful residential property in green Erandwane near Deenanath Hospital. Easy public transport and PMT buses to Fergusson College and Deccan Gymkhana in 10 minutes.",
    "address": "Opp. Deenanath Mangeshkar Hospital, Erandwane, Pune 411004",
    "area": "Erandwane",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98500 77889",
    "rentFrom": 7500,
    "rentTo": 15500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water",
      "Laundry"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Strictly girls only",
      "Visitors allowed in lounge only"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8265,
        18.5035
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g16-1",
        "hostelId": "hst-g16",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g16-2",
        "hostelId": "hst-g16",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g16-3",
        "hostelId": "hst-g16",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g17",
    "ownerId": "usr-owner-2",
    "name": "Ananya Girls Student Living",
    "description": "Charming girls residence tucked in Deccan Gymkhana Lane 3, two minutes from Goodluck Chowk. Dedicated warden, CCTV on all staircases, and homemade tiffin meals.",
    "address": "Deccan Gymkhana Lane 3, Near Goodluck Cafe, Pune 411004",
    "area": "Deccan Gymkhana",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 97633 44551",
    "rentFrom": 7200,
    "rentTo": 15000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Parents permission note for outstation visits",
      "Cleanliness check"
    ],
    "images": [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8405,
        18.5178
      ]
    },
    "rating": 4.7,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g17-1",
        "hostelId": "hst-g17",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 15000,
        "deposit": 30000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g17-2",
        "hostelId": "hst-g17",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g17-3",
        "hostelId": "hst-g17",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7800,
        "deposit": 15600,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g17-4",
        "hostelId": "hst-g17",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 7200,
        "deposit": 14400,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g18",
    "ownerId": "usr-owner-1",
    "name": "Kasturba Gandhi Girls Student Hostel",
    "description": "Government-recognized, trustworthy girls hostel in Shivajinagar. Safe neighborhood near Balgandharva auditorium with easy metro access to all Pune colleges.",
    "address": "Off J.M. Road, Near Balgandharva Rangmandir, Shivajinagar, Pune 411005",
    "area": "Shivajinagar",
    "city": "Pune",
    "gender": "female",
    "hostelType": "hostel",
    "phone": "+91 20 2553 1120",
    "rentFrom": 5500,
    "rentTo": 11000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Biometric Entry",
      "Study Room",
      "Hot Water",
      "Power Backup"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "Attendance register check daily",
      "Strictly no outsiders"
    ],
    "images": [
      "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8505,
        18.5255
      ]
    },
    "rating": 4.5,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g18-1",
        "hostelId": "hst-g18",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 9500,
        "deposit": 19000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g18-2",
        "hostelId": "hst-g18",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g18-3",
        "hostelId": "hst-g18",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 5500,
        "deposit": 11000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g19",
    "ownerId": "usr-owner-2",
    "name": "Muktangan Girls PG & Student Home",
    "description": "Serene girls accommodation situated beside Model Colony Lake. Clean study tables, solar water geysers, Wi-Fi 6 router on every floor, and healthy home-style meals.",
    "address": "Model Colony Lake Road, Shivajinagar, Pune 411016",
    "area": "Model Colony",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98224 88990",
    "rentFrom": 8000,
    "rentTo": 16000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "No loud music after 10 PM",
      "Advance rent by 5th"
    ],
    "images": [
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8335,
        18.535
      ]
    },
    "rating": 4.7,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g19-1",
        "hostelId": "hst-g19",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 16000,
        "deposit": 32000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g19-2",
        "hostelId": "hst-g19",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11500,
        "deposit": 23000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g19-3",
        "hostelId": "hst-g19",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8000,
        "deposit": 16000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g20",
    "ownerId": "usr-owner-1",
    "name": "Deepali Girls PG",
    "description": "Warm and friendly girls PG on Prabhat Road Lane 7. CCTV monitored, RO water, attached washrooms, and walking distance to FC Road cafes and bookshops.",
    "address": "Lane 7, Prabhat Road, Deccan Gymkhana, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98811 77334",
    "rentFrom": 7500,
    "rentTo": 15000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Hot Water",
      "Study Room"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Girls only",
      "No smoking"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8375,
        18.5158
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g20-1",
        "hostelId": "hst-g20",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g20-2",
        "hostelId": "hst-g20",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 8500,
        "deposit": 17000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g20-3",
        "hostelId": "hst-g20",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g21",
    "ownerId": "usr-owner-2",
    "name": "Renuka Girls Student PG",
    "description": "Located behind ICC Trade Center on Senapati Bapat Road. Modern building with lift, security guard, mess dining room, and study hall.",
    "address": "Behind ICC Trade Center, Senapati Bapat Road, Pune 411016",
    "area": "Senapati Bapat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98902 44119",
    "rentFrom": 7000,
    "rentTo": 14500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "No male visitors inside rooms",
      "Maintain cleanliness"
    ],
    "images": [
      "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8305,
        18.5335
      ]
    },
    "rating": 4.6,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g21-1",
        "hostelId": "hst-g21",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g21-2",
        "hostelId": "hst-g21",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 8000,
        "deposit": 16000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g21-3",
        "hostelId": "hst-g21",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 3,
        "availableBeds": 1,
        "rent": 7000,
        "deposit": 14000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g22",
    "ownerId": "usr-owner-1",
    "name": "Kulkarni Heritage Girls PG",
    "description": "Cozy, family-managed girls stay on Prabhat Road Lane 1 near Goodluck. Very safe residential neighbourhood, homemade meals with sweet Sunday treats.",
    "address": "Lane 1, Prabhat Road, Near Deccan Bus Stand, Pune 411004",
    "area": "Prabhat Road",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98223 55112",
    "rentFrom": 7800,
    "rentTo": 15500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Hot Water",
      "Power Backup",
      "Study Room"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "No unauthorized guests",
      "Family-friendly atmosphere"
    ],
    "images": [
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8401,
        18.5182
      ]
    },
    "rating": 4.8,
    "reviewCount": 3,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g22-1",
        "hostelId": "hst-g22",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 15500,
        "deposit": 31000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g22-2",
        "hostelId": "hst-g22",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11000,
        "deposit": 22000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g22-3",
        "hostelId": "hst-g22",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 1,
        "availableBeds": 2,
        "rent": 7800,
        "deposit": 15600,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g23",
    "ownerId": "usr-owner-2",
    "name": "Vrundavan Girls Student PG",
    "description": "Peaceful girls stay near Kamala Nehru Park and Bhandarkar Road. Surrounded by greenery with high study focus and nutritious vegetarian food.",
    "address": "Near Kamala Nehru Park, Off Bhandarkar Road, Erandwane, Pune 411004",
    "area": "Erandwane",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98810 66221",
    "rentFrom": 7500,
    "rentTo": 16000,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Hot Water",
      "Study Room"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "No smoking",
      "Maintain quiet environment"
    ],
    "images": [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8315,
        18.515
      ]
    },
    "rating": 4.7,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g23-1",
        "hostelId": "hst-g23",
        "roomType": "single",
        "capacity": 1,
        "occupiedBeds": 0,
        "availableBeds": 1,
        "rent": 16000,
        "deposit": 32000,
        "ac": true,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g23-2",
        "hostelId": "hst-g23",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 11500,
        "deposit": 23000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g23-3",
        "hostelId": "hst-g23",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g24",
    "ownerId": "usr-owner-1",
    "name": "Swastik Girls PG",
    "description": "Located in safe residential Ghole Road near Balgandharva bridge. Clean double and triple sharing rooms, high speed fiber broadband, and warden support.",
    "address": "Near Ghole Road Art Gallery, Shivajinagar, Pune 411005",
    "area": "Shivajinagar",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 97631 88992",
    "rentFrom": 6800,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Laundry",
      "Power Backup",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:30 PM",
      "No male visitors inside rooms",
      "Pay rent by 5th"
    ],
    "images": [
      "https://images.unsplash.com/photo-1540518614846-7ede433c4b69?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8475,
        18.5275
      ]
    },
    "rating": 4.5,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g24-1",
        "hostelId": "hst-g24",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10000,
        "deposit": 20000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g24-2",
        "hostelId": "hst-g24",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g24-3",
        "hostelId": "hst-g24",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 6800,
        "deposit": 13600,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  },
  {
    "_id": "hst-g25",
    "ownerId": "usr-owner-2",
    "name": "Ashwini Girls Student PG",
    "description": "Peaceful girls PG near Mayur Colony Ganpati Mandir. Quick metro or bus ride to Fergusson College. Pure vegetarian diet and friendly warden.",
    "address": "Near Mayur Colony Ganpati Mandir, Kothrud, Pune 411038",
    "area": "Kothrud",
    "city": "Pune",
    "gender": "female",
    "hostelType": "pg",
    "phone": "+91 98819 44331",
    "rentFrom": 6500,
    "rentTo": 13500,
    "amenities": [
      "WiFi",
      "Mess / Food",
      "CCTV",
      "Power Backup",
      "Study Room",
      "Hot Water"
    ],
    "rules": [
      "Curfew 9:45 PM",
      "Girls only",
      "Advance monthly rent payments"
    ],
    "images": [
      "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
    ],
    "location": {
      "type": "Point",
      "coordinates": [
        73.8165,
        18.5085
      ]
    },
    "rating": 4.5,
    "reviewCount": 2,
    "verificationStatus": "approved",
    "isDemo": false,
    "rooms": [
      {
        "_id": "rm-g25-1",
        "hostelId": "hst-g25",
        "roomType": "double",
        "capacity": 2,
        "occupiedBeds": 1,
        "availableBeds": 1,
        "rent": 10500,
        "deposit": 21000,
        "ac": false,
        "attachedBathroom": true
      },
      {
        "_id": "rm-g25-2",
        "hostelId": "hst-g25",
        "roomType": "triple",
        "capacity": 3,
        "occupiedBeds": 2,
        "availableBeds": 1,
        "rent": 7500,
        "deposit": 15000,
        "ac": false,
        "attachedBathroom": false
      },
      {
        "_id": "rm-g25-3",
        "hostelId": "hst-g25",
        "roomType": "four",
        "capacity": 4,
        "occupiedBeds": 2,
        "availableBeds": 2,
        "rent": 6500,
        "deposit": 13000,
        "ac": false,
        "attachedBathroom": false
      }
    ]
  }
];

export const initialReviews = [
  {
    _id: 'rev-1',
    hostelId: 'hst-b1',
    studentId: { _id: 'usr-student-1', name: 'Rohan Deshmukh', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 5,
    securityRating: 5,
    comment: 'Apte Road location is unbeatable! Takes 3 minutes to walk to Fergusson College gate #2. Extremely quiet for study and good food.',
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
  {
    _id: 'rev-2',
    hostelId: 'hst-g1',
    studentId: { _id: 'usr-student-2', name: 'Ananya Patil', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 5,
    securityRating: 5,
    comment: 'MyHostelRoom Venus in Model Colony is so peaceful right by Lakaki Lake. Biometric entry feels super safe and study rooms are clean.',
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
  },
  {
    _id: 'rev-3',
    hostelId: 'hst-b2',
    studentId: { _id: 'usr-student-3', name: 'Siddharth Joshi', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 4,
    securityRating: 5,
    comment: 'Phadke Hostel has solid Godrej cupboards and quiet study atmosphere. High occupancy for a reason, truly great place.',
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
  },
  {
    _id: 'rev-4',
    hostelId: 'hst-g2',
    studentId: { _id: 'usr-student-2', name: 'Ananya Patil', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 5,
    securityRating: 5,
    comment: 'Blessing Premium PG near Reliance Centro Deccan is 700m from FC. AC rooms with regular backup. Warden is very responsive.',
    createdAt: new Date(Date.now() - 12 * 86400000).toISOString(),
  },
  {
    _id: 'rev-5',
    hostelId: 'hst-b3',
    studentId: { _id: 'usr-student-1', name: 'Rohan Deshmukh', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 4,
    foodRating: 5,
    securityRating: 5,
    comment: 'Sarang Boys Hostel on FC Road near Kidzee has AC options and budget friendly rates (under 5k). Walking distance to everything.',
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
  },
  {
    _id: 'rev-6',
    hostelId: 'hst-g4',
    studentId: { _id: 'usr-student-2', name: 'Ananya Patil', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 5,
    securityRating: 5,
    comment: 'Youthville SBR is next level luxury for girls! Nutritious meal subscriptions and gym games on SB Road.',
    createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
  },
  {
    _id: 'rev-7',
    hostelId: 'hst-b4',
    studentId: { _id: 'usr-student-3', name: 'Siddharth Joshi', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 4,
    securityRating: 5,
    comment: 'Youthville Shivajinagar near Sancheti Chowk has hotel-level housekeeping and fast laundry. Highly recommended.',
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
  },
  {
    _id: 'rev-8',
    hostelId: 'hst-g5',
    studentId: { _id: 'usr-student-2', name: 'Ananya Patil', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=80&q=80' },
    rating: 5,
    cleanlinessRating: 5,
    foodRating: 4,
    securityRating: 5,
    comment: 'Yash Girls Hostel in Revenue Colony opposite Hotel Bhushan has strict 9:30 PM gate deadline, super safe for girls.',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
];

export const initialEnquiries = [
  {
    _id: 'enq-1',
    hostelId: 'hst-b1',
    studentId: 'usr-student-1',
    ownerId: 'usr-owner-1',
    roomType: 'double',
    moveInDate: new Date(Date.now() + 5 * 86400000).toISOString(),
    durationMonths: 10,
    message: 'Hello, I am a 2nd year BSc student at Fergusson College looking for a double sharing room at Daund PG starting next week.',
    phone: '+91 99221 44556',
    status: 'accepted',
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    _id: 'enq-2',
    hostelId: 'hst-g1',
    studentId: 'usr-student-2',
    ownerId: 'usr-owner-2',
    roomType: 'double',
    moveInDate: new Date(Date.now() + 10 * 86400000).toISOString(),
    durationMonths: 12,
    message: 'Interested in double room at MyHostelRoom Venus. Would like to schedule an in-person room visit this Saturday.',
    phone: '+91 97632 55667',
    status: 'contacted',
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    _id: 'enq-3',
    hostelId: 'hst-b3',
    studentId: 'usr-student-3',
    ownerId: 'usr-owner-1',
    roomType: 'triple',
    moveInDate: new Date(Date.now() + 14 * 86400000).toISOString(),
    durationMonths: 6,
    message: 'Hi, are meals included on weekends as well at Sarang Boys Hostel? Can I reserve a triple sharing bed?',
    phone: '+91 96573 66778',
    status: 'pending',
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
  },
  {
    _id: 'enq-4',
    hostelId: 'hst-g2',
    studentId: 'usr-student-2',
    ownerId: 'usr-owner-2',
    roomType: 'double',
    moveInDate: new Date(Date.now() + 3 * 86400000).toISOString(),
    durationMonths: 10,
    message: 'Looking for immediate occupancy in AC double sharing room at Blessing Premium PG Deccan.',
    phone: '+91 97632 55667',
    status: 'pending',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
];

export const initialFavorites = [
  { _id: 'fav-1', studentId: 'usr-student-1', hostelId: 'hst-b1' },
  { _id: 'fav-2', studentId: 'usr-student-1', hostelId: 'hst-b3' },
  { _id: 'fav-3', studentId: 'usr-student-2', hostelId: 'hst-g1' },
  { _id: 'fav-4', studentId: 'usr-student-2', hostelId: 'hst-g2' },
  { _id: 'fav-5', studentId: 'usr-student-2', hostelId: 'hst-g4' },
  { _id: 'fav-6', studentId: 'usr-student-3', hostelId: 'hst-b2' },
];

export const initialNotifications = [
  {
    _id: 'notif-1',
    userId: 'usr-student-1',
    title: 'Booking Enquiry Accepted! 🎉',
    message: 'Owner Rajesh Kulkarni has accepted your booking enquiry for Daund PG and Hostel for Boys.',
    link: '/enquiries',
    type: 'status_change',
    read: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    _id: 'notif-2',
    userId: 'usr-owner-1',
    title: 'New Student Room Enquiry',
    message: 'Rohan Deshmukh enquired for Daund PG (double room sharing).',
    link: '/dashboard/owner',
    type: 'enquiry',
    read: true,
    createdAt: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    _id: 'notif-3',
    userId: 'usr-admin-1',
    title: 'New Listing Pending Verification',
    message: 'Prabhat Sanskriti Girls PG was submitted by Sunita Deshpande and is awaiting administrative approval.',
    link: '/admin/hostels',
    type: 'hostel_approval',
    read: false,
    createdAt: new Date(Date.now() - 10800000).toISOString(),
  },
];
