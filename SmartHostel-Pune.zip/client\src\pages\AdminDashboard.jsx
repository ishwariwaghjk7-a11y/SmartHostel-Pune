import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  Building2,
  Clock,
  CheckCircle2,
  XCircle,
  MessageSquare,
  ShieldCheck,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import api from '../services/api';
import StatCard from '../components/dashboard/StatCard';
import {
  AreaBarChart,
  GenderPieChart,
  RentRangesChart,
} from '../components/dashboard/AnalyticsCharts';
import { useToast } from '../context/ToastContext';

const AdminDashboard = () => {
  const { showToast } = useToast();
  const [analytics, setAnalytics] = useState(null);
  const [pendingHostels, setPendingHostels] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAdminData();
  }, []);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [analyticsRes, hostelsRes] = await Promise.all([
        api.get('/admin/analytics'),
        api.get('/admin/hostels?status=pending'),
      ]);

      if (analyticsRes.data?.success) setAnalytics(analyticsRes.data);
      if (hostelsRes.data?.success) setPendingHostels(hostelsRes.data.hostels || []);
    } catch (err) {
      showToast('Failed to load admin analytics', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id, status) => {
    try {
      const res = await api.patch(`/admin/hostels/${id}/status`, { status });
      if (res.data?.success) {
        showToast(`Hostel status updated to '${status}'`, 'success');
        setPendingHostels((prev) => prev.filter((h) => h._id !== id));
        fetchAdminData(); // refresh counts
      }
    } catch (err) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  if (loading) {
    return <div className="py-20 text-center text-xs text-slate-400">Loading system analytics...</div>;
  }

  const stats = analytics?.stats || {};
  const charts = analytics?.charts || {};

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
            System Administration
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Pune SmartHostel Analytics & Moderation
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time platform statistics, geospatial distribution, and verification queues.
          </p>
        </div>

        <div className="flex gap-2">
          <Link
            to="/admin/hostels"
            className="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow transition"
          >
            All Hostels ({stats.totalHostels})
          </Link>
          <Link
            to="/admin/users"
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition"
          >
            Users ({stats.totalUsers})
          </Link>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        <StatCard
          title="Total Students"
          value={stats.totalStudents || 0}
          subtitle="Registered accounts"
          icon={Users}
          color="brand"
        />
        <StatCard
          title="Property Owners"
          value={stats.totalOwners || 0}
          subtitle="Registered wardens"
          icon={Building2}
          color="indigo"
        />
        <StatCard
          title="Approved Hostels"
          value={stats.approvedHostels || 0}
          subtitle="Publicly visible"
          icon={ShieldCheck}
          color="emerald"
        />
        <StatCard
          title="Pending Queue"
          value={stats.pendingHostels || 0}
          subtitle="Requires review"
          icon={Clock}
          color="amber"
        />
        <StatCard
          title="Total Enquiries"
          value={stats.totalEnquiries || 0}
          subtitle="Booking submissions"
          icon={MessageSquare}
          color="purple"
        />
      </div>

      {/* Pending Approvals Table */}
      <div className="glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-honey-500" />
              Pending Property Verification Queue
            </h2>
            <p className="text-xs text-slate-500">
              Hostel listings submitted by Pune property owners awaiting administrative verification.
            </p>
          </div>
          <span className="text-xs font-bold text-honey-800 bg-honey-50 px-3 py-1 rounded-full border border-honey-200">
            {pendingHostels.length} Pending
          </span>
        </div>

        {pendingHostels.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400 bg-pastel-canvas/60 rounded-2xl border border-brand-100/60">
            No pending hostels in queue. All submissions have been moderated.
          </div>
        ) : (
          <div className="divide-y divide-brand-100/50">
            {pendingHostels.map((h) => (
              <div
                key={h._id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-extrabold text-sm text-slate-900">{h.name}</h4>
                    <span className="bg-honey-50 text-honey-800 border border-honey-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                      Awaiting Verification
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {h.address} • Area: {h.area} • Owner: {h.ownerId?.name || 'Owner'} ({h.phone})
                  </p>
                  <p className="text-xs text-brand-700 font-bold">
                    Rent Range: ₹{h.rentFrom?.toLocaleString('en-IN')} - ₹{h.rentTo?.toLocaleString('en-IN')}/mo
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleUpdateStatus(h._id, 'approved')}
                    className="px-4 py-2 bg-mint-600 hover:bg-mint-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Approve
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(h._id, 'rejected')}
                    className="px-4 py-2 bg-blush-500 hover:bg-blush-600 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition flex items-center gap-1.5"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recharts Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Hostels by Area */}
        <div className="glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-3">
          <h3 className="font-bold text-sm text-slate-900">Hostels by Pune Hub</h3>
          <p className="text-xs text-slate-400">Distribution across Fergusson & nearby student zones</p>
          <AreaBarChart data={charts.hostelsByArea || []} />
        </div>

        {/* Chart 2: Gender Demographic */}
        <div className="glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-3">
          <h3 className="font-bold text-sm text-slate-900">Gender Policy Breakdown</h3>
          <p className="text-xs text-slate-400">Boys vs Girls vs Co-ed Stays</p>
          <GenderPieChart data={charts.hostelsByGender || []} />
        </div>

        {/* Chart 3: Rent Ranges Distribution */}
        <div className="glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-3">
          <h3 className="font-bold text-sm text-slate-900">Monthly Rent Distribution</h3>
          <p className="text-xs text-slate-400">Budget tier segmentation (INR/month)</p>
          <RentRangesChart data={charts.rentRanges || []} />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
