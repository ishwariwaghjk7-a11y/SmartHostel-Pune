import React, { useState, useEffect } from 'react';
import {
  Building2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Search,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';
import { Link } from 'react-router-dom';

const AdminHostelsPage = () => {
  const { showToast } = useToast();
  const [hostels, setHostels] = useState([]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchHostels();
  }, [statusFilter, searchTerm]);

  const fetchHostels = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'all') params.append('status', statusFilter);
      if (searchTerm) params.append('search', searchTerm);

      const res = await api.get(`/admin/hostels?${params.toString()}`);
      if (res.data?.success) {
        setHostels(res.data.hostels || []);
      }
    } catch (err) {
      showToast('Failed to load hostels list', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      const res = await api.patch(`/admin/hostels/${id}/status`, { status: newStatus });
      if (res.data?.success) {
        showToast(`Hostel status set to ${newStatus}`, 'success');
        setHostels((prev) =>
          prev.map((h) => (h._id === id ? { ...h, verificationStatus: newStatus } : h))
        );
      }
    } catch (err) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Hostels Moderation & Verification
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Review and moderate all registered accommodation properties in Pune.
          </p>
        </div>
        <span className="text-xs font-bold bg-brand-50 text-brand-700 px-3 py-1.5 rounded-xl border border-brand-200">
          {hostels.length} Properties Found
        </span>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-card flex flex-col sm:flex-row items-center gap-3 p-4 rounded-2xl border border-brand-100/70 shadow-soft text-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by name, locality, address..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white/80 border border-brand-100 rounded-xl shadow-2xs focus:outline-none focus:ring-2 focus:ring-brand-400 font-semibold"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full sm:w-auto">
          <span className="text-slate-500 font-semibold">Filter:</span>
          {['all', 'pending', 'approved', 'rejected', 'suspended'].map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-2 rounded-xl font-bold capitalize transition ${
                statusFilter === status
                  ? 'bg-brand-600 text-white shadow-soft'
                  : 'bg-white/80 text-slate-600 hover:bg-brand-50/60 border border-brand-100/60'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Hostels Table */}
      {loading ? (
        <div className="py-20 text-center text-xs text-slate-400">Loading properties...</div>
      ) : hostels.length === 0 ? (
        <div className="glass-card rounded-3xl p-12 text-center border border-brand-100 shadow-soft text-xs text-slate-400">
          No hostels found matching current criteria.
        </div>
      ) : (
        <div className="glass-card rounded-3xl border border-brand-100/70 overflow-hidden shadow-soft">
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-pastel-canvas/70 text-slate-500 uppercase tracking-wider text-[10px] border-b border-brand-100/60">
                <tr>
                  <th className="p-4">Property</th>
                  <th className="p-4">Area & City</th>
                  <th className="p-4">Owner Contact</th>
                  <th className="p-4">Rent Range</th>
                  <th className="p-4">Current Status</th>
                  <th className="p-4">Moderation Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-100/50">
                {hostels.map((hostel) => (
                  <tr key={hostel._id} className="hover:bg-brand-50/30 transition">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={hostel.images?.[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=120&q=80'}
                          alt={hostel.name}
                          className="w-12 h-12 rounded-xl object-cover border border-brand-100 shadow-2xs"
                        />
                        <div>
                          <div className="font-extrabold text-slate-900 flex items-center gap-1.5">
                            <Link
                              to={`/hostels/${hostel._id}`}
                              className="hover:text-brand-600 flex items-center gap-1"
                            >
                              {hostel.name}
                              <ExternalLink className="w-3 h-3 text-slate-400" />
                            </Link>
                          </div>
                          <span className="text-[10px] text-slate-400 capitalize">
                            {hostel.gender} • {hostel.hostelType}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="p-4 text-slate-700 font-semibold">{hostel.area}</td>

                    <td className="p-4">
                      <div className="font-semibold text-slate-800">{hostel.ownerId?.name || 'Owner'}</div>
                      <div className="text-slate-400 text-[11px]">{hostel.phone}</div>
                    </td>

                    <td className="p-4 font-black text-brand-700">
                      ₹{hostel.rentFrom?.toLocaleString('en-IN')} - ₹{hostel.rentTo?.toLocaleString('en-IN')}
                    </td>

                    <td className="p-4">
                      <span
                        className={`font-bold px-2.5 py-1 rounded-full capitalize text-[10px] border ${
                          hostel.verificationStatus === 'approved'
                            ? 'bg-mint-50 text-mint-700 border-mint-200'
                            : hostel.verificationStatus === 'rejected'
                            ? 'bg-blush-50 text-blush-700 border-blush-200'
                            : hostel.verificationStatus === 'suspended'
                            ? 'bg-slate-100 text-slate-700 border-slate-200'
                            : 'bg-honey-50 text-honey-800 border-honey-200'
                        }`}
                      >
                        {hostel.verificationStatus}
                      </span>
                    </td>

                    <td className="p-4">
                      <select
                        value={hostel.verificationStatus}
                        onChange={(e) => handleStatusChange(hostel._id, e.target.value)}
                        className="bg-white border border-brand-200 rounded-lg p-1.5 font-bold text-slate-800 shadow-2xs focus:outline-none focus:ring-2 focus:ring-brand-400"
                      >
                        <option value="pending">Pending</option>
                        <option value="approved">Approve</option>
                        <option value="rejected">Reject</option>
                        <option value="suspended">Suspend</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminHostelsPage;
