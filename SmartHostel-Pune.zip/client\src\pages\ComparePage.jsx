import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Layers,
  X,
  Plus,
  Check,
  Minus,
  Star,
  MapPin,
  ExternalLink,
  Building2,
  Bed,
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const AMENITIES_TO_COMPARE = [
  'WiFi',
  'Mess / Food',
  'CCTV',
  'Laundry',
  'Power Backup',
  'Gym',
  'Study Room',
  'Hot Water',
  'Biometric Entry',
];

const ComparePage = () => {
  const { showToast } = useToast();
  const [comparedHostels, setComparedHostels] = useState([]);
  const [allHostels, setAllHostels] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    setLoading(true);
    try {
      const res = await api.get('/hostels?limit=30');
      if (res.data?.success) {
        setAllHostels(res.data.hostels || []);

        // Load persisted comparisons or default to first 2-3
        const saved = localStorage.getItem('smarthostel_compare');
        if (saved) {
          try {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setComparedHostels(parsed);
              setLoading(false);
              return;
            }
          } catch {
            // fallback
          }
        }

        // Default comparison if empty
        if (res.data.hostels.length >= 2) {
          const defaults = res.data.hostels.slice(0, 3);
          setComparedHostels(defaults);
          localStorage.setItem('smarthostel_compare', JSON.stringify(defaults));
        }
      }
    } catch (err) {
      showToast('Failed to load hostels for comparison', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveHostel = (id) => {
    const updated = comparedHostels.filter((h) => h._id !== id);
    setComparedHostels(updated);
    localStorage.setItem('smarthostel_compare', JSON.stringify(updated));
  };

  const handleAddHostel = (hostelId) => {
    if (comparedHostels.length >= 3) {
      showToast('Maximum 3 hostels can be compared side-by-side', 'warning');
      return;
    }
    const found = allHostels.find((h) => h._id === hostelId);
    if (found && !comparedHostels.some((h) => h._id === found._id)) {
      const updated = [...comparedHostels, found];
      setComparedHostels(updated);
      localStorage.setItem('smarthostel_compare', JSON.stringify(updated));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-brand-100">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-50 text-brand-700 border border-brand-200/80 text-xs font-bold uppercase tracking-wider mb-2">
            <Layers className="w-3.5 h-3.5 text-brand-600" />
            Side-by-Side Analysis
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Objective Pune Hostel Comparison
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Neutral evaluation of student stays near Fergusson College across rent, deposits, safety, and amenities.
          </p>
        </div>

        {/* Add Hostel Dropdown */}
        {comparedHostels.length < 3 && (
          <div className="flex items-center gap-2">
            <select
              onChange={(e) => {
                if (e.target.value) handleAddHostel(e.target.value);
                e.target.value = '';
              }}
              defaultValue=""
              className="bg-white border border-brand-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-700 shadow-soft focus:outline-none focus:ring-2 focus:ring-brand-400"
            >
              <option value="" disabled>+ Add hostel to comparison...</option>
              {allHostels
                .filter((h) => !comparedHostels.some((ch) => ch._id === h._id))
                .map((h) => (
                  <option key={h._id} value={h._id}>
                    {h.name} ({h.area} - ₹{h.rentFrom}/mo)
                  </option>
                ))}
            </select>
          </div>
        )}
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-xs">
          Loading comparison data...
        </div>
      ) : comparedHostels.length === 0 ? (
        <div className="glass-card rounded-3xl p-12 text-center border border-brand-100 shadow-soft space-y-4 max-w-md mx-auto">
          <Layers className="w-12 h-12 text-brand-300 mx-auto" />
          <h3 className="font-bold text-base text-slate-800">No Hostels Selected</h3>
          <p className="text-xs text-slate-500">
            Select hostels from the search page or use the dropdown above to start comparing.
          </p>
          <Link
            to="/search"
            className="inline-block px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition"
          >
            Explore Accommodations
          </Link>
        </div>
      ) : (
        /* Comparison Table */
        <div className="glass-card rounded-3xl border border-brand-100/70 overflow-x-auto shadow-soft">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-brand-100 bg-pastel-canvas/80 backdrop-blur-sm">
                <th className="p-4 w-48 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                  Feature Matrix
                </th>
                {comparedHostels.map((hostel) => (
                  <th key={hostel._id} className="p-4 w-64 min-w-[220px] align-top">
                    <div className="relative space-y-2">
                      <button
                        onClick={() => handleRemoveHostel(hostel._id)}
                        className="absolute -top-1 -right-1 p-1 bg-white hover:bg-blush-50 text-slate-400 hover:text-blush-600 rounded-full border border-slate-200 shadow-sm transition"
                        title="Remove from comparison"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>

                      <img
                        src={hostel.images?.[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=80'}
                        alt={hostel.name}
                        className="w-full h-32 object-cover rounded-xl border border-brand-100 shadow-2xs"
                      />

                      <h4 className="font-extrabold text-sm text-slate-900 line-clamp-1">
                        {hostel.name}
                      </h4>

                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-medium text-slate-500">{hostel.area}</span>
                        <span className="flex items-center text-honey-800 bg-honey-50 border border-honey-200 px-2 py-0.5 rounded-full font-bold">
                          <Star className="w-3 h-3 fill-honey-400 text-honey-400 mr-0.5" />
                          {hostel.rating > 0 ? hostel.rating.toFixed(1) : 'New'}
                        </span>
                      </div>

                      <Link
                        to={`/hostels/${hostel._id}`}
                        className="inline-flex items-center justify-center gap-1.5 w-full py-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-[11px] rounded-xl shadow-soft hover:shadow-soft-hover transition"
                      >
                        View Details
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>

            <tbody className="divide-y divide-brand-100/50 font-medium text-slate-700">
              {/* Distance from Reference College */}
              <tr>
                <td className="p-4 bg-pastel-canvas/40 font-bold text-slate-900">
                  Distance from Fergusson College
                </td>
                {comparedHostels.map((h) => (
                  <td key={h._id} className="p-4 font-bold text-brand-700">
                    {h.distanceKm !== undefined ? `${h.distanceKm} km from Gate` : 'Near Fergusson (~0.4 km)'}
                  </td>
                ))}
              </tr>

              {/* Monthly Rent */}
              <tr>
                <td className="p-4 bg-pastel-canvas/40 font-bold text-slate-900">Monthly Rent Range</td>
                {comparedHostels.map((h) => (
                  <td key={h._id} className="p-4 font-extrabold text-slate-900 text-sm">
                    ₹{h.rentFrom?.toLocaleString('en-IN')} - ₹{h.rentTo?.toLocaleString('en-IN')}
                    <span className="text-[10px] font-normal text-slate-500 block">per bed/month</span>
                  </td>
                ))}
              </tr>

              {/* Security Deposit */}
              <tr>
                <td className="p-4 bg-pastel-canvas/40 font-bold text-slate-900">Security Deposit</td>
                {comparedHostels.map((h) => (
                  <td key={h._id} className="p-4 text-slate-600">
                    ₹{((h.rentFrom || 7000) * 2).toLocaleString('en-IN')} (approx 2 months)
                  </td>
                ))}
              </tr>

              {/* Gender Policy */}
              <tr>
                <td className="p-4 bg-pastel-canvas/40 font-bold text-slate-900">Gender Policy</td>
                {comparedHostels.map((h) => (
                  <td key={h._id} className="p-4">
                    <span className="inline-block bg-brand-50 text-brand-700 border border-brand-200/80 px-2.5 py-0.5 rounded-full capitalize text-[11px] font-bold">
                      {h.gender} Stay
                    </span>
                  </td>
                ))}
              </tr>

              {/* Total Available Beds */}
              <tr>
                <td className="p-4 bg-pastel-canvas/40 font-bold text-slate-900">Current Available Beds</td>
                {comparedHostels.map((h) => {
                  const beds = (h.rooms || []).reduce(
                    (acc, r) => acc + (r.availableBeds ?? (r.capacity - (r.occupiedBeds || 0))),
                    0
                  );
                  return (
                    <td key={h._id} className="p-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border ${
                        beds > 0 ? 'bg-mint-50 text-mint-700 border-mint-200' : 'bg-blush-50 text-blush-700 border-blush-200'
                      }`}>
                        <Bed className="w-3.5 h-3.5" />
                        {beds > 0 ? `${beds} beds open` : 'Waitlist only'}
                      </span>
                    </td>
                  );
                })}
              </tr>

              {/* Room Types Provided */}
              <tr>
                <td className="p-4 bg-pastel-canvas/40 font-bold text-slate-900">Room Configurations</td>
                {comparedHostels.map((h) => (
                  <td key={h._id} className="p-4 space-y-1">
                    {(h.rooms || []).map((r, i) => (
                      <div key={i} className="text-xs text-slate-600 capitalize">
                        • {r.roomType} Sharing (₹{r.rent?.toLocaleString('en-IN')})
                      </div>
                    ))}
                  </td>
                ))}
              </tr>

              {/* Amenities Comparison Rows */}
              {AMENITIES_TO_COMPARE.map((amenity) => (
                <tr key={amenity}>
                  <td className="p-4 bg-pastel-canvas/40 font-medium text-slate-600">{amenity}</td>
                  {comparedHostels.map((h) => {
                    const hasAmenity = (h.amenities || []).some(
                      (a) => a.toLowerCase() === amenity.toLowerCase()
                    );
                    return (
                      <td key={h._id} className="p-4">
                        {hasAmenity ? (
                          <span className="inline-flex items-center gap-1 bg-mint-50 text-mint-700 border border-mint-200/80 px-2.5 py-0.5 rounded-full text-[11px] font-bold">
                            <Check className="w-3.5 h-3.5 text-mint-600" />
                            Included
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-slate-50 text-slate-400 border border-slate-200 px-2.5 py-0.5 rounded-full text-[11px]">
                            <Minus className="w-3.5 h-3.5" />
                            No
                          </span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ComparePage;
