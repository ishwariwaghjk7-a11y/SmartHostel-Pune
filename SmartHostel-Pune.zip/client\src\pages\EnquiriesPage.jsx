import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Calendar, Phone, Mail, Building2, CheckCircle2, Clock, XCircle, ArrowRight } from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const EnquiriesPage = () => {
  const { showToast } = useToast();
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEnquiries();
  }, []);

  const fetchEnquiries = async () => {
    setLoading(true);
    try {
      const res = await api.get('/enquiries/student');
      if (res.data?.success) {
        setEnquiries(res.data.enquiries || []);
      }
    } catch (err) {
      showToast('Failed to load enquiries', 'error');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'accepted':
        return (
          <span className="inline-flex items-center gap-1.5 bg-mint-50 text-mint-700 border border-mint-200 text-xs font-bold px-3 py-1 rounded-full shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-mint-600" />
            Accepted
          </span>
        );
      case 'contacted':
        return (
          <span className="inline-flex items-center gap-1.5 bg-brand-50 text-brand-700 border border-brand-200 text-xs font-bold px-3 py-1 rounded-full shadow-2xs">
            <Clock className="w-3.5 h-3.5 text-brand-600" />
            Owner Contacted
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 bg-blush-50 text-blush-700 border border-blush-200 text-xs font-bold px-3 py-1 rounded-full shadow-2xs">
            <XCircle className="w-3.5 h-3.5 text-blush-600" />
            Declined
          </span>
        );
      case 'closed':
        return (
          <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold px-3 py-1 rounded-full">
            Closed
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 bg-honey-50 text-honey-800 border border-honey-200 text-xs font-bold px-3 py-1 rounded-full shadow-2xs">
            <Clock className="w-3.5 h-3.5 text-honey-600" />
            Pending Review
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-brand-100">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            My Enquiries & Bookings
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Track inquiries sent to Pune hostel wardens and accommodation managers
          </p>
        </div>
        <span className="text-xs font-bold bg-brand-50 text-brand-700 px-3 py-1.5 rounded-full border border-brand-200/80 shadow-2xs">
          {enquiries.length} Enquiries
        </span>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-xs">Loading enquiries...</div>
      ) : enquiries.length === 0 ? (
        <div className="glass-card rounded-3xl p-12 text-center border border-brand-100 shadow-soft space-y-4 max-w-md mx-auto">
          <MessageSquare className="w-12 h-12 text-brand-300 mx-auto" />
          <h3 className="font-bold text-base text-slate-800">No Enquiries Sent</h3>
          <p className="text-xs text-slate-500">
            When you enquire about a room from any hostel page, the status will appear here.
          </p>
          <Link
            to="/search"
            className="inline-block px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition"
          >
            Explore Accommodations
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {enquiries.map((enq) => {
            const hostel = enq.hostelId;
            const owner = enq.ownerId;

            return (
              <div
                key={enq._id}
                className="glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-4 hover:shadow-soft-hover transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-brand-100/50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-brand-50 text-brand-600 border border-brand-200/70 flex items-center justify-center font-bold shadow-2xs">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-slate-900">
                        {hostel?.name || 'Hostel Accommodation'}
                      </h3>
                      <p className="text-xs text-slate-500">{hostel?.area || 'Pune'}</p>
                    </div>
                  </div>

                  <div>{getStatusBadge(enq.status)}</div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-pastel-canvas/60 p-3.5 rounded-2xl border border-brand-100/60">
                  <div>
                    <span className="text-slate-400 block font-medium">Room Requested</span>
                    <span className="font-bold text-slate-800 capitalize">{enq.roomType} Sharing</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Target Move-In</span>
                    <span className="font-bold text-slate-800">
                      {new Date(enq.moveInDate).toLocaleDateString()} ({enq.durationMonths} mos)
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block font-medium">Submitted On</span>
                    <span className="font-bold text-slate-800">
                      {new Date(enq.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 italic bg-white/70 p-3 rounded-xl border border-brand-100/60 leading-relaxed">
                  "{enq.message}"
                </p>

                {/* Owner info banner if accepted or contacted */}
                {(enq.status === 'accepted' || enq.status === 'contacted') && owner && (
                  <div className="p-3 bg-mint-50/80 rounded-2xl border border-mint-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2 text-mint-900 font-semibold">
                      <span>Owner: {owner.name}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1 font-bold">
                        <Phone className="w-3.5 h-3.5 text-mint-700" />
                        {owner.phone || '+91 98501 22334'}
                      </span>
                    </div>
                    <span className="text-[11px] text-mint-700 font-medium">
                      You can call the owner directly to schedule a room visit
                    </span>
                  </div>
                )}

                <div className="flex justify-end pt-1">
                  {hostel && (
                    <Link
                      to={`/hostels/${hostel._id}`}
                      className="inline-flex items-center gap-1 text-xs font-bold text-brand-600 hover:text-brand-800"
                    >
                      View Hostel Page
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default EnquiriesPage;
