import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Trash2, ExternalLink, Bed, Star, MapPin } from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const FavoritesPage = () => {
  const { showToast } = useToast();
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFavorites();
  }, []);

  const fetchFavorites = async () => {
    setLoading(true);
    try {
      const res = await api.get('/favorites');
      if (res.data?.success) {
        setFavorites(res.data.favorites || []);
      }
    } catch (err) {
      showToast('Failed to load saved favorites', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (hostelId) => {
    try {
      await api.delete(`/favorites/${hostelId}`);
      setFavorites((prev) => prev.filter((f) => f.hostelId?._id !== hostelId && f.hostelId !== hostelId));
      showToast('Removed from saved hostels', 'info');
    } catch (err) {
      showToast('Failed to remove favorite', 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Saved Hostels & PGs
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Keep track of your shortlisted student accommodations in Pune
          </p>
        </div>
        <span className="text-xs font-bold bg-brand-50 text-brand-700 px-3 py-1.5 rounded-xl border border-brand-200">
          {favorites.length} Saved
        </span>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400 text-xs">Loading favorites...</div>
      ) : favorites.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-4 max-w-md mx-auto">
          <Heart className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-bold text-base text-slate-800">No Saved Hostels Yet</h3>
          <p className="text-xs text-slate-500">
            Click the heart icon on any hostel card to save it here for easy access.
          </p>
          <Link
            to="/search"
            className="inline-block px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow-sm transition"
          >
            Explore Accommodations
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favorites.map((fav) => {
            const hostel = fav.hostelId;
            if (!hostel) return null;

            return (
              <div
                key={fav._id}
                className="glass-card rounded-3xl border border-brand-100/70 overflow-hidden shadow-soft hover:shadow-soft-hover transition flex flex-col justify-between"
              >
                <div className="relative h-44 bg-slate-100">
                  <img
                    src={hostel.images?.[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=500&q=80'}
                    alt={hostel.name}
                    className="w-full h-full object-cover"
                  />
                  <button
                    onClick={() => handleRemove(hostel._id)}
                    className="absolute top-3 right-3 p-2 bg-white/90 hover:bg-white text-blush-500 rounded-full shadow-soft hover:shadow-soft-hover transition"
                    title="Remove from saved"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <div className="absolute bottom-3 left-3 bg-slate-900/60 backdrop-blur-md px-2.5 py-1 rounded-xl text-white text-xs font-semibold flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-blush-400" />
                    <span>{hostel.area}</span>
                  </div>
                </div>

                <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900 line-clamp-1 mb-1">
                      {hostel.name}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{hostel.description}</p>
                  </div>

                  <div className="pt-3 border-t border-brand-100/60 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-medium">
                        Monthly Rent
                      </span>
                      <span className="text-sm font-black text-brand-700">
                        ₹{hostel.rentFrom?.toLocaleString('en-IN')}<span className="text-xs font-normal text-slate-500">/mo</span>
                      </span>
                    </div>

                    <Link
                      to={`/hostels/${hostel._id}`}
                      className="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition flex items-center gap-1.5"
                    >
                      View Details
                      <ExternalLink className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default FavoritesPage;
