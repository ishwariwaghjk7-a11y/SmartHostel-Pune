import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Star,
  MapPin,
  CheckCircle,
  Heart,
  Layers,
  Bed,
  Share2,
  Navigation,
  ShieldCheck,
  Sparkles,
  Wifi,
  Utensils,
  Camera,
  Car,
  Zap,
  Dumbbell,
  BookOpen,
  Droplet,
  Fingerprint,
  Phone,
  Mail,
  User,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';
import api from '../services/api';
import MapView from '../components/map/MapView';
import EnquiryModal from '../components/hostel/EnquiryModal';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

const AMENITY_ICONS = {
  WiFi: Wifi,
  'Mess / Food': Utensils,
  CCTV: Camera,
  Laundry: Zap,
  'Power Backup': Zap,
  Gym: Dumbbell,
  'Study Room': BookOpen,
  'Hot Water': Droplet,
  'Biometric Entry': Fingerprint,
};

const HostelDetailPage = () => {
  const { id } = useParams();
  const { user, isAuthenticated } = useAuth();
  const { showToast } = useToast();

  const [hostel, setHostel] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isEnquiryOpen, setIsEnquiryOpen] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  // New review form state
  const [reviewRating, setReviewRating] = useState(5);
  const [cleanlinessRating, setCleanlinessRating] = useState(5);
  const [foodRating, setFoodRating] = useState(4);
  const [securityRating, setSecurityRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    fetchHostelDetails();
    fetchReviews();
    checkIfFavorite();
  }, [id]);

  const fetchHostelDetails = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/hostels/${id}`);
      if (res.data?.success) {
        setHostel(res.data.hostel);
      }
    } catch (err) {
      showToast(err.message || 'Failed to fetch hostel details', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async () => {
    try {
      const res = await api.get(`/reviews/hostel/${id}`);
      if (res.data?.success) {
        setReviews(res.data.reviews || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const checkIfFavorite = async () => {
    if (!isAuthenticated || user?.role !== 'student') return;
    try {
      const res = await api.get('/favorites');
      if (res.data?.success) {
        const exists = (res.data.favorites || []).some(
          (f) => f.hostelId?._id === id || f.hostelId === id
        );
        setIsFavorite(exists);
      }
    } catch (err) {
      // Ignore favorite check error
    }
  };

  const handleToggleFavorite = async () => {
    if (!isAuthenticated) {
      showToast('Please sign in as a student to save favorites', 'warning');
      return;
    }
    if (user?.role !== 'student') {
      showToast('Only students can save favorites', 'info');
      return;
    }

    try {
      const res = await api.post(`/favorites/${id}`);
      if (res.data?.success) {
        setIsFavorite(res.data.isFavorited);
        showToast(res.data.message, 'success');
      }
    } catch (err) {
      showToast(err.message || 'Failed to update favorites', 'error');
    }
  };

  const handleAddReview = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) {
      showToast('Please sign in as a student to submit a review', 'warning');
      return;
    }
    if (user?.role !== 'student') {
      showToast('Only students who have stayed here can review', 'info');
      return;
    }
    if (!reviewComment.trim()) {
      showToast('Please provide your review feedback comment', 'error');
      return;
    }

    setSubmittingReview(true);
    try {
      const res = await api.post(`/reviews/hostel/${id}`, {
        rating: reviewRating,
        cleanlinessRating,
        foodRating,
        securityRating,
        comment: reviewComment,
      });

      if (res.data?.success) {
        showToast('Review submitted successfully!', 'success');
        setReviews([res.data.review, ...reviews]);
        setReviewComment('');
        fetchHostelDetails(); // refresh average rating
      }
    } catch (err) {
      showToast(err.message || 'Could not submit review', 'error');
    } finally {
      setSubmittingReview(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center">
        <div className="w-10 h-10 border-4 border-brand-200 border-t-brand-600 rounded-full animate-spin mb-4" />
        <p className="text-sm font-medium text-slate-500">Loading hostel details...</p>
      </div>
    );
  }

  if (!hostel) {
    return (
      <div className="max-w-2xl mx-auto py-20 px-4 text-center">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Hostel Not Found</h2>
        <p className="text-xs text-slate-500 mb-6">The listing you requested could not be located.</p>
        <Link to="/search" className="px-5 py-2.5 bg-brand-600 text-white rounded-xl font-bold text-xs">
          Back to Search
        </Link>
      </div>
    );
  }

  const lat = hostel.location?.coordinates?.[1] || 18.5236;
  const lng = hostel.location?.coordinates?.[0] || 73.8415;
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;

  const images = hostel.images && hostel.images.length > 0 ? hostel.images : [
    'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=1200&q=80',
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Title & Badges Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            {hostel.verificationStatus === 'approved' && (
              <span className="inline-flex items-center gap-1.5 bg-mint-50 text-mint-700 border border-mint-200/80 text-xs font-bold px-3 py-1 rounded-full shadow-2xs">
                <CheckCircle className="w-3.5 h-3.5 text-mint-600" />
                Verified Pune Student Living
              </span>
            )}
            <span className="inline-block bg-brand-50 text-brand-700 border border-brand-200/80 text-xs font-bold px-3 py-1 rounded-full capitalize">
              {hostel.gender} Accommodation
            </span>
            <span className="inline-block bg-honey-50 text-honey-800 border border-honey-200/80 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              {hostel.hostelType}
            </span>
            {hostel.distanceKm !== undefined && (
              <span className="inline-flex items-center gap-1 bg-pastel-canvas text-brand-800 border border-brand-200/70 text-xs font-semibold px-2.5 py-1 rounded-full">
                <Navigation className="w-3 h-3 text-brand-600" />
                {hostel.distanceKm} km from Fergusson College
              </span>
            )}
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {hostel.name}
          </h1>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
            <span className="flex items-center gap-1.5 font-medium">
              <MapPin className="w-4 h-4 text-blush-500" />
              {hostel.address}
            </span>
            <span className="flex items-center gap-1.5 text-honey-800 font-bold bg-honey-50/80 border border-honey-200/60 px-2.5 py-0.5 rounded-full">
              <Star className="w-3.5 h-3.5 fill-honey-400 text-honey-400" />
              {hostel.rating > 0 ? hostel.rating.toFixed(1) : 'New'} ({hostel.reviewCount} student reviews)
            </span>
          </div>
        </div>

        {/* Top CTA buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleToggleFavorite}
            className={`p-3 rounded-2xl border transition flex items-center gap-1.5 text-xs font-bold shadow-soft ${
              isFavorite
                ? 'bg-blush-50 border-blush-200 text-blush-600'
                : 'bg-white/80 backdrop-blur-sm border-brand-100 text-slate-700 hover:bg-brand-50/50'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-blush-500 text-blush-500' : 'text-slate-400'}`} />
            {isFavorite ? 'Saved' : 'Save'}
          </button>

          <a
            href={directionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-3 rounded-2xl border border-brand-100 bg-white/80 backdrop-blur-sm hover:bg-brand-50/50 text-slate-700 transition flex items-center gap-1.5 text-xs font-bold shadow-soft"
          >
            <Navigation className="w-4 h-4 text-brand-600" />
            Get Directions
          </a>

          <button
            onClick={() => setIsEnquiryOpen(true)}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-700 hover:to-indigo-700 text-white font-bold text-xs shadow-soft hover:shadow-soft-hover transition flex items-center gap-2"
          >
            <MessageSquare className="w-4 h-4" />
            Enquire Now
          </button>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 rounded-3xl overflow-hidden shadow-sm border border-slate-200 bg-slate-100 p-2">
        <div className="md:col-span-3 h-80 sm:h-96 rounded-2xl overflow-hidden relative">
          <img
            src={images[activeImageIndex] || images[0]}
            alt={hostel.name}
            className="w-full h-full object-cover transition duration-300"
          />
        </div>
        <div className="md:col-span-1 flex md:flex-col gap-2 overflow-x-auto md:overflow-y-auto max-h-96">
          {images.map((img, idx) => (
            <button
              key={idx}
              onClick={() => setActiveImageIndex(idx)}
              className={`h-20 md:h-28 w-28 md:w-full rounded-xl overflow-hidden flex-shrink-0 border-2 transition ${
                activeImageIndex === idx ? 'border-brand-600 shadow-md' : 'border-transparent opacity-70 hover:opacity-100'
              }`}
            >
              <img src={img} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Layout (2 Columns) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Details, Rooms, Amenities, Rules, Reviews */}
        <div className="lg:col-span-2 space-y-8">
          {/* About Section */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-brand-100/70 shadow-soft space-y-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-brand-600" />
              About this Accommodation
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
              {hostel.description}
            </p>
          </div>

          {/* Room Availability Inventory */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-brand-100/70 shadow-soft space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Bed className="w-5 h-5 text-brand-600" />
                  Room Types & Live Vacancies
                </h2>
                <p className="text-xs text-slate-500">Live bed availability managed directly by property warden</p>
              </div>
            </div>

            <div className="space-y-3">
              {(hostel.rooms || []).map((room) => {
                const availableBeds =
                  room.availableBeds !== undefined
                    ? room.availableBeds
                    : Math.max(0, room.capacity - (room.occupiedBeds || 0));

                return (
                  <div
                    key={room._id}
                    className="p-4 rounded-2xl border border-brand-100/70 hover:border-brand-300 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white/70 backdrop-blur-sm"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900 capitalize">
                          {room.roomType} Sharing
                        </span>
                        {room.ac && (
                          <span className="bg-sky-50 text-sky-700 border border-sky-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                            AC Room
                          </span>
                        )}
                        {room.attachedBathroom && (
                          <span className="bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                            Attached Bath
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">
                        Total Capacity: {room.capacity} beds • Security Deposit: ₹{room.deposit?.toLocaleString('en-IN')}
                      </p>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-6">
                      <div className="text-left sm:text-right">
                        <div className="text-base font-black text-brand-700">
                          ₹{room.rent?.toLocaleString('en-IN')}<span className="text-xs font-normal text-slate-500">/mo</span>
                        </div>
                        <span
                          className={`inline-block text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                            availableBeds > 0
                              ? 'bg-mint-50 text-mint-700 border-mint-200'
                              : 'bg-blush-50 text-blush-700 border-blush-200'
                          }`}
                        >
                          {availableBeds > 0 ? `${availableBeds} beds available` : 'Full / Waitlist'}
                        </span>
                      </div>

                      <button
                        onClick={() => setIsEnquiryOpen(true)}
                        className="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition"
                      >
                        Enquire
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Amenities Grid */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-brand-100/70 shadow-soft space-y-5">
            <h2 className="text-lg font-bold text-slate-900">Amenities & Living Conveniences</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {(hostel.amenities || []).map((amenity, idx) => {
                const IconComponent = AMENITY_ICONS[amenity] || CheckCircle;
                return (
                  <div
                    key={idx}
                    className="flex items-center gap-2.5 p-3 rounded-xl bg-white/70 border border-brand-100/60 text-xs font-semibold text-slate-800 hover:bg-brand-50/40 transition shadow-2xs"
                  >
                    <IconComponent className="w-4 h-4 text-brand-600 flex-shrink-0" />
                    <span>{amenity}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* House Rules */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-brand-100/70 shadow-soft space-y-4">
            <h2 className="text-lg font-bold text-slate-900">House Rules & Safety Policies</h2>
            <ul className="space-y-2 text-xs text-slate-600">
              {(hostel.rules || []).map((rule, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-brand-500 mt-1.5 flex-shrink-0" />
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Reviews & Ratings Section */}
          <div className="glass-card rounded-3xl p-6 sm:p-8 border border-brand-100/70 shadow-soft space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-brand-100/60 gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Student Reviews & Ratings</h2>
                <p className="text-xs text-slate-500">Verified resident feedback from Fergusson / SPPU students</p>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="text-2xl font-black text-honey-600 flex items-center gap-1 justify-end">
                    <Star className="w-6 h-6 fill-honey-400 text-honey-400" />
                    {hostel.rating > 0 ? hostel.rating.toFixed(1) : 'New'}
                  </div>
                  <span className="text-[11px] text-slate-400 font-medium">
                    {hostel.reviewCount} verified reviews
                  </span>
                </div>
              </div>
            </div>

            {/* Sub-rating breakdown meters */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-pastel-canvas/60 border border-brand-100/60">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span>Cleanliness</span>
                  <span className="text-brand-600 font-bold">4.6★</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-mint-500 rounded-full" style={{ width: '92%' }} />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span>Food & Mess</span>
                  <span className="text-brand-600 font-bold">4.3★</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-honey-500 rounded-full" style={{ width: '86%' }} />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-slate-700">
                  <span>Security & Warden</span>
                  <span className="text-brand-600 font-bold">4.8★</span>
                </div>
                <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-brand-500 rounded-full" style={{ width: '96%' }} />
                </div>
              </div>
            </div>

            {/* Write Review Form */}
            {isAuthenticated && user?.role === 'student' && (
              <form onSubmit={handleAddReview} className="bg-white/80 p-5 rounded-2xl border border-brand-100/80 shadow-soft space-y-4 text-xs">
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-brand-600" />
                  Post Your Student Experience
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-600 mb-1">Overall</label>
                    <select
                      value={reviewRating}
                      onChange={(e) => setReviewRating(Number(e.target.value))}
                      className="w-full bg-white border border-brand-200 rounded-lg p-2 font-bold text-honey-600"
                    >
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>{n} Stars</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 mb-1">Cleanliness</label>
                    <select
                      value={cleanlinessRating}
                      onChange={(e) => setCleanlinessRating(Number(e.target.value))}
                      className="w-full bg-white border border-brand-200 rounded-lg p-2"
                    >
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>{n} Stars</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 mb-1">Food / Mess</label>
                    <select
                      value={foodRating}
                      onChange={(e) => setFoodRating(Number(e.target.value))}
                      className="w-full bg-white border border-brand-200 rounded-lg p-2"
                    >
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>{n} Stars</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 mb-1">Security</label>
                    <select
                      value={securityRating}
                      onChange={(e) => setSecurityRating(Number(e.target.value))}
                      className="w-full bg-white border border-brand-200 rounded-lg p-2"
                    >
                      {[5, 4, 3, 2, 1].map((n) => (
                        <option key={n} value={n}>{n} Stars</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">Detailed Feedback</label>
                  <textarea
                    rows={3}
                    required
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="Share details about room ventilation, study environment, wifi stability, warden support..."
                    className="w-full bg-white border border-brand-200 rounded-xl p-3 text-xs focus:ring-2 focus:ring-brand-400 focus:outline-none"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={submittingReview}
                    className="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl shadow-soft hover:shadow-soft-hover transition disabled:opacity-50"
                  >
                    {submittingReview ? 'Submitting...' : 'Post Review'}
                  </button>
                </div>
              </form>
            )}

            {/* Reviews List */}
            <div className="space-y-3">
              {reviews.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No reviews written yet. Be the first student to review!</p>
              ) : (
                reviews.map((rev) => (
                  <div key={rev._id} className="p-4 rounded-2xl border border-brand-100/70 bg-white/70 shadow-2xs space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <img
                          src={rev.studentId?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=60&q=80'}
                          alt={rev.studentId?.name}
                          className="w-8 h-8 rounded-full object-cover border border-brand-200"
                        />
                        <div>
                          <span className="font-bold text-slate-800 block">{rev.studentId?.name || 'Fergusson Student'}</span>
                          <span className="text-[10px] text-slate-400">Verified Resident</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-honey-800 bg-honey-50 border border-honey-200 px-2 py-0.5 rounded-full font-bold">
                        <Star className="w-3.5 h-3.5 fill-honey-400 text-honey-400" />
                        <span>{rev.rating}★</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed pt-1">{rev.comment}</p>
                    <div className="flex gap-4 text-[10px] text-slate-400 pt-2 border-t border-slate-100">
                      <span>Cleanliness: <strong className="text-slate-600">{rev.cleanlinessRating || rev.rating}★</strong></span>
                      <span>Food: <strong className="text-slate-600">{rev.foodRating || rev.rating}★</strong></span>
                      <span>Security: <strong className="text-slate-600">{rev.securityRating || rev.rating}★</strong></span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Location Map, Owner Card, Sticky Booking Box */}
        <div className="space-y-6">
          {/* Map Preview Card */}
          <div className="glass-card rounded-3xl p-6 border border-brand-100/70 shadow-soft space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-brand-600" />
              Property Location & Vicinity
            </h3>
            <div className="h-56 rounded-2xl overflow-hidden border border-brand-100">
              <MapView
                hostels={[hostel]}
                center={[lat, lng]}
                zoom={15}
                height="100%"
              />
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">{hostel.address}</p>
            <a
              href={directionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 bg-pastel-canvas hover:bg-brand-50 border border-brand-200/70 text-brand-800 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <Navigation className="w-3.5 h-3.5 text-brand-600" />
              Open Navigation in Google Maps
            </a>
          </div>

          {/* Owner Contact Card */}
          <div className="glass-card rounded-3xl p-6 border border-brand-100/70 shadow-soft space-y-4">
            <h3 className="font-bold text-sm text-slate-900">Hostel Warden & Manager</h3>
            <div className="flex items-center gap-3">
              <img
                src={hostel.ownerId?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80'}
                alt={hostel.ownerId?.name}
                className="w-12 h-12 rounded-full object-cover border border-brand-200"
              />
              <div>
                <h4 className="font-bold text-sm text-slate-900">{hostel.ownerId?.name || 'Property Owner'}</h4>
                <p className="text-xs text-mint-700 font-semibold flex items-center gap-1">
                  <CheckCircle className="w-3 h-3 text-mint-600" />
                  Verified Pune Property
                </p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-600 pt-2 border-t border-brand-100">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-brand-600" />
                <span>{hostel.phone || hostel.ownerId?.phone || '+91 98230 11223'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-brand-600" />
                <span>{hostel.ownerId?.email || 'fc.living@smarthostel.com'}</span>
              </div>
            </div>

            <button
              onClick={() => setIsEnquiryOpen(true)}
              className="w-full py-3 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-700 hover:to-indigo-700 text-white rounded-xl font-bold text-xs shadow-soft hover:shadow-soft-hover transition"
            >
              Send Direct Enquiry Message
            </button>
          </div>
        </div>
      </div>

      {/* Enquiry Modal */}
      <EnquiryModal
        hostel={hostel}
        isOpen={isEnquiryOpen}
        onClose={() => setIsEnquiryOpen(false)}
        onSuccess={() => {
          showToast('Enquiry dispatched to hostel owner!', 'success');
        }}
      />
    </div>
  );
};

export default HostelDetailPage;
