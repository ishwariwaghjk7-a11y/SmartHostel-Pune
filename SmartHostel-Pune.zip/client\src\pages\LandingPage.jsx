import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Compass,
  MapPin,
  IndianRupee,
  Search,
  Navigation,
  Sparkles,
  ShieldCheck,
  Scale,
  Users,
  CheckCircle2,
  Building2,
  ArrowRight,
  HeartHandshake,
  Coffee,
  BookOpen,
  Wifi,
  Zap,
  Droplets,
  Bed,
  Check,
  Phone,
  Star,
  ExternalLink,
} from 'lucide-react';
import api from '../services/api';
import { useToast } from '../context/ToastContext';

const LandingPage = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [colleges, setColleges] = useState([]);
  const [selectedCollege, setSelectedCollege] = useState('');
  const [budget, setBudget] = useState(14000);
  const [radius, setRadius] = useState(3);
  const [geoLoading, setGeoLoading] = useState(false);
  const [featuredHostels, setFeaturedHostels] = useState([]);

  useEffect(() => {
    fetchColleges();
    fetchFeaturedHostels();
  }, []);

  const fetchColleges = async () => {
    try {
      const res = await api.get('/colleges');
      if (res.data?.success && res.data.colleges.length > 0) {
        setColleges(res.data.colleges);
        const fc = res.data.colleges.find((c) => c.name.includes('Fergusson')) || res.data.colleges[0];
        setSelectedCollege(fc._id);
      }
    } catch (err) {
      console.error('Error fetching colleges:', err);
    }
  };

  const fetchFeaturedHostels = async () => {
    try {
      const res = await api.get('/hostels/search?sort=nearest&radius=5');
      if (res.data?.success && res.data.hostels?.length > 0) {
        // Pick top 3 boys and top 3 girls
        const boys = res.data.hostels.filter((h) => h.gender === 'male').slice(0, 3);
        const girls = res.data.hostels.filter((h) => h.gender === 'female').slice(0, 3);
        setFeaturedHostels([...boys, ...girls]);
      }
    } catch (err) {
      console.error('Error fetching featured hostels:', err);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (selectedCollege) params.append('collegeId', selectedCollege);
    if (budget) params.append('budget', budget);
    if (radius) params.append('radius', radius);
    navigate(`/search?${params.toString()}`);
  };

  const handleNearMeClick = () => {
    if (!navigator.geolocation) {
      showToast('Geolocation is not supported by your browser. Please select a college instead.', 'error');
      return;
    }

    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setGeoLoading(false);
        const { latitude, longitude } = position.coords;
        navigate(`/search?lat=${latitude}&lng=${longitude}&radius=${radius}`);
      },
      (error) => {
        setGeoLoading(false);
        if (error.code === error.PERMISSION_DENIED) {
          showToast('Location permission denied. Searching near Fergusson College instead.', 'info');
          navigate(`/search?radius=${radius}`);
        } else {
          showToast('Unable to determine location. Searching near Fergusson College.', 'info');
          navigate(`/search?radius=${radius}`);
        }
      },
      { timeout: 8000 }
    );
  };

  const popularAreas = [
    { name: 'F.C. Road', tag: 'Walking Distance (0-300m)', count: 'Fergusson Gate #1 & #3', color: 'bg-brand-50 text-brand-700' },
    { name: 'Deccan Gymkhana', tag: 'Goodluck Chowk & Prabhat', count: 'Safe Residential PGs', color: 'bg-mint-50 text-mint-700' },
    { name: 'Law College Road', tag: 'Near BMCC & ILS', count: 'Peaceful Green Lanes', color: 'bg-blush-50 text-blush-700' },
    { name: 'Model Colony', tag: 'Deep Bunglow Chowk', count: 'Executive Suites', color: 'bg-honey-50 text-honey-800' },
    { name: 'Senapati Bapat Road', tag: 'Behind ICC Tower', count: 'Near Symbiosis & SPPU', color: 'bg-brand-50 text-brand-700' },
    { name: 'Erandwane', tag: 'Kamala Nehru Park', count: 'Girls Hostels & Food', color: 'bg-mint-50 text-mint-700' },
    { name: 'Karve Road', tag: 'Garware Metro Access', count: 'Budget Student Stays', color: 'bg-blush-50 text-blush-700' },
    { name: 'Shivajinagar', tag: 'Pune Central & Railway', count: 'Metro Connected', color: 'bg-honey-50 text-honey-800' },
  ];

  return (
    <div className="space-y-16 sm:space-y-24 pb-20">
      {/* Hero Section – Inspired directly by the Reference Flyer */}
      <section className="relative pt-8 sm:pt-14 pb-16 overflow-hidden pastel-gradient-hero border-b border-brand-100/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
            
            {/* Left Column: Reference Poster Typography & Highlights */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-brand-100/90 text-brand-800 text-xs font-bold uppercase tracking-wider shadow-xs border border-brand-200/70">
                <Sparkles className="w-3.5 h-3.5 text-brand-600" />
                Pune Student Living • Near Fergusson College
              </div>

              {/* Big Impact Headline inspired by reference poster */}
              <div className="space-y-1">
                <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-slate-900 tracking-tight leading-[1.05] uppercase">
                  LOOKING <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 via-brand-500 to-blush-500">
                    FOR A HOSTEL ?
                  </span>
                </h1>
                <p className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-800 tracking-tight lowercase">
                  your search is over.
                </p>
              </div>

              {/* Accommodation Options Pills (As in Reference Poster) */}
              <div className="bg-white/80 backdrop-blur-md rounded-2xl border border-brand-200/70 p-3 sm:p-4 shadow-xs space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Bed className="w-4 h-4 text-brand-600" />
                    Accomodation Options
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">Click to filter rooms</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => navigate('/search?roomType=single')}
                    className="p-2 sm:p-2.5 bg-brand-50/70 hover:bg-brand-100 text-brand-900 rounded-xl border border-brand-200/60 text-center transition group shadow-2xs hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-center gap-1 text-xs font-black">
                      <Bed className="w-3.5 h-3.5 text-brand-600" />
                      <span>1</span>
                    </div>
                    <div className="text-[10px] text-slate-600 font-semibold mt-0.5">in a room</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => navigate('/search?roomType=double')}
                    className="p-2 sm:p-2.5 bg-sky-50/70 hover:bg-sky-100 text-sky-900 rounded-xl border border-sky-200/60 text-center transition group shadow-2xs hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-center gap-1 text-xs font-black">
                      <Users className="w-3.5 h-3.5 text-sky-600" />
                      <span>2</span>
                    </div>
                    <div className="text-[10px] text-slate-600 font-semibold mt-0.5">in a room</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => navigate('/search?roomType=triple')}
                    className="p-2 sm:p-2.5 bg-mint-50/70 hover:bg-mint-100 text-mint-900 rounded-xl border border-mint-200/60 text-center transition group shadow-2xs hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-center gap-1 text-xs font-black">
                      <Users className="w-3.5 h-3.5 text-mint-600" />
                      <span>3</span>
                    </div>
                    <div className="text-[10px] text-slate-600 font-semibold mt-0.5">in a room</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => navigate('/search?roomType=four')}
                    className="p-2 sm:p-2.5 bg-rose-50/70 hover:bg-rose-100 text-rose-900 rounded-xl border border-rose-200/60 text-center transition group shadow-2xs hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-center gap-1 text-xs font-black">
                      <Users className="w-3.5 h-3.5 text-rose-600" />
                      <span>4</span>
                    </div>
                    <div className="text-[10px] text-slate-600 font-semibold mt-0.5">in a room</div>
                  </button>
                </div>
              </div>

              {/* Key Features List Card (Matching the Reference Poster's Bulleted Card) */}
              <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl border border-slate-800 space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-brand-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-mint-400" />
                  What Every Verified Property Includes
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-semibold text-slate-200">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-sky-400 flex-shrink-0" />
                    <span>Constant Water Supply & Geyser</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-amber-400 flex-shrink-0" />
                    <span>Constant Power Supply & Backup</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wifi className="w-4 h-4 text-mint-400 flex-shrink-0" />
                    <span>Fast High-Speed Fibre WiFi</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-brand-400 flex-shrink-0" />
                    <span>Secured Biometric & CCTV Entry</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bed className="w-4 h-4 text-rose-400 flex-shrink-0" />
                    <span>Spacious Rooms with Study Desks</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Closer to Campus (0.1 - 1.5 km)</span>
                  </div>
                </div>
              </div>

              {/* Quick Boys & Girls Category Selector */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Direct Category:</span>
                <Link
                  to="/search?gender=male"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-sky-100 hover:bg-sky-200 text-sky-900 text-xs font-black border border-sky-300 transition shadow-xs hover:scale-105"
                >
                  <span>👨 25 Boys Hostels</span>
                </Link>
                <Link
                  to="/search?gender=female"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-900 text-xs font-black border border-rose-300 transition shadow-xs hover:scale-105"
                >
                  <span>👩 25 Girls Hostels</span>
                </Link>
                <Link
                  to="/search"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-100 hover:bg-brand-200 text-brand-900 text-xs font-black border border-brand-300 transition shadow-xs hover:scale-105"
                >
                  <span>🌟 All 50 Hostels</span>
                </Link>
              </div>

            </div>

            {/* Right Column: Visual Mockup Phone / Capsule Showcase (Matching the Reference Poster's Layout) */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-[360px] sm:max-w-[400px]">
                
                {/* Decorative Ambient Pastel Glow */}
                <div className="absolute -inset-4 bg-gradient-to-r from-brand-400/20 via-blush-400/20 to-mint-400/20 rounded-[48px] blur-2xl opacity-70 -z-10" />

                {/* Vertical Capsule Mockup Container (Inspired by reference poster's tall black pill) */}
                <div className="bg-slate-900 rounded-[40px] p-4 sm:p-5 shadow-2xl border-4 border-white/80 space-y-3.5 relative overflow-hidden">
                  
                  {/* Capsule Window 1 (Top): Corridor View */}
                  <div className="relative h-36 sm:h-40 rounded-3xl overflow-hidden border-2 border-white/20 bg-slate-800 group">
                    <img
                      src="https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80"
                      alt="Modern hostel corridor"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <span className="absolute bottom-2.5 left-3 text-[11px] font-extrabold text-white bg-black/40 px-2 py-0.5 rounded-full backdrop-blur border border-white/10">
                      Clean Hallways & Corridors
                    </span>
                  </div>

                  {/* Capsule Window 2 (Middle): Bedroom View */}
                  <div className="relative h-36 sm:h-40 rounded-3xl overflow-hidden border-2 border-white/20 bg-slate-800 group">
                    <img
                      src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80"
                      alt="Student room with study table"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <span className="absolute bottom-2.5 left-3 text-[11px] font-extrabold text-white bg-black/40 px-2 py-0.5 rounded-full backdrop-blur border border-white/10">
                      Private Study Desk & Comfy Bed
                    </span>
                  </div>

                  {/* Capsule Window 3 (Bottom): Exterior Building View */}
                  <div className="relative h-44 sm:h-48 rounded-3xl overflow-hidden border-2 border-white/20 bg-slate-800 group">
                    <img
                      src="https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80"
                      alt="Hostel building exterior"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                    <span className="absolute bottom-3 left-3 text-xs font-extrabold text-white bg-brand-600/90 px-3 py-1 rounded-full backdrop-blur shadow-sm">
                      Walking Distance to Fergusson College
                    </span>
                  </div>

                  {/* Floating Badges */}
                  <div className="absolute top-8 -left-4 bg-white/95 text-slate-900 rounded-2xl px-3.5 py-2 shadow-xl border border-brand-100 flex items-center gap-2 backdrop-blur animate-bounce duration-1000">
                    <Star className="w-4 h-4 fill-honey-500 text-honey-500" />
                    <div>
                      <div className="text-xs font-black">4.8 / 5 Rating</div>
                      <div className="text-[10px] text-slate-500">50 Verified Stays</div>
                    </div>
                  </div>

                  <div className="absolute bottom-16 -right-3 bg-white/95 text-slate-900 rounded-2xl px-3.5 py-2 shadow-xl border border-mint-100 flex items-center gap-2 backdrop-blur">
                    <ShieldCheck className="w-4 h-4 text-mint-600" />
                    <div>
                      <div className="text-xs font-black">Campus Verified</div>
                      <div className="text-[10px] text-slate-500">Zero Brokerage</div>
                    </div>
                  </div>

                </div>

              </div>
            </div>

          </div>

          {/* Interactive Search Box Card */}
          <div className="mt-12 max-w-4xl mx-auto glass-card rounded-3xl shadow-soft border border-brand-100 p-5 sm:p-7 md:p-8">
            <form onSubmit={handleSearchSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* College Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-blush-500" />
                    Campus Landmark
                  </label>
                  <select
                    value={selectedCollege}
                    onChange={(e) => setSelectedCollege(e.target.value)}
                    className="w-full bg-slate-50/90 border border-brand-100 rounded-2xl px-3.5 py-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-400 transition"
                  >
                    {colleges.map((c) => (
                      <option key={c._id} value={c._id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Budget Input */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <IndianRupee className="w-4 h-4 text-mint-600" />
                    Max Monthly Rent
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="4000"
                      max="30000"
                      step="500"
                      value={budget}
                      onChange={(e) => setBudget(Number(e.target.value))}
                      className="w-full bg-slate-50/90 border border-brand-100 rounded-2xl px-3.5 py-3 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-brand-400 transition"
                    />
                    <span className="absolute right-3.5 top-3.5 text-xs text-brand-600 font-semibold">
                      ₹/mo
                    </span>
                  </div>
                </div>

                {/* Radius Buttons */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    Search Radius
                  </label>
                  <div className="grid grid-cols-4 gap-1.5 pt-0.5">
                    {[1, 2, 3, 5].map((km) => (
                      <button
                        key={km}
                        type="button"
                        onClick={() => setRadius(km)}
                        className={`py-2.5 rounded-xl text-xs font-bold transition ${
                          radius === km
                            ? 'bg-brand-600 text-white shadow-xs'
                            : 'bg-brand-50/70 text-brand-900 hover:bg-brand-100'
                        }`}
                      >
                        {km} km
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="w-full sm:flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-brand-600 via-brand-500 to-brand-700 hover:from-brand-700 hover:to-brand-800 text-white font-black text-sm shadow-soft hover:shadow-soft-hover flex items-center justify-center gap-2 transition hover:scale-[1.01]"
                >
                  <Search className="w-4 h-4" />
                  Search 50 Hostels Near Fergusson College
                </button>

                <button
                  type="button"
                  onClick={handleNearMeClick}
                  disabled={geoLoading}
                  className="w-full sm:w-auto py-3.5 px-6 rounded-2xl bg-brand-50/90 hover:bg-brand-100 text-brand-800 font-bold text-sm flex items-center justify-center gap-2 transition disabled:opacity-60 border border-brand-200/60"
                >
                  <Navigation className={`w-4 h-4 text-brand-600 ${geoLoading ? 'animate-spin' : ''}`} />
                  {geoLoading ? 'Locating...' : 'Find Hostels Near Me'}
                </button>
              </div>
            </form>
          </div>

          {/* Reference Poster Contact Strip */}
          <div className="mt-10 max-w-4xl mx-auto">
            <div className="bg-slate-900 text-white rounded-3xl p-4 sm:p-5 shadow-lg border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="inline-flex items-center gap-2 bg-honey-200 text-honey-900 font-black text-xs uppercase px-4 py-2 rounded-2xl shadow-xs">
                <Phone className="w-3.5 h-3.5" />
                Contact us on
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full md:w-auto text-center md:text-left">
                <div className="bg-slate-800/80 px-4 py-2 rounded-2xl border border-slate-700">
                  <div className="text-xs font-bold text-white">+91 98501 22334</div>
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">FC Helpdesk (Rajesh)</div>
                </div>

                <div className="bg-slate-800/80 px-4 py-2 rounded-2xl border border-slate-700">
                  <div className="text-xs font-bold text-white">+91 98812 33445</div>
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Girls PG Desk (Sunita)</div>
                </div>

                <div className="bg-slate-800/80 px-4 py-2 rounded-2xl border border-slate-700">
                  <div className="text-xs font-bold text-white">+91 99221 44556</div>
                  <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Student Rep (Rohan)</div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Featured Hostels Spotlight (Real 25 Boys + 25 Girls Listings) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full border border-brand-200/60">
              Verified Accommodation Spotlight
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
              Popular Hostels Near Fergusson College
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Top-rated boys and girls student homes with verified bed vacancies.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Link
              to="/search?gender=male"
              className="px-3.5 py-1.5 rounded-xl bg-sky-50 text-sky-800 hover:bg-sky-100 text-xs font-bold border border-sky-200 transition"
            >
              👨 Boys Hostels (25)
            </Link>
            <Link
              to="/search?gender=female"
              className="px-3.5 py-1.5 rounded-xl bg-rose-50 text-rose-800 hover:bg-rose-100 text-xs font-bold border border-rose-200 transition"
            >
              👩 Girls Hostels (25)
            </Link>
          </div>
        </div>

        {/* Featured Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredHostels.map((h) => (
            <div
              key={h._id}
              className="group bg-white rounded-3xl border border-brand-100/80 hover:border-brand-300 hover:shadow-soft-hover transition-all duration-300 overflow-hidden flex flex-col"
            >
              <div className="relative h-48 w-full overflow-hidden bg-slate-100">
                <img
                  src={h.images?.[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80'}
                  alt={h.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent" />
                
                <div className="absolute top-3 left-3 flex gap-1.5">
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full backdrop-blur shadow-xs ${
                    h.gender === 'male' ? 'bg-sky-50/95 text-sky-800' : 'bg-rose-50/95 text-rose-800'
                  }`}>
                    {h.gender === 'male' ? '👨 Boys Only' : '👩 Girls Only'}
                  </span>
                  <span className="bg-mint-50/95 text-mint-800 text-[11px] font-bold px-2.5 py-1 rounded-full backdrop-blur shadow-xs">
                    Verified
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs font-semibold">
                  <span className="flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded-lg backdrop-blur">
                    <MapPin className="w-3.5 h-3.5 text-blush-400" />
                    {h.area}
                  </span>
                  <span className="flex items-center gap-1 bg-honey-200/90 text-honey-900 px-2 py-0.5 rounded-lg font-bold">
                    <Star className="w-3.5 h-3.5 fill-honey-500 text-honey-500" />
                    {h.rating}
                  </span>
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <Link to={`/hostels/${h._id}`}>
                    <h3 className="font-bold text-base text-slate-900 group-hover:text-brand-600 transition-colors line-clamp-1 mb-1">
                      {h.name}
                    </h3>
                  </Link>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {h.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Monthly Rent</span>
                    <span className="text-sm font-extrabold text-brand-700">₹{h.rentFrom?.toLocaleString('en-IN')} - ₹{h.rentTo?.toLocaleString('en-IN')}</span>
                  </div>

                  <Link
                    to={`/hostels/${h._id}`}
                    className="px-3.5 py-2 rounded-xl bg-brand-50 hover:bg-brand-600 hover:text-white text-brand-700 text-xs font-bold transition flex items-center gap-1 shadow-2xs"
                  >
                    View Details
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Student Hubs around Fergusson College */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-3 py-1 rounded-full">
            Pune Educational Hubs
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
            Explore Hostels by Pune Neighborhood
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Carefully curated localities around Fergusson College, BMCC, and Deccan Gymkhana.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {popularAreas.map((area) => (
            <Link
              key={area.name}
              to={`/search?area=${encodeURIComponent(area.name)}`}
              className="group p-4 bg-white rounded-3xl border border-brand-100/80 hover:border-brand-300 hover:shadow-soft-hover transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <span className={`inline-block text-[11px] font-bold px-2 py-0.5 rounded-md mb-2 ${area.color}`}>
                  {area.tag}
                </span>
                <h3 className="font-bold text-slate-900 group-hover:text-brand-600 transition-colors text-sm sm:text-base">
                  {area.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">{area.count}</p>
              </div>
              <div className="mt-4 flex items-center justify-end text-xs text-brand-600 font-bold group-hover:translate-x-1 transition-transform">
                <span>View</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Why SmartHostel Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 lg:p-16 relative overflow-hidden shadow-xl">
          <div className="relative z-10 max-w-3xl space-y-3 mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-300 bg-brand-900/60 px-3 py-1 rounded-full border border-brand-500/30">
              Zero Brokerage • Verified Hostels
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
              Engineered for Pune College Students
            </h2>
            <p className="text-sm sm:text-base text-slate-300">
              Direct connection with hostel wardens and owners. Transparent mess details, Wi-Fi speeds, and genuine security reviews.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
            <div className="p-6 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-brand-500/20 text-brand-300 flex items-center justify-center font-bold">
                <Navigation className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-white">Live Walking Distance</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Calculated directly from Fergusson College Gate #1 and Gate #3. Know your morning walk time before visiting.
              </p>
            </div>

            <div className="p-6 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-mint-500/20 text-mint-300 flex items-center justify-center font-bold">
                <Scale className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-white">Objective Comparison</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Compare rent, deposits, sharing types, WiFi, Maharashtrian mess food, and curfew hours side-by-side with no biased ranking.
              </p>
            </div>

            <div className="p-6 bg-slate-800/80 rounded-2xl border border-slate-700/60 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-blush-500/20 text-blush-300 flex items-center justify-center font-bold">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-lg text-white">Admin Verified Safety</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Every hostel is verified for biometric security, clean drinking water, and in-house warden supervision.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            How It Works
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            Get settled near Fergusson College in three simple steps.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center text-center space-y-3 p-6 bg-white rounded-3xl border border-brand-100 shadow-soft">
            <div className="w-14 h-14 rounded-2xl bg-brand-100 text-brand-700 font-extrabold text-xl flex items-center justify-center">
              1
            </div>
            <h3 className="font-bold text-base text-slate-900">Search & Filter</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Filter by walking distance from Fergusson College, maximum budget, gender policy, and room sharing type on our interactive map.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-3 p-6 bg-white rounded-3xl border border-brand-100 shadow-soft">
            <div className="w-14 h-14 rounded-2xl bg-blush-100 text-blush-700 font-extrabold text-xl flex items-center justify-center">
              2
            </div>
            <h3 className="font-bold text-base text-slate-900">Compare & Shortlist</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Save favorites and evaluate up to 3 properties side-by-side with verified student reviews, mess details, and transparent deposit policies.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-3 p-6 bg-white rounded-3xl border border-brand-100 shadow-soft">
            <div className="w-14 h-14 rounded-2xl bg-mint-100 text-mint-700 font-extrabold text-xl flex items-center justify-center">
              3
            </div>
            <h3 className="font-bold text-base text-slate-900">Connect & Move In</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Send your room enquiry directly to the property warden, schedule a visit, and reserve your bed with zero brokerage.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
