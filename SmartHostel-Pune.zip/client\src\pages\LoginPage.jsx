import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Building2, LogIn, Sparkles, User, ShieldCheck, Home } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

const LoginPage = () => {
  const { login } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const from = location.state?.from?.pathname || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await login(email, password);
      showToast(`Welcome back, ${res.user.name}!`, 'success');

      if (from !== '/') {
        navigate(from, { replace: true });
      } else {
        // Redirect to role dashboard
        if (res.user.role === 'admin') navigate('/dashboard/admin');
        else if (res.user.role === 'owner') navigate('/dashboard/owner');
        else navigate('/dashboard/student');
      }
    } catch (err) {
      showToast(err.message || 'Invalid email or password', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoFill = async (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setSubmitting(true);
    try {
      const res = await login(demoEmail, demoPassword);
      showToast(`Logged in as ${res.user.name} (${res.user.role.toUpperCase()})`, 'success');
      if (res.user.role === 'admin') navigate('/dashboard/admin');
      else if (res.user.role === 'owner') navigate('/dashboard/owner');
      else navigate('/dashboard/student');
    } catch (err) {
      showToast(err.message || 'Demo login failed', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 relative">
      <div className="max-w-md w-full space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2 group">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-600 flex items-center justify-center text-white shadow-soft group-hover:scale-105 transition-transform">
              <Building2 className="w-6 h-6" />
            </div>
          </Link>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Sign In to SmartHostel
          </h1>
          <p className="text-xs text-slate-500">
            Find. Compare. Connect. Live Better in Pune.
          </p>
        </div>

        {/* 1-Click Viva Accounts Banner */}
        <div className="glass-card rounded-2xl p-4 border border-brand-100/80 shadow-soft space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-brand-800">
            <Sparkles className="w-4 h-4 text-brand-600" />
            Quick Sign-In (Select Role Profile)
          </div>
          <p className="text-[11px] text-slate-600">
            Instant authentication across all 3 verified platform roles:
          </p>

          <div className="grid grid-cols-3 gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleDemoFill('student1@smarthostel.com', 'Student@123')}
              className="p-2.5 bg-mint-50/70 hover:bg-mint-100/70 border border-mint-200/80 rounded-xl text-center transition shadow-2xs hover:scale-[1.02]"
            >
              <div className="text-xs font-bold text-mint-800 flex items-center justify-center gap-1">
                <User className="w-3.5 h-3.5 text-mint-600" /> Student
              </div>
              <span className="text-[10px] text-mint-600/80 font-medium block">Rohan K.</span>
            </button>

            <button
              type="button"
              onClick={() => handleDemoFill('owner1@smarthostel.com', 'Owner@123')}
              className="p-2.5 bg-brand-50/70 hover:bg-brand-100/70 border border-brand-200/80 rounded-xl text-center transition shadow-2xs hover:scale-[1.02]"
            >
              <div className="text-xs font-bold text-brand-800 flex items-center justify-center gap-1">
                <Home className="w-3.5 h-3.5 text-brand-600" /> Owner
              </div>
              <span className="text-[10px] text-brand-600/80 font-medium block">Rajesh P.</span>
            </button>

            <button
              type="button"
              onClick={() => handleDemoFill('admin@smarthostel.com', 'Admin@123')}
              className="p-2.5 bg-honey-50/70 hover:bg-honey-100/70 border border-honey-200/80 rounded-xl text-center transition shadow-2xs hover:scale-[1.02]"
            >
              <div className="text-xs font-bold text-honey-800 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-honey-600" /> Admin
              </div>
              <span className="text-[10px] text-honey-700/80 font-medium block">Moderator</span>
            </button>
          </div>
        </div>

        {/* Form Card */}
        <div className="glass-card rounded-3xl border border-brand-100/80 p-6 sm:p-8 shadow-soft">
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/80 border border-brand-100 rounded-xl p-3 font-semibold text-slate-900 shadow-2xs focus:outline-none focus:ring-2 focus:ring-brand-400"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Password
              </label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/80 border border-brand-100 rounded-xl p-3 font-semibold text-slate-900 shadow-2xs focus:outline-none focus:ring-2 focus:ring-brand-400"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition disabled:opacity-50 flex items-center justify-center gap-2 mt-2"
            >
              <LogIn className="w-4 h-4" />
              {submitting ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center text-xs text-slate-500">
            Don't have an account yet?{' '}
            <Link to="/register" className="font-bold text-brand-600 hover:text-brand-700">
              Create an account
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
