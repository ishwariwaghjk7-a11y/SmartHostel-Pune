import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Building2,
  Bed,
  MessageSquare,
  PlusCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Phone,
  User,
  ArrowRight,
} from 'lucide-react';
import api from '../services/api';
import StatCard from '../components/dashboard/StatCard';
import { GenderPieChart } from '../components/dashboard/AnalyticsCharts';
import { useToast } from '../context/ToastContext';

const OwnerDashboard = () => {
  const { showToast } = useToast();
  const [hostels, setHostels] = useState([]);
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOwnerData();
  }, []);

  const fetchOwnerData = async () => {
    setLoading(true);
    try {
      const [hostelRes, enqRes] = await Promise.all([
        api.get('/hostels/my/listings'),
        api.get('/enquiries/owner'),
      ]);

      if (hostelRes.data?.success) setHostels(hostelRes.data.hostels || []);
      if (enqRes.data?.success) setEnquiries(enqRes.data.enquiries || []);
    } catch (err) {
      showToast('Failed to load owner dashboard', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (enquiryId, newStatus) => {
    try {
      const res = await api.patch(`/enquiries/${enquiryId}/status`, { status: newStatus });
      if (res.data?.success) {
        setEnquiries((prev) =>
          prev.map((e) => (e._id === enquiryId ? { ...e, status: newStatus } : e))
        );
        showToast(`Enquiry status updated to ${newStatus}`, 'success');
      }
    } catch (err) {
      showToast(err.message || 'Failed to update enquiry status', 'error');
    }
  };

  // Compute metrics
  const totalHostels = hostels.length;
  const totalRooms = hostels.reduce((acc, h) => acc + (h.rooms?.length || 0), 0);
  const totalAvailableBeds = hostels.reduce((acc, h) => {
    const beds = (h.rooms || []).reduce(
      (rAcc, r) => rAcc + (r.availableBeds ?? Math.max(0, r.capacity - (r.occupiedBeds || 0))),
      0
    );
    return acc + beds;
  }, 0);

  const pendingEnquiries = enquiries.filter((e) => e.status === 'pending').length;

  // Chart data: enquiries by status
  const chartData = [
    { gender: 'Pending', count: enquiries.filter((e) => e.status === 'pending').length },
    { gender: 'Contacted', count: enquiries.filter((e) => e.status === 'contacted').length },
    { gender: 'Accepted', count: enquiries.filter((e) => e.status === 'accepted').length },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-brand-600">
            Property Warden Portal
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Owner Management Dashboard
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage your Pune accommodations, room vacancies, and applicant inquiries.
          </p>
        </div>

        <Link
          to="/owner/hostels"
          className="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow transition"
        >
          <PlusCircle className="w-4 h-4" />
          Manage & Add Hostels
        </Link>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-5">
        <StatCard
          title="Total Hostels"
          value={totalHostels}
          subtitle="Registered properties"
          icon={Building2}
          color="brand"
        />
        <StatCard
          title="Total Rooms"
          value={totalRooms}
          subtitle="Active configurations"
          icon={Building2}
          color="indigo"
        />
        <StatCard
          title="Available Beds"
          value={totalAvailableBeds}
          subtitle="Ready for move-in"
          icon={Bed}
          color="emerald"
        />
        <StatCard
          title="Total Enquiries"
          value={enquiries.length}
          subtitle={`${pendingEnquiries} awaiting review`}
          icon={MessageSquare}
          color="amber"
        />
      </div>

      {/* Main Grid: Enquiries Table & Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Enquiries Table (2 cols) */}
        <div className="lg:col-span-2 glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Student Booking Enquiries</h2>
              <p className="text-xs text-slate-500">Update status to automatically notify students</p>
            </div>
            <span className="text-xs font-bold text-brand-700 bg-brand-50 border border-brand-200/80 px-2.5 py-0.5 rounded-full">{enquiries.length} total</span>
          </div>

          {enquiries.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No student inquiries received yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="text-slate-500 uppercase tracking-wider bg-pastel-canvas/70 text-[10px]">
                  <tr>
                    <th className="p-3 rounded-l-xl">Student</th>
                    <th className="p-3">Hostel & Room</th>
                    <th className="p-3">Move-In Date</th>
                    <th className="p-3">Status</th>
                    <th className="p-3 rounded-r-xl">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-brand-100/50">
                  {enquiries.map((enq) => (
                    <tr key={enq._id} className="hover:bg-brand-50/30 transition">
                      <td className="p-3">
                        <div className="font-bold text-slate-800">{enq.studentId?.name}</div>
                        <div className="text-[11px] text-slate-500">{enq.phone || enq.studentId?.phone}</div>
                      </td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-800">{enq.hostelId?.name}</div>
                        <div className="text-[11px] text-brand-600 font-medium capitalize">
                          {enq.roomType} room
                        </div>
                      </td>
                      <td className="p-3 text-slate-600">
                        {new Date(enq.moveInDate).toLocaleDateString()}
                      </td>
                      <td className="p-3">
                        <span
                          className={`font-bold px-2.5 py-0.5 rounded-full capitalize text-[10px] border ${
                            enq.status === 'accepted'
                              ? 'bg-mint-50 text-mint-700 border-mint-200'
                              : enq.status === 'contacted'
                              ? 'bg-brand-50 text-brand-700 border-brand-200'
                              : enq.status === 'rejected'
                              ? 'bg-blush-50 text-blush-700 border-blush-200'
                              : 'bg-honey-50 text-honey-800 border-honey-200'
                          }`}
                        >
                          {enq.status}
                        </span>
                      </td>
                      <td className="p-3">
                        <select
                          value={enq.status}
                          onChange={(e) => handleUpdateStatus(enq._id, e.target.value)}
                          className="bg-white border border-brand-200 rounded-lg px-2.5 py-1 text-[11px] font-semibold text-slate-700 shadow-2xs focus:outline-none focus:ring-2 focus:ring-brand-400"
                        >
                          <option value="pending">Pending</option>
                          <option value="contacted">Contacted</option>
                          <option value="accepted">Accept</option>
                          <option value="rejected">Decline</option>
                          <option value="closed">Close</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Analytics Breakdown Card (1 col) */}
        <div className="glass-card rounded-3xl border border-brand-100/70 p-6 shadow-soft space-y-4">
          <h2 className="text-base font-bold text-slate-900">Enquiry Status Ratio</h2>
          <p className="text-xs text-slate-500">Distribution of incoming requests</p>
          <GenderPieChart data={chartData} />
        </div>
      </div>
    </div>
  );
};

export default OwnerDashboard;
