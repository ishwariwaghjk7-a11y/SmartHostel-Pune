import React, { useState, useEffect } from 'react';
import {
  Plus,
  Building2,
  MapPin,
  Bed,
  CheckCircle,
  Clock,
  XCircle,
  Trash2,
  Edit,
  ExternalLink,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import api from '../services/api';
import LocationPicker from '../components/map/LocationPicker';
import { useToast } from '../context/ToastContext';

const AMENITIES_OPTIONS = [
  'WiFi',
  'Mess / Food',
  'CCTV',
  'Laundry',
  'Power Backup',
  'Gym',
  'Study Room',
  'Hot Water',
  'Biometric Entry',
];

const OwnerHostelsPage = () => {
  const { showToast } = useToast();
  const [hostels, setHostels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // New hostel form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    address: '',
    area: 'Deccan Gymkhana',
    city: 'Pune',
    gender: 'male',
    hostelType: 'hostel',
    phone: '',
    rentFrom: 7000,
    rentTo: 14000,
    amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Hot Water'],
    rules: ['Curfew 10:30 PM', 'No smoking on premises'],
    images: ['https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80'],
    lat: 18.5236, // Fergusson College latitude
    lng: 73.8415, // Fergusson College longitude
  });

  // Rooms creation state for the new hostel
  const [rooms, setRooms] = useState([
    { roomType: 'double', capacity: 2, occupiedBeds: 0, rent: 9000, deposit: 18000, ac: false, attachedBathroom: true },
    { roomType: 'triple', capacity: 3, occupiedBeds: 0, rent: 7000, deposit: 14000, ac: false, attachedBathroom: false },
  ]);

  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchHostels();
  }, []);

  const fetchHostels = async () => {
    setLoading(true);
    try {
      const res = await api.get('/hostels/my/listings');
      if (res.data?.success) {
        setHostels(res.data.hostels || []);
      }
    } catch (err) {
      showToast('Failed to load your hostel listings', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleAmenityToggle = (amenity) => {
    setFormData((prev) => {
      const exists = prev.amenities.includes(amenity);
      return {
        ...prev,
        amenities: exists
          ? prev.amenities.filter((a) => a !== amenity)
          : [...prev.amenities, amenity],
      };
    });
  };

  const handleAddRoomRow = () => {
    setRooms([
      ...rooms,
      { roomType: 'single', capacity: 1, occupiedBeds: 0, rent: 12000, deposit: 24000, ac: true, attachedBathroom: true },
    ]);
  };

  const handleRemoveRoomRow = (index) => {
    setRooms(rooms.filter((_, i) => i !== index));
  };

  const handleRoomChange = (index, field, value) => {
    const updated = [...rooms];
    updated[index][field] = value;
    setRooms(updated);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      // 1. Create hostel
      const res = await api.post('/hostels', formData);
      if (res.data?.success) {
        const createdHostel = res.data.hostel;

        // 2. Create associated rooms
        for (const room of rooms) {
          await api.post(`/rooms/hostel/${createdHostel._id}`, room);
        }

        showToast('Hostel submitted for admin verification!', 'success');
        setShowAddForm(false);
        fetchHostels();
      }
    } catch (err) {
      showToast(err.message || 'Failed to submit hostel listing', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteHostel = async (id) => {
    if (!window.confirm('Are you sure you want to delete this hostel and its room inventory?')) return;
    try {
      await api.delete(`/hostels/${id}`);
      showToast('Hostel listing deleted', 'info');
      fetchHostels();
    } catch (err) {
      showToast(err.message || 'Failed to delete listing', 'error');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            My Hostel Listings & Rooms
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Register new Pune student properties or update room capacities.
          </p>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          {showAddForm ? 'Close Form' : 'Add New Hostel'}
        </button>
      </div>

      {/* Add Hostel Form Modal / Collapse */}
      {showAddForm && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-md space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-lg font-bold text-slate-900">List a New Student Hostel</h2>
            <p className="text-xs text-slate-500">
              Your listing will be reviewed by SmartHostel administrators before public activation.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 text-xs">
            {/* General Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Hostel Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Deccan Student Homes"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Pune Locality / Area
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Deccan Gymkhana, F.C. Road, Shivajinagar"
                  value={formData.area}
                  onChange={(e) => setFormData({ ...formData, area: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Gender Policy
                </label>
                <select
                  value={formData.gender}
                  onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="male">Boys Only</option>
                  <option value="female">Girls Only</option>
                  <option value="coed">Co-ed / Shared</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Contact Phone
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98501 22334"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Full Street Address
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Lane 4, Prabhat Road, Near Goodluck Cafe, Deccan, Pune 411004"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
                Description & Facilities
              </label>
              <textarea
                rows={3}
                required
                placeholder="Describe study atmosphere, proximity to Fergusson College, meal timings..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 font-medium focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            {/* Interactive Map Location Picker with Draggable Marker */}
            <div className="pt-2">
              <label className="block font-bold text-slate-900 uppercase tracking-wider mb-2">
                Pin Exact Location on Map
              </label>
              <LocationPicker
                lat={formData.lat}
                lng={formData.lng}
                onChange={(newLat, newLng) => setFormData({ ...formData, lat: newLat, lng: newLng })}
                height="300px"
              />
            </div>

            {/* Amenities Checkbox Matrix */}
            <div>
              <label className="block font-bold text-slate-700 uppercase tracking-wider mb-2">
                Included Amenities
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {AMENITIES_OPTIONS.map((a) => (
                  <label key={a} className="flex items-center gap-2 p-2 rounded-lg bg-slate-50 border border-slate-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.amenities.includes(a)}
                      onChange={() => handleAmenityToggle(a)}
                      className="rounded text-brand-600 focus:ring-brand-500"
                    />
                    <span className="font-semibold text-slate-700">{a}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Room Configurations Matrix */}
            <div className="pt-4 border-t border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Room Configurations & Rates</h3>
                  <p className="text-[11px] text-slate-500">Define single, double, or triple room types with bed capacity</p>
                </div>
                <button
                  type="button"
                  onClick={handleAddRoomRow}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-lg text-xs"
                >
                  + Add Room Type
                </button>
              </div>

              <div className="space-y-2">
                {rooms.map((room, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center gap-3">
                    <select
                      value={room.roomType}
                      onChange={(e) => handleRoomChange(idx, 'roomType', e.target.value)}
                      className="bg-white border border-slate-300 rounded-lg p-1.5 font-bold"
                    >
                      <option value="single">Single</option>
                      <option value="double">Double</option>
                      <option value="triple">Triple</option>
                      <option value="four">Four</option>
                    </select>

                    <div className="flex items-center gap-1">
                      <span className="text-slate-400">Beds:</span>
                      <input
                        type="number"
                        min="1"
                        max="6"
                        value={room.capacity}
                        onChange={(e) => handleRoomChange(idx, 'capacity', Number(e.target.value))}
                        className="w-14 bg-white border border-slate-300 rounded-lg p-1.5 font-semibold text-center"
                      />
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="text-slate-400">Rent ₹:</span>
                      <input
                        type="number"
                        step="500"
                        value={room.rent}
                        onChange={(e) => handleRoomChange(idx, 'rent', Number(e.target.value))}
                        className="w-24 bg-white border border-slate-300 rounded-lg p-1.5 font-bold text-brand-700"
                      />
                    </div>

                    <label className="flex items-center gap-1 text-slate-700">
                      <input
                        type="checkbox"
                        checked={room.ac}
                        onChange={(e) => handleRoomChange(idx, 'ac', e.target.checked)}
                      />
                      <span>AC</span>
                    </label>

                    <label className="flex items-center gap-1 text-slate-700">
                      <input
                        type="checkbox"
                        checked={room.attachedBathroom}
                        onChange={(e) => handleRoomChange(idx, 'attachedBathroom', e.target.checked)}
                      />
                      <span>Attached Bath</span>
                    </label>

                    {rooms.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveRoomRow(idx)}
                        className="text-rose-500 hover:text-rose-700 p-1 ml-auto"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-5 py-2.5 text-slate-600 font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl shadow transition disabled:opacity-50"
              >
                {submitting ? 'Submitting...' : 'Register Hostel'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Hostels List */}
      {loading ? (
        <div className="py-20 text-center text-xs text-slate-400">Loading listings...</div>
      ) : hostels.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-4 max-w-md mx-auto">
          <Building2 className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-bold text-base text-slate-800">No Listings Yet</h3>
          <p className="text-xs text-slate-500">
            You haven't listed any student hostels yet. Click "Add New Hostel" above to get started.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {hostels.map((hostel) => (
            <div
              key={hostel._id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4 hover:border-slate-300 transition"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={hostel.images?.[0] || 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=200&q=80'}
                    alt={hostel.name}
                    className="w-16 h-16 rounded-xl object-cover border"
                  />
                  <div>
                    <h3 className="font-bold text-base text-slate-900">{hostel.name}</h3>
                    <p className="text-xs text-slate-500">{hostel.address}</p>
                    <div className="flex items-center gap-2 mt-1 text-[11px]">
                      <span className="font-bold text-brand-700">
                        ₹{hostel.rentFrom?.toLocaleString('en-IN')} - ₹{hostel.rentTo?.toLocaleString('en-IN')}/mo
                      </span>
                      <span>•</span>
                      <span className="capitalize text-slate-600 font-medium">{hostel.gender}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`font-bold px-3 py-1 rounded-full text-xs capitalize ${
                      hostel.verificationStatus === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : hostel.verificationStatus === 'rejected'
                        ? 'bg-rose-100 text-rose-800'
                        : hostel.verificationStatus === 'suspended'
                        ? 'bg-slate-100 text-slate-700'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {hostel.verificationStatus}
                  </span>

                  <button
                    onClick={() => handleDeleteHostel(hostel._id)}
                    className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                    title="Delete hostel"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Rooms preview */}
              <div className="pt-3 border-t border-slate-100 flex flex-wrap gap-2 text-xs">
                {(hostel.rooms || []).map((r, i) => (
                  <span key={i} className="bg-slate-100 px-2.5 py-1 rounded-lg text-slate-700 font-medium capitalize">
                    {r.roomType} (Capacity: {r.capacity} beds • ₹{r.rent?.toLocaleString('en-IN')})
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OwnerHostelsPage;
