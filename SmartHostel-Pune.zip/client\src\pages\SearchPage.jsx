import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import {
  Search,
  MapPin,
  SlidersHorizontal,
  Map as MapIcon,
  List,
  Layers,
  Sparkles,
  ArrowUpDown,
  X,
} from 'lucide-react';
import api from '../services/api';
import FilterSidebar from '../components/hostel/FilterSidebar';
import HostelCard from '../components/hostel/HostelCard';
import MapView from '../components/map/MapView';
import SkeletonCard from '../components/common/SkeletonCard';
import { useToast } from '../context/ToastContext';

const SearchPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [colleges, setColleges] = useState([]);
  const [selectedCollege, setSelectedCollege] = useState(null);
  const [hostels, setHostels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedHostelId, setSelectedHostelId] = useState(null);
  const [mobileView, setMobileView] = useState('list'); // 'list' | 'map'
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Comparison drawer state
  const [comparedHostels, setComparedHostels] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('smarthostel_compare') || '[]');
    } catch {
      return [];
    }
  });

  // Current filter values from URL or defaults
  const currentFilters = {
    collegeId: searchParams.get('collegeId') || '',
    lat: searchParams.get('lat') || '',
    lng: searchParams.get('lng') || '',
    budget: searchParams.get('budget') || '20000',
    radius: searchParams.get('radius') || '5',
    gender: searchParams.get('gender') || 'all',
    roomType: searchParams.get('roomType') || 'all',
    amenities: searchParams.get('amenities') || '',
    minRating: searchParams.get('minRating') || '',
    sort: searchParams.get('sort') || 'nearest',
    search: searchParams.get('search') || '',
  };

  const cardRefs = useRef({});

  useEffect(() => {
    fetchColleges();
  }, []);

  useEffect(() => {
    fetchHostels();
  }, [searchParams]);

  useEffect(() => {
    localStorage.setItem('smarthostel_compare', JSON.stringify(comparedHostels));
  }, [comparedHostels]);

  const fetchColleges = async () => {
    try {
      const res = await api.get('/colleges');
      if (res.data?.success) {
        setColleges(res.data.colleges);
        const fc =
          res.data.colleges.find((c) => c._id === currentFilters.collegeId) ||
          res.data.colleges.find((c) => c.name.includes('Fergusson')) ||
          res.data.colleges[0];
        setSelectedCollege(fc);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchHostels = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams(searchParams);
      if (!queryParams.has('sort')) queryParams.set('sort', 'nearest');
      if (!queryParams.has('radius')) queryParams.set('radius', '5');

      const res = await api.get(`/hostels/search?${queryParams.toString()}`);
      if (res.data?.success) {
        setHostels(res.data.hostels || []);
        if (res.data.referenceCollege) {
          setSelectedCollege((prev) => ({
            ...prev,
            name: res.data.referenceCollege.name,
            location: {
              type: 'Point',
              coordinates: [res.data.referenceCollege.lng, res.data.referenceCollege.lat],
            },
          }));
        }
      }
    } catch (err) {
      showToast(err.message || 'Failed to load hostels', 'error');
    } finally {
      setLoading(false);
    }
  };

  const updateFilters = (newFilters) => {
    const updated = new URLSearchParams(searchParams);
    Object.entries(newFilters).forEach(([key, val]) => {
      if (val === '' || val === 'all' || val === null || val === undefined) {
        updated.delete(key);
      } else {
        updated.set(key, val);
      }
    });
    setSearchParams(updated);
  };

  const handleResetFilters = () => {
    const fresh = new URLSearchParams();
    if (selectedCollege) fresh.set('collegeId', selectedCollege._id);
    fresh.set('radius', '5');
    setSearchParams(fresh);
  };

  const handleMarkerClick = (hostel) => {
    setSelectedHostelId(hostel._id);
    if (cardRefs.current[hostel._id]) {
      cardRefs.current[hostel._id].scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  };

  const handleToggleCompare = (hostel) => {
    setComparedHostels((prev) => {
      const exists = prev.some((h) => h._id === hostel._id);
      if (exists) {
        return prev.filter((h) => h._id !== hostel._id);
      } else {
        if (prev.length >= 3) {
          showToast('You can compare up to 3 hostels at a time', 'warning');
          return prev;
        }
        showToast(`Added ${hostel.name} to comparison`, 'success');
        return [...prev, hostel];
      }
    });
  };

  // Map center coordinates
  const mapCenter =
    selectedCollege?.location?.coordinates
      ? [selectedCollege.location.coordinates[1], selectedCollege.location.coordinates[0]]
      : [18.5236, 73.8415];

  return (
    <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Mobile Toggle & Filter Trigger Header */}
      <div className="lg:hidden flex items-center justify-between mb-4 gap-2">
        <button
          onClick={() => setMobileFilterOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 shadow-sm"
        >
          <SlidersHorizontal className="w-4 h-4 text-brand-600" />
          Filters
        </button>

        {/* View Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            onClick={() => setMobileView('list')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              mobileView === 'list'
                ? 'bg-white text-brand-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            List
          </button>
          <button
            onClick={() => setMobileView('map')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              mobileView === 'map'
                ? 'bg-white text-brand-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MapIcon className="w-3.5 h-3.5" />
            Map
          </button>
        </div>
      </div>

      {/* Main 3-Column Desktop Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Desktop Filter Sidebar (3 cols) */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-20">
          <FilterSidebar
            filters={currentFilters}
            onChange={updateFilters}
            onReset={handleResetFilters}
            colleges={colleges}
            totalResults={hostels.length}
          />
        </aside>

        {/* Middle Column: Results Feed (5 cols) */}
        <main
          className={`lg:col-span-5 space-y-4 ${
            mobileView === 'map' ? 'hidden lg:block' : 'block'
          }`}
        >
          {/* Search bar & Sorting bar */}
          <div className="bg-white rounded-3xl border border-brand-100/80 p-5 shadow-soft space-y-3.5">
            <div className="relative">
              <Search className="w-4 h-4 text-brand-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                placeholder="Search by hostel name, area (e.g. Deccan, FC Road, Prabhat Road)..."
                value={currentFilters.search}
                onChange={(e) => updateFilters({ search: e.target.value })}
                className="w-full pl-10 pr-4 py-2.5 bg-brand-50/40 border border-brand-100 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-400"
              />
            </div>

            {/* Quick Boys / Girls / All Filter Pills */}
            <div className="flex items-center gap-2 pt-1 overflow-x-auto pb-1">
              <button
                type="button"
                onClick={() => updateFilters({ gender: 'all' })}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                  currentFilters.gender === 'all' || !currentFilters.gender
                    ? 'bg-brand-600 text-white shadow-xs'
                    : 'bg-brand-50 text-brand-900 hover:bg-brand-100 border border-brand-200/60'
                }`}
              >
                <span>🌟 All Hostels</span>
              </button>
              <button
                type="button"
                onClick={() => updateFilters({ gender: 'male' })}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                  currentFilters.gender === 'male'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'bg-sky-50 text-sky-900 hover:bg-sky-100 border border-sky-200/80'
                }`}
              >
                <span>👨 Boys Hostels (25)</span>
              </button>
              <button
                type="button"
                onClick={() => updateFilters({ gender: 'female' })}
                className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                  currentFilters.gender === 'female'
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-rose-50 text-rose-900 hover:bg-rose-100 border border-rose-200/80'
                }`}
              >
                <span>👩 Girls Hostels (25)</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-brand-50 text-xs">
              <span className="font-bold text-slate-800">
                {loading ? 'Searching Pune Hostels...' : `${hostels.length} Student Accommodations Found`}
              </span>

              {/* Sorting Selector */}
              <div className="flex items-center gap-1.5">
                <ArrowUpDown className="w-3.5 h-3.5 text-brand-500" />
                <span className="text-slate-500 font-medium">Sort:</span>
                <select
                  value={currentFilters.sort}
                  onChange={(e) => updateFilters({ sort: e.target.value })}
                  className="bg-brand-50/80 border border-brand-100 rounded-xl px-2.5 py-1 text-xs font-bold text-brand-900 focus:outline-none"
                >
                  <option value="nearest">Distance from FC Gate</option>
                  <option value="recommended">Smart Recommendation Match</option>
                  <option value="lowest_rent">Lowest Rent First</option>
                  <option value="highest_rating">Highest Student Rating</option>
                </select>
              </div>
            </div>
          </div>

          {/* Hostels List */}
          {loading ? (
            <div className="space-y-4">
              <SkeletonCard />
              <SkeletonCard />
            </div>
          ) : hostels.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-brand-50 text-brand-600 flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-base text-slate-800">No Hostels Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                No properties matched all your selected criteria. Try widening your search radius or budget.
              </p>
              <button
                onClick={handleResetFilters}
                className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-brand-600 hover:text-brand-800"
              >
                Reset all filters
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {hostels.map((hostel) => (
                <div
                  key={hostel._id}
                  ref={(el) => (cardRefs.current[hostel._id] = el)}
                >
                  <HostelCard
                    hostel={hostel}
                    isSelected={selectedHostelId === hostel._id}
                    onHover={(id) => setSelectedHostelId(id)}
                    isCompared={comparedHostels.some((h) => h._id === hostel._id)}
                    onToggleCompare={handleToggleCompare}
                  />
                </div>
              ))}
            </div>
          )}
        </main>

        {/* Right Column: Sticky Interactive MapView (4 cols) */}
        <aside
          className={`lg:col-span-4 sticky top-20 ${
            mobileView === 'list' ? 'hidden lg:block' : 'block'
          }`}
        >
          <div className="h-[calc(100vh-110px)] min-h-[500px]">
            <MapView
              hostels={hostels}
              center={mapCenter}
              zoom={14}
              college={selectedCollege}
              selectedHostelId={selectedHostelId}
              onMarkerClick={handleMarkerClick}
              height="100%"
            />
          </div>
        </aside>
      </div>

      {/* Floating Compare Bar if hostels selected */}
      {comparedHostels.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-4 border border-slate-700 animate-in slide-in-from-bottom duration-200">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-brand-400" />
            <span className="text-xs font-bold">
              {comparedHostels.length} of 3 Hostels Selected
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Link
              to="/compare"
              className="bg-brand-600 hover:bg-brand-500 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl transition shadow-sm"
            >
              Compare Now
            </Link>
            <button
              onClick={() => setComparedHostels([])}
              className="text-slate-400 hover:text-white transition p-1"
              aria-label="Clear comparison"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Mobile Filters Drawer Modal */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm p-4 flex items-end sm:items-center justify-center">
          <div className="bg-white rounded-3xl max-w-md w-full p-5 max-h-[85vh] overflow-y-auto relative">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Filter Hostels</h3>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <FilterSidebar
              filters={currentFilters}
              onChange={updateFilters}
              onReset={handleResetFilters}
              colleges={colleges}
              totalResults={hostels.length}
            />

            <div className="pt-4 mt-4 border-t border-slate-100">
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl text-xs"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchPage;
