import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Heart,
  MessageSquare,
  Sparkles,
  Bell,
  Compass,
  ArrowRight,
  Star,
  MapPin,
  CheckCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';
import StatCard from '../components/dashboard/StatCard';
import HostelCard from '../components/hostel/HostelCard';

const StudentDashboard = () => {
  const { user } = useAuth();

  const [stats, setStats] = useState({
    favoritesCount: 0,
    enquiriesCount: 0,
    unreadNotifications: 0,
  });
  const [recommendations, setRecommendations] = useState([]);
  const [recentEnquiries, setRecentEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [favRes, enqRes, notifRes, recRes] = await Promise.all([
        api.get('/favorites'),
        api.get('/enquiries/student'),
        api.get('/notifications'),
        api.get('/hostels/recommended?budget=14000'),
      ]);

      setStats({
        favoritesCount: favRes.data?.count || 0,
        enquiriesCount: enqRes.data?.count || 0,
        unreadNotifications: notifRes.data?.unreadCount || 0,
      });

      setRecentEnquiries((enqRes.data?.enquiries || []).slice(0, 3));
      setRecommendations((recRes.data?.hostels || []).slice(0, 3));
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-brand-600 via-indigo-600 to-accent-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full">
            Student Portal
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-xs sm:text-sm text-brand-100">
            Fergusson College student accommodation planner & status tracker.
          </p>
        </div>

        <Link
          to="/search"
          className="self-start sm:self-center px-5 py-2.5 bg-white text-brand-700 hover:bg-brand-50 font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5"
        >
          <Compass className="w-4 h-4" />
          Find More Hostels
        </Link>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <StatCard
          title="Saved Hostels"
          value={stats.favoritesCount}
          subtitle="Shortlisted properties"
          icon={Heart}
          color="rose"
        />
        <StatCard
          title="Active Enquiries"
          value={stats.enquiriesCount}
          subtitle="Sent to property owners"
          icon={MessageSquare}
          color="brand"
        />
        <StatCard
          title="Unread Updates"
          value={stats.unreadNotifications}
          subtitle="Responses and notices"
          icon={Bell}
          color="amber"
        />
      </div>

      {/* AI / Smart Recommendations Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-brand-50 text-brand-600 border border-brand-200/70 flex items-center justify-center shadow-2xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Recommended Stays Near Fergusson College
              </h2>
              <p className="text-xs text-slate-500">
                Calculated via 5-factor weighted algorithm (budget, FC distance, amenities, rating, occupancy)
              </p>
            </div>
          </div>

          <Link
            to="/search?sort=recommended"
            className="text-xs font-bold text-brand-600 hover:text-brand-800 flex items-center gap-1"
          >
            View all matches
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {recommendations.map((hostel) => (
            <div
              key={hostel._id}
              className="glass-card rounded-3xl border border-brand-100/70 overflow-hidden shadow-soft hover:shadow-soft-hover transition flex flex-col justify-between"
            >
              <div className="relative h-44 bg-slate-100">
                <img
                  src={hostel.images?.[0]}
                  alt={hostel.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-brand-600/90 backdrop-blur-md text-white text-[11px] font-extrabold px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
                  <Sparkles className="w-3 h-3 text-honey-300" />
                  {hostel.matchScore}% Match
                </div>
                <div className="absolute bottom-3 left-3 bg-slate-900/60 backdrop-blur-md px-2.5 py-1 rounded-xl text-white text-xs font-semibold">
                  {hostel.distanceKm} km from FC Gate
                </div>
              </div>

              <div className="p-5 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 line-clamp-1 mb-1.5">
                    {hostel.name}
                  </h3>
                  <div className="space-y-1.5">
                    {(hostel.matchReasons || []).slice(0, 2).map((reason, i) => (
                      <div key={i} className="flex items-center gap-1.5 text-xs text-slate-600">
                        <CheckCircle className="w-3.5 h-3.5 text-mint-500 flex-shrink-0" />
                        <span className="line-clamp-1">{reason}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-brand-100/60 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">Starting from</span>
                    <span className="text-sm font-black text-brand-700">
                      ₹{hostel.rentFrom?.toLocaleString('en-IN')}<span className="text-xs font-normal text-slate-500">/mo</span>
                    </span>
                  </div>
                  <Link
                    to={`/hostels/${hostel._id}`}
                    className="px-4 py-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl shadow-soft hover:shadow-soft-hover transition"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Enquiries Tracker */}
      <div className="space-y-4 pt-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Recent Booking Enquiries</h2>
            <p className="text-xs text-slate-500">Live communication status with property wardens</p>
          </div>
          <Link
            to="/enquiries"
            className="text-xs font-bold text-brand-600 hover:text-brand-800 flex items-center gap-1"
          >
            All enquiries
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {recentEnquiries.length === 0 ? (
          <div className="p-8 text-center glass-card rounded-3xl border border-brand-100/70 text-xs text-slate-400 shadow-soft">
            No active enquiries yet. Search Pune hostels and submit a booking enquiry.
          </div>
        ) : (
          <div className="glass-card rounded-3xl border border-brand-100/70 divide-y divide-brand-100/60 overflow-hidden shadow-soft">
            {recentEnquiries.map((enq) => (
              <div key={enq._id} className="p-4 sm:p-5 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-extrabold text-slate-900">{enq.hostelId?.name}</h4>
                  <p className="text-slate-500 mt-0.5">
                    Requested: <strong className="text-slate-700 capitalize">{enq.roomType} Sharing</strong> • Target Move-in: {new Date(enq.moveInDate).toLocaleDateString()}
                  </p>
                </div>
                <span className={`font-bold px-3 py-1 rounded-full capitalize text-xs border ${
                  enq.status === 'accepted'
                    ? 'bg-mint-50 text-mint-700 border-mint-200'
                    : enq.status === 'contacted'
                    ? 'bg-brand-50 text-brand-700 border-brand-200'
                    : 'bg-honey-50 text-honey-800 border-honey-200'
                }`}>
                  {enq.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;
