import mockDb from './mockDb';

// Synthetic response delay for realistic UX transitions
const delay = (ms = 80) => new Promise((resolve) => setTimeout(resolve, ms));

const parseQueryParams = (url) => {
  const queryIndex = url.indexOf('?');
  if (queryIndex === -1) return {};
  const searchStr = url.substring(queryIndex + 1);
  const params = new URLSearchParams(searchStr);
  const result = {};
  for (const [key, val] of params.entries()) {
    result[key] = val;
  }
  return result;
};

// Seamless API adapter routing all requests to mockDb
const api = {
  async get(url) {
    await delay();
    const cleanUrl = url.split('?')[0];
    const params = parseQueryParams(url);

    // Auth
    if (cleanUrl === '/auth/me') {
      const user = mockDb.getCurrentUser();
      return { data: { success: !!user, user } };
    }

    // Colleges
    if (cleanUrl === '/colleges') {
      return { data: { success: true, colleges: mockDb.getColleges() } };
    }

    // Hostels Search & Recommended
    if (cleanUrl === '/hostels/search') {
      return { data: mockDb.searchHostels(params) };
    }
    if (cleanUrl === '/hostels/recommended') {
      return { data: mockDb.getRecommendedHostels(params) };
    }
    if (cleanUrl === '/hostels/my/listings') {
      return { data: mockDb.getMyListings() };
    }
    if (cleanUrl === '/hostels') {
      return { data: mockDb.searchHostels(params) };
    }
    if (cleanUrl.startsWith('/hostels/')) {
      const id = cleanUrl.replace('/hostels/', '');
      return { data: mockDb.getHostelById(id) };
    }

    // Reviews
    if (cleanUrl.startsWith('/reviews/hostel/')) {
      const hostelId = cleanUrl.replace('/reviews/hostel/', '');
      return { data: mockDb.getReviews(hostelId) };
    }

    // Favorites
    if (cleanUrl === '/favorites') {
      return { data: mockDb.getFavorites() };
    }

    // Enquiries
    if (cleanUrl === '/enquiries/student') {
      return { data: mockDb.getStudentEnquiries() };
    }
    if (cleanUrl === '/enquiries/owner') {
      return { data: mockDb.getOwnerEnquiries() };
    }

    // Notifications
    if (cleanUrl === '/notifications') {
      return { data: mockDb.getNotifications() };
    }

    // Admin
    if (cleanUrl === '/admin/analytics') {
      return { data: mockDb.getAdminAnalytics() };
    }
    if (cleanUrl === '/admin/hostels') {
      return { data: mockDb.getAllHostels(params) };
    }
    if (cleanUrl === '/admin/users') {
      return { data: mockDb.getAllUsers(params) };
    }

    return { data: { success: true } };
  },

  async post(url, body = {}) {
    await delay();
    const cleanUrl = url.split('?')[0];

    // Auth
    if (cleanUrl === '/auth/login') {
      return { data: mockDb.login(body.email, body.password) };
    }
    if (cleanUrl === '/auth/register') {
      return { data: mockDb.register(body) };
    }
    if (cleanUrl === '/auth/logout') {
      return { data: mockDb.logout() };
    }

    // Hostels & Rooms
    if (cleanUrl === '/hostels') {
      return { data: mockDb.createHostel(body) };
    }
    if (cleanUrl.startsWith('/rooms/hostel/')) {
      const hostelId = cleanUrl.replace('/rooms/hostel/', '');
      return { data: mockDb.createRoom(hostelId, body) };
    }

    // Reviews
    if (cleanUrl.startsWith('/reviews/hostel/')) {
      const hostelId = cleanUrl.replace('/reviews/hostel/', '');
      return { data: mockDb.createReview(hostelId, body) };
    }

    // Favorites
    if (cleanUrl.startsWith('/favorites/')) {
      const hostelId = cleanUrl.replace('/favorites/', '');
      return { data: mockDb.toggleFavorite(hostelId) };
    }

    // Enquiries
    if (cleanUrl === '/enquiries') {
      return { data: mockDb.createEnquiry(body) };
    }

    return { data: { success: true } };
  },

  async put(url, body = {}) {
    await delay();
    const cleanUrl = url.split('?')[0];

    if (cleanUrl === '/auth/profile') {
      return { data: mockDb.updateProfile(body) };
    }

    return { data: { success: true } };
  },

  async patch(url, body = {}) {
    await delay();
    const cleanUrl = url.split('?')[0];

    if (cleanUrl.startsWith('/enquiries/') && cleanUrl.endsWith('/status')) {
      const id = cleanUrl.replace('/enquiries/', '').replace('/status', '');
      return { data: mockDb.updateEnquiryStatus(id, body.status) };
    }

    if (cleanUrl.startsWith('/admin/hostels/') && cleanUrl.endsWith('/status')) {
      const id = cleanUrl.replace('/admin/hostels/', '').replace('/status', '');
      return { data: mockDb.updateHostelStatus(id, body.status) };
    }

    if (cleanUrl === '/notifications/mark-all-read') {
      return { data: mockDb.markAllNotificationsRead() };
    }

    return { data: { success: true } };
  },

  async delete(url) {
    await delay();
    const cleanUrl = url.split('?')[0];

    if (cleanUrl.startsWith('/favorites/')) {
      const hostelId = cleanUrl.replace('/favorites/', '');
      return { data: mockDb.toggleFavorite(hostelId) };
    }

    if (cleanUrl.startsWith('/hostels/')) {
      const id = cleanUrl.replace('/hostels/', '');
      return { data: mockDb.deleteHostel(id) };
    }

    return { data: { success: true } };
  },
};

export default api;
