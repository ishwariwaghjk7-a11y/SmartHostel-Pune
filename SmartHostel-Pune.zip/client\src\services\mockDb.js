import {
  initialColleges,
  initialUsers,
  initialHostels,
  initialReviews,
  initialEnquiries,
  initialFavorites,
  initialNotifications,
} from '../data/mockData';

const DB_KEY = 'smarthostel_pune_v6';
const AUTH_KEY = 'smarthostel_current_user_v6';

// Helper: Haversine distance in kilometers
export const calculateHaversineDistanceKm = (lat1, lon1, lat2, lon2) => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
};

// 5-Factor Weighted Recommendation Engine (Viva-ready)
export const calculateHostelMatch = (hostel, preferences = {}) => {
  const {
    budget = 12000,
    collegeLat = 18.5236, // Fergusson College
    collegeLng = 73.8415,
    collegeName = 'Fergusson College',
    radiusKm = 5,
    preferredAmenities = ['WiFi', 'Mess / Food', 'CCTV'],
    preferredRoomType = 'double',
  } = preferences;

  const reasons = [];

  // 1. Distance Calculation (25%)
  const hostelLng = hostel.location?.coordinates?.[0] || 73.84;
  const hostelLat = hostel.location?.coordinates?.[1] || 18.52;
  const distanceKm = calculateHaversineDistanceKm(collegeLat, collegeLng, hostelLat, hostelLng);

  let distanceScore = 0;
  if (distanceKm <= 1.0) {
    distanceScore = 100;
    reasons.push(`Just ${distanceKm} km from ${collegeName} (quick walking distance)`);
  } else if (distanceKm <= radiusKm) {
    distanceScore = Math.max(0, 100 - ((distanceKm - 1.0) / (radiusKm - 1.0)) * 70);
    reasons.push(`${distanceKm} km from ${collegeName}`);
  } else {
    distanceScore = Math.max(10, 100 - (distanceKm / radiusKm) * 80);
  }

  // 2. Budget Scoring (30%)
  const minRent = hostel.rentFrom || 6000;
  let budgetScore = 0;
  if (minRent <= budget) {
    budgetScore = 100;
    reasons.push(`Fits your budget (₹${minRent.toLocaleString('en-IN')}/mo vs target ₹${Number(budget).toLocaleString('en-IN')})`);
  } else if (minRent <= budget * 1.25) {
    const overBudgetPct = (minRent - budget) / (budget * 0.25);
    budgetScore = Math.max(20, Math.round(100 - overBudgetPct * 70));
    reasons.push(`Slightly above target budget (₹${minRent.toLocaleString('en-IN')}/mo)`);
  } else {
    budgetScore = 10;
  }

  // 3. Amenities Scoring (20%)
  let amenitiesScore = 70;
  if (preferredAmenities && preferredAmenities.length > 0) {
    const hostelAmenities = hostel.amenities || [];
    const matched = preferredAmenities.filter((a) =>
      hostelAmenities.some((ha) => ha.toLowerCase() === a.toLowerCase())
    );
    amenitiesScore = Math.round((matched.length / preferredAmenities.length) * 100);
    if (matched.length > 0) {
      reasons.push(`Features your requested amenities: ${matched.slice(0, 3).join(', ')}`);
    }
  }

  // 4. Rating Scoring (15%)
  const rating = hostel.rating || 4.0;
  const ratingScore = Math.min(100, Math.round((rating / 5) * 100));
  if (rating >= 4.2) {
    reasons.push(`Highly rated by students (${rating}★ from ${hostel.reviewCount || 1} reviews)`);
  } else if (rating >= 3.5) {
    reasons.push(`Positive student satisfaction (${rating}★)`);
  }

  // 5. Room Preference Scoring (10%)
  let roomPreferenceScore = 50;
  if (hostel.rooms && hostel.rooms.length > 0) {
    const matchingRoom = hostel.rooms.find(
      (r) => r.roomType?.toLowerCase() === preferredRoomType?.toLowerCase()
    );
    if (matchingRoom) {
      const available = matchingRoom.availableBeds ?? (matchingRoom.capacity - matchingRoom.occupiedBeds);
      if (available > 0) {
        roomPreferenceScore = 100;
        reasons.push(`${available} bed(s) available in preferred ${preferredRoomType} room`);
      } else {
        roomPreferenceScore = 60;
        reasons.push(`Offers ${preferredRoomType} rooms (currently waiting list)`);
      }
    } else {
      roomPreferenceScore = 40;
    }
  } else {
    roomPreferenceScore = 70;
  }

  const matchScore = Math.round(
    budgetScore * 0.30 +
    distanceScore * 0.25 +
    amenitiesScore * 0.20 +
    ratingScore * 0.15 +
    roomPreferenceScore * 0.10
  );

  return {
    matchScore: Math.min(99, Math.max(45, matchScore)),
    reasons: reasons.slice(0, 4),
    distanceKm,
  };
};

class MockDatabase {
  constructor() {
    this.init();
  }

  init() {
    const saved = localStorage.getItem(DB_KEY);
    if (!saved) {
      this.reset();
    }
  }

  reset() {
    const data = {
      colleges: initialColleges,
      users: initialUsers,
      hostels: initialHostels,
      reviews: initialReviews,
      enquiries: initialEnquiries,
      favorites: initialFavorites,
      notifications: initialNotifications,
    };
    localStorage.setItem(DB_KEY, JSON.stringify(data));
    return data;
  }

  getData() {
    try {
      const data = localStorage.getItem(DB_KEY);
      return data ? JSON.parse(data) : this.reset();
    } catch {
      return this.reset();
    }
  }

  saveData(data) {
    localStorage.setItem(DB_KEY, JSON.stringify(data));
  }

  // Auth Operations
  getCurrentUser() {
    try {
      const user = localStorage.getItem(AUTH_KEY);
      return user ? JSON.parse(user) : null;
    } catch {
      return null;
    }
  }

  setCurrentUser(user) {
    if (user) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(AUTH_KEY);
    }
  }

  login(email, password) {
    const data = this.getData();
    const user = data.users.find((u) => u.email.toLowerCase() === email.toLowerCase().trim());
    if (!user) {
      throw new Error('No user found with this email address');
    }
    this.setCurrentUser(user);
    return { success: true, user };
  }

  register(userData) {
    const data = this.getData();
    const exists = data.users.some((u) => u.email.toLowerCase() === userData.email.toLowerCase().trim());
    if (exists) {
      throw new Error('An account with this email already exists');
    }
    const newUser = {
      _id: `usr-${Date.now()}`,
      name: userData.name,
      email: userData.email.toLowerCase().trim(),
      role: userData.role === 'owner' ? 'owner' : 'student',
      phone: userData.phone || '',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80&q=80',
      createdAt: new Date().toISOString(),
    };
    data.users.push(newUser);
    this.saveData(data);
    this.setCurrentUser(newUser);
    return { success: true, user: newUser };
  }

  logout() {
    this.setCurrentUser(null);
    return { success: true };
  }

  updateProfile(updateData) {
    const current = this.getCurrentUser();
    if (!current) throw new Error('Not authenticated');
    const data = this.getData();
    const idx = data.users.findIndex((u) => u._id === current._id);
    if (idx !== -1) {
      data.users[idx] = { ...data.users[idx], ...updateData };
      this.saveData(data);
      this.setCurrentUser(data.users[idx]);
      return { success: true, user: data.users[idx] };
    }
    return { success: true, user: current };
  }

  // Colleges
  getColleges() {
    return this.getData().colleges;
  }

  // Hostels Search & Filtering
  searchHostels(params = {}) {
    const data = this.getData();
    const {
      collegeId,
      lat,
      lng,
      budget,
      radius = 10,
      gender,
      roomType,
      amenities,
      minRating,
      sort = 'nearest',
      search,
    } = params;

    // Reference college coordinate
    let refLat = lat ? parseFloat(lat) : 18.5236; // Fergusson College
    let refLng = lng ? parseFloat(lng) : 73.8415;
    let collegeName = 'Fergusson College';

    if (collegeId) {
      const col = data.colleges.find((c) => c._id === collegeId);
      if (col) {
        refLng = col.location.coordinates[0];
        refLat = col.location.coordinates[1];
        collegeName = col.name;
      }
    }

    // Filter approved hostels
    let results = data.hostels.filter((h) => h.verificationStatus === 'approved');

    // Text search
    if (search && search.trim() !== '') {
      const q = search.toLowerCase();
      results = results.filter(
        (h) =>
          h.name.toLowerCase().includes(q) ||
          h.area.toLowerCase().includes(q) ||
          h.address.toLowerCase().includes(q)
      );
    }

    // Gender filter
    if (gender && gender !== 'all') {
      results = results.filter((h) => h.gender === gender);
    }

    // Budget filter
    if (budget) {
      results = results.filter((h) => h.rentFrom <= parseFloat(budget));
    }

    // Rating filter
    if (minRating) {
      results = results.filter((h) => (h.rating || 0) >= parseFloat(minRating));
    }

    // Room sharing type filter
    if (roomType && roomType !== 'all') {
      results = results.filter((h) =>
        (h.rooms || []).some((r) => r.roomType === roomType)
      );
    }

    // Amenities filter
    if (amenities) {
      const amList = Array.isArray(amenities)
        ? amenities
        : amenities.split(',').map((a) => a.trim()).filter(Boolean);
      if (amList.length > 0) {
        results = results.filter((h) =>
          amList.every((reqAm) =>
            (h.amenities || []).some((ha) => ha.toLowerCase() === reqAm.toLowerCase())
          )
        );
      }
    }

    // Compute distance and recommendation score for each
    results = results.map((h) => {
      const hLng = h.location?.coordinates?.[0] || 73.84;
      const hLat = h.location?.coordinates?.[1] || 18.52;
      const distanceKm = calculateHaversineDistanceKm(refLat, refLng, hLat, hLng);

      const rec = calculateHostelMatch(h, {
        budget: budget ? parseFloat(budget) : undefined,
        collegeLat: refLat,
        collegeLng: refLng,
        collegeName,
        radiusKm: parseFloat(radius),
        preferredAmenities: amenities ? (Array.isArray(amenities) ? amenities : amenities.split(',')) : [],
        preferredRoomType: roomType !== 'all' ? roomType : 'double',
      });

      return {
        ...h,
        distanceKm,
        matchScore: rec.matchScore,
        matchReasons: rec.reasons,
      };
    });

    // Radius filter
    const maxRadius = parseFloat(radius) || 15;
    results = results.filter((h) => h.distanceKm <= maxRadius);

    // Sorting
    if (sort === 'lowest_rent') {
      results.sort((a, b) => (a.rentFrom || 0) - (b.rentFrom || 0));
    } else if (sort === 'highest_rating') {
      results.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (sort === 'recommended') {
      results.sort((a, b) => b.matchScore - a.matchScore);
    } else {
      results.sort((a, b) => a.distanceKm - b.distanceKm);
    }

    return {
      success: true,
      count: results.length,
      referenceCollege: { name: collegeName, lat: refLat, lng: refLng },
      hostels: results,
    };
  }

  getRecommendedHostels(params = {}) {
    return this.searchHostels({ ...params, sort: 'recommended', radius: 10 });
  }

  getHostelById(id) {
    const data = this.getData();
    const hostel = data.hostels.find((h) => h._id === id);
    if (!hostel) throw new Error('Hostel not found');
    const owner = data.users.find((u) => u._id === hostel.ownerId);

    const distanceKm = calculateHaversineDistanceKm(
      18.5236,
      73.8415,
      hostel.location.coordinates[1],
      hostel.location.coordinates[0]
    );

    return {
      success: true,
      distanceFromFergussonKm: distanceKm,
      hostel: {
        ...hostel,
        ownerId: owner || { name: 'Property Warden', email: 'warden@pune.edu', phone: hostel.phone },
      },
    };
  }

  createHostel(hostelData) {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Authentication required');
    const data = this.getData();

    const newHostel = {
      _id: `hst-${Date.now()}`,
      ownerId: user._id,
      name: hostelData.name,
      description: hostelData.description,
      address: hostelData.address,
      area: hostelData.area,
      city: hostelData.city || 'Pune',
      gender: hostelData.gender,
      hostelType: hostelData.hostelType || 'hostel',
      phone: hostelData.phone || user.phone,
      rentFrom: Number(hostelData.rentFrom),
      rentTo: Number(hostelData.rentTo),
      amenities: hostelData.amenities || [],
      rules: hostelData.rules || [],
      images: hostelData.images && hostelData.images.length > 0 ? hostelData.images : [
        'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80',
      ],
      location: {
        type: 'Point',
        coordinates: [parseFloat(hostelData.lng || 73.8415), parseFloat(hostelData.lat || 18.5236)],
      },
      rating: 0,
      reviewCount: 0,
      verificationStatus: 'pending', // Starts as pending for Admin verification demo!
      isDemo: false,
      rooms: [],
    };

    data.hostels.unshift(newHostel);

    // Notify admins
    data.notifications.unshift({
      _id: `notif-${Date.now()}`,
      userId: 'usr-admin-1',
      title: 'New Hostel Awaiting Verification',
      message: `${user.name} registered "${newHostel.name}" in ${newHostel.area}.`,
      link: '/admin/hostels',
      type: 'hostel_approval',
      read: false,
      createdAt: new Date().toISOString(),
    });

    this.saveData(data);
    return { success: true, hostel: newHostel };
  }

  createRoom(hostelId, roomData) {
    const data = this.getData();
    const hostel = data.hostels.find((h) => h._id === hostelId);
    if (!hostel) throw new Error('Hostel not found');

    const newRoom = {
      _id: `rm-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      hostelId,
      roomType: roomData.roomType,
      capacity: Number(roomData.capacity),
      occupiedBeds: Number(roomData.occupiedBeds || 0),
      availableBeds: Math.max(0, Number(roomData.capacity) - Number(roomData.occupiedBeds || 0)),
      rent: Number(roomData.rent),
      deposit: Number(roomData.deposit),
      ac: Boolean(roomData.ac),
      attachedBathroom: Boolean(roomData.attachedBathroom),
    };

    if (!hostel.rooms) hostel.rooms = [];
    hostel.rooms.push(newRoom);

    // Update rent bounds
    const rents = hostel.rooms.map((r) => r.rent);
    hostel.rentFrom = Math.min(...rents);
    hostel.rentTo = Math.max(...rents);

    this.saveData(data);
    return { success: true, room: newRoom };
  }

  deleteHostel(id) {
    const data = this.getData();
    data.hostels = data.hostels.filter((h) => h._id !== id);
    data.enquiries = data.enquiries.filter((e) => e.hostelId !== id);
    data.reviews = data.reviews.filter((r) => r.hostelId !== id);
    data.favorites = data.favorites.filter((f) => f.hostelId !== id);
    this.saveData(data);
    return { success: true };
  }

  getMyListings(ownerId) {
    const data = this.getData();
    const user = this.getCurrentUser();
    const targetOwnerId = ownerId || user?._id || 'usr-owner-1';
    const listings = data.hostels.filter((h) => h.ownerId === targetOwnerId);
    return { success: true, hostels: listings };
  }

  // Reviews
  getReviews(hostelId) {
    const data = this.getData();
    const reviews = data.reviews.filter((r) => r.hostelId === hostelId);
    return { success: true, reviews };
  }

  createReview(hostelId, reviewData) {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Please sign in to post a review');
    const data = this.getData();

    const newReview = {
      _id: `rev-${Date.now()}`,
      hostelId,
      studentId: { _id: user._id, name: user.name, avatar: user.avatar },
      rating: Number(reviewData.rating),
      cleanlinessRating: Number(reviewData.cleanlinessRating || reviewData.rating),
      foodRating: Number(reviewData.foodRating || reviewData.rating),
      securityRating: Number(reviewData.securityRating || reviewData.rating),
      comment: reviewData.comment,
      createdAt: new Date().toISOString(),
    };

    data.reviews.unshift(newReview);

    // Update hostel average rating and reviewCount
    const hostelReviews = data.reviews.filter((r) => r.hostelId === hostelId);
    const avg = hostelReviews.reduce((sum, r) => sum + r.rating, 0) / hostelReviews.length;
    const hostel = data.hostels.find((h) => h._id === hostelId);
    if (hostel) {
      hostel.rating = Math.round(avg * 10) / 10;
      hostel.reviewCount = hostelReviews.length;
    }

    this.saveData(data);
    return { success: true, review: newReview };
  }

  // Favorites
  getFavorites(studentId) {
    const data = this.getData();
    const user = this.getCurrentUser();
    const targetStudentId = studentId || user?._id;
    const favs = data.favorites
      .filter((f) => f.studentId === targetStudentId)
      .map((f) => ({
        ...f,
        hostelId: data.hostels.find((h) => h._id === f.hostelId) || null,
      }))
      .filter((f) => f.hostelId !== null);

    return { success: true, favorites: favs };
  }

  toggleFavorite(hostelId) {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Authentication required');
    const data = this.getData();
    const existingIdx = data.favorites.findIndex(
      (f) => f.studentId === user._id && f.hostelId === hostelId
    );

    let isFavorited = false;
    if (existingIdx !== -1) {
      data.favorites.splice(existingIdx, 1);
      isFavorited = false;
    } else {
      data.favorites.push({
        _id: `fav-${Date.now()}`,
        studentId: user._id,
        hostelId,
      });
      isFavorited = true;
    }

    this.saveData(data);
    return {
      success: true,
      isFavorited,
      message: isFavorited ? 'Saved to favorites' : 'Removed from favorites',
    };
  }

  // Enquiries
  getStudentEnquiries(studentId) {
    const data = this.getData();
    const user = this.getCurrentUser();
    const targetStudentId = studentId || user?._id;

    const list = data.enquiries
      .filter((e) => e.studentId === targetStudentId)
      .map((e) => ({
        ...e,
        hostelId: data.hostels.find((h) => h._id === e.hostelId),
        ownerId: data.users.find((u) => u._id === e.ownerId),
      }));

    return { success: true, enquiries: list };
  }

  getOwnerEnquiries(ownerId) {
    const data = this.getData();
    const user = this.getCurrentUser();
    const targetOwnerId = ownerId || user?._id || 'usr-owner-1';

    const list = data.enquiries
      .filter((e) => e.ownerId === targetOwnerId)
      .map((e) => ({
        ...e,
        hostelId: data.hostels.find((h) => h._id === e.hostelId),
        studentId: data.users.find((u) => u._id === e.studentId),
      }));

    return { success: true, enquiries: list };
  }

  createEnquiry(enquiryData) {
    const user = this.getCurrentUser();
    if (!user) throw new Error('Authentication required');
    const data = this.getData();

    const hostel = data.hostels.find((h) => h._id === enquiryData.hostelId);
    if (!hostel) throw new Error('Hostel not found');

    const newEnq = {
      _id: `enq-${Date.now()}`,
      hostelId: hostel._id,
      studentId: user._id,
      ownerId: hostel.ownerId,
      roomType: enquiryData.roomType || 'double',
      moveInDate: enquiryData.moveInDate,
      durationMonths: Number(enquiryData.durationMonths || 6),
      message: enquiryData.message,
      phone: enquiryData.phone || user.phone,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    data.enquiries.unshift(newEnq);

    // Notify owner
    data.notifications.unshift({
      _id: `notif-${Date.now()}`,
      userId: hostel.ownerId,
      title: 'New Student Enquiry Received',
      message: `${user.name} enquired about ${hostel.name} (${newEnq.roomType} room).`,
      link: '/dashboard/owner',
      type: 'enquiry',
      read: false,
      createdAt: new Date().toISOString(),
    });

    this.saveData(data);
    return { success: true, enquiry: newEnq, message: 'Enquiry submitted to hostel owner successfully!' };
  }

  updateEnquiryStatus(enquiryId, status) {
    const data = this.getData();
    const enq = data.enquiries.find((e) => e._id === enquiryId);
    if (!enq) throw new Error('Enquiry not found');

    enq.status = status;
    const hostel = data.hostels.find((h) => h._id === enq.hostelId);

    // Notify student
    data.notifications.unshift({
      _id: `notif-${Date.now()}`,
      userId: enq.studentId,
      title: `Enquiry Update: ${status.toUpperCase()}`,
      message: `Your booking inquiry for "${hostel?.name || 'hostel'}" status is now: ${status}`,
      link: '/enquiries',
      type: 'status_change',
      read: false,
      createdAt: new Date().toISOString(),
    });

    this.saveData(data);
    return { success: true, enquiry: enq };
  }

  // Notifications
  getNotifications(userId) {
    const data = this.getData();
    const user = this.getCurrentUser();
    const targetUserId = userId || user?._id;
    const list = data.notifications.filter((n) => n.userId === targetUserId);
    const unread = list.filter((n) => !n.read).length;
    return { success: true, notifications: list, unreadCount: unread };
  }

  markAllNotificationsRead(userId) {
    const data = this.getData();
    const user = this.getCurrentUser();
    const targetUserId = userId || user?._id;
    data.notifications.forEach((n) => {
      if (n.userId === targetUserId) n.read = true;
    });
    this.saveData(data);
    return { success: true };
  }

  // Admin Operations
  getAllHostels(params = {}) {
    const data = this.getData();
    let list = [...data.hostels];

    if (params.status && params.status !== 'all') {
      list = list.filter((h) => h.verificationStatus === params.status);
    }

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter((h) => h.name.toLowerCase().includes(q) || h.area.toLowerCase().includes(q));
    }

    const populated = list.map((h) => ({
      ...h,
      ownerId: data.users.find((u) => u._id === h.ownerId) || { name: 'Owner' },
    }));

    return { success: true, hostels: populated };
  }

  updateHostelStatus(hostelId, status) {
    const data = this.getData();
    const hostel = data.hostels.find((h) => h._id === hostelId);
    if (!hostel) throw new Error('Hostel not found');

    hostel.verificationStatus = status;

    // Notify owner
    data.notifications.unshift({
      _id: `notif-${Date.now()}`,
      userId: hostel.ownerId,
      title: `Hostel Listing ${status.toUpperCase()}!`,
      message: `Your property "${hostel.name}" has been ${status} by administrators.`,
      link: '/owner/hostels',
      type: 'hostel_approval',
      read: false,
      createdAt: new Date().toISOString(),
    });

    this.saveData(data);
    return { success: true, hostel };
  }

  getAllUsers(params = {}) {
    const data = this.getData();
    let list = [...data.users];

    if (params.role && params.role !== 'all') {
      list = list.filter((u) => u.role === params.role);
    }

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter((u) => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
    }

    return { success: true, users: list };
  }

  getAdminAnalytics() {
    const data = this.getData();

    const totalStudents = data.users.filter((u) => u.role === 'student').length;
    const totalOwners = data.users.filter((u) => u.role === 'owner').length;
    const approvedHostels = data.hostels.filter((h) => h.verificationStatus === 'approved').length;
    const pendingHostels = data.hostels.filter((h) => h.verificationStatus === 'pending').length;
    const rejectedHostels = data.hostels.filter((h) => h.verificationStatus === 'rejected').length;

    // Areas aggregation
    const areaCounts = {};
    data.hostels.forEach((h) => {
      areaCounts[h.area] = (areaCounts[h.area] || 0) + 1;
    });
    const hostelsByArea = Object.entries(areaCounts).map(([area, count]) => ({ area, count }));

    // Gender aggregation
    const genderCounts = {};
    data.hostels.forEach((h) => {
      genderCounts[h.gender] = (genderCounts[h.gender] || 0) + 1;
    });
    const hostelsByGender = Object.entries(genderCounts).map(([gender, count]) => ({ gender, count }));

    // Rent distribution
    const rentRanges = [
      { range: 'Under ₹6,000', count: data.hostels.filter((h) => h.rentFrom < 6000).length },
      { range: '₹6,000 - ₹10,000', count: data.hostels.filter((h) => h.rentFrom >= 6000 && h.rentFrom <= 10000).length },
      { range: '₹10,000 - ₹15,000', count: data.hostels.filter((h) => h.rentFrom > 10000 && h.rentFrom <= 15000).length },
      { range: 'Above ₹15,000', count: data.hostels.filter((h) => h.rentFrom > 15000).length },
    ];

    return {
      success: true,
      stats: {
        totalUsers: data.users.length,
        totalStudents,
        totalOwners,
        totalHostels: data.hostels.length,
        approvedHostels,
        pendingHostels,
        rejectedHostels,
        totalEnquiries: data.enquiries.length,
        totalReviews: data.reviews.length,
      },
      charts: {
        hostelsByArea,
        hostelsByGender,
        rentRanges,
      },
    };
  }
}

export const mockDb = new MockDatabase();
export default mockDb;
