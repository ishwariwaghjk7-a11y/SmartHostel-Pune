/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Dynamic Pastel Theme Palette
        brand: {
          50: 'var(--brand-50, #f5f3ff)',
          100: 'var(--brand-100, #ede9fe)',
          200: 'var(--brand-200, #ddd6fe)',
          300: 'var(--brand-300, #c4b5fd)',
          400: 'var(--brand-400, #a78bfa)',
          500: 'var(--brand-500, #8b5cf6)',
          600: 'var(--brand-600, #7c3aed)',
          700: 'var(--brand-700, #6d28d9)',
          800: 'var(--brand-800, #5b21b6)',
          900: 'var(--brand-900, #4c1d95)',
          950: 'var(--brand-950, #2e1065)',
        },
        // Pastel Mint & Sage (Safety / Availability / Verified)
        mint: {
          50: '#ecfdf5',
          100: '#d1fae5',
          200: '#a7f3d0',
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
          800: '#065f46',
        },
        // Pastel Rose & Peach (Favorites / Highlights)
        blush: {
          50: '#fff1f2',
          100: '#ffe4e6',
          200: '#fecdd3',
          300: '#fda4af',
          400: '#fb7185',
          500: '#f43f5e',
          600: '#e11d48',
        },
        // Pastel Warm Honey & Butter (Ratings / Stars)
        honey: {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
        },
        // Soft Pastel Canvas Surfaces
        pastel: {
          canvas: '#fbfbfe',
          card: '#ffffff',
          lavender: '#f8f7ff',
          rose: '#fff5f7',
          mint: '#f2fcf7',
          amber: '#fffcf2',
          sky: '#f0f9ff',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(124, 58, 237, 0.08), 0 2px 6px -1px rgba(0, 0, 0, 0.04)',
        'soft-hover': '0 12px 32px -4px rgba(124, 58, 237, 0.14), 0 4px 12px -2px rgba(0, 0, 0, 0.05)',
        'pastel': '0 8px 24px -4px rgba(221, 214, 254, 0.6)',
      },
    },
  },
  plugins: [],
};
