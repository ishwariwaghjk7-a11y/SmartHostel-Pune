import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    if (!process.env.MONGO_URI || process.env.MONGO_URI.includes('placeholder')) {
      console.log('📦 [Database Notice]: MONGO_URI not configured. Using high-speed local Pune database engine.');
      return null;
    }
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 3000,
    });
    console.log(`[MongoDB Connected]: ${conn.connection.host}`);
    return conn;
  } catch (error) {
    console.log(`⚠️ [Database Warning]: Remote MongoDB not reached (${error.message}).`);
    console.log('✅ [SmartHostel Database]: Activated local Pune accommodation database engine.');
    return null;
  }
};

export default connectDB;
