import User from '../models/User.js';
import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';
import Enquiry from '../models/Enquiry.js';
import Review from '../models/Review.js';
import { createNotification } from '../services/notificationService.js';

// @desc    Get all users (with search and role filter)
// @route   GET /api/admin/users
// @access  Private (Admin)
export const getAllUsers = async (req, res, next) => {
  try {
    const { role, search, page = 1, limit = 25 } = req.query;

    const query = {};
    if (role && role !== 'all') query.role = role;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [users, total] = await Promise.all([
      User.find(query).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
      User.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      count: users.length,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      users,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all hostels with status filter for admin moderation
// @route   GET /api/admin/hostels
// @access  Private (Admin)
export const getAllHostels = async (req, res, next) => {
  try {
    const { status, search, page = 1, limit = 20 } = req.query;

    const query = {};
    if (status && status !== 'all') query.verificationStatus = status;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { area: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [hostels, total] = await Promise.all([
      Hostel.find(query)
        .populate('ownerId', 'name email phone')
        .populate('rooms')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Hostel.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      count: hostels.length,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      hostels,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Approve, reject, or suspend a hostel
// @route   PATCH /api/admin/hostels/:id/status
// @access  Private (Admin)
export const updateHostelStatus = async (req, res, next) => {
  try {
    const { status, feedback } = req.body;
    const validStatuses = ['approved', 'rejected', 'suspended', 'pending'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Status must be one of: ${validStatuses.join(', ')}`,
      });
    }

    const hostel = await Hostel.findById(req.params.id).populate('ownerId', 'name email');
    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    hostel.verificationStatus = status;
    await hostel.save();

    // Notify hostel owner
    const statusTitles = {
      approved: 'Hostel Listing Approved! 🎉',
      rejected: 'Hostel Listing Requires Updates',
      suspended: 'Hostel Listing Suspended',
      pending: 'Hostel Listing Placed in Review',
    };

    const statusDescriptions = {
      approved: `Congratulations! Your hostel "${hostel.name}" has been approved and is now live on SmartHostel.`,
      rejected: `Your hostel "${hostel.name}" was not approved. ${feedback || 'Please update your details and resubmit.'}`,
      suspended: `Your hostel "${hostel.name}" has been temporarily suspended by an administrator.`,
      pending: `Your hostel "${hostel.name}" status has been set back to pending review.`,
    };

    if (hostel.ownerId) {
      await createNotification({
        userId: hostel.ownerId._id,
        title: statusTitles[status] || 'Hostel Status Updated',
        message: statusDescriptions[status] || `Your hostel status is now ${status}`,
        link: '/owner/hostels',
        type: 'hostel_approval',
      });
    }

    res.status(200).json({
      success: true,
      message: `Hostel status successfully updated to '${status}'`,
      hostel,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get dashboard analytics (counts, charts data)
// @route   GET /api/admin/analytics
// @access  Private (Admin)
export const getAnalytics = async (req, res, next) => {
  try {
    // 1. Overall counts
    const [
      totalUsers,
      totalStudents,
      totalOwners,
      totalHostels,
      approvedHostels,
      pendingHostels,
      rejectedHostels,
      totalRooms,
      totalEnquiries,
      totalReviews,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'student' }),
      User.countDocuments({ role: 'owner' }),
      Hostel.countDocuments(),
      Hostel.countDocuments({ verificationStatus: 'approved' }),
      Hostel.countDocuments({ verificationStatus: 'pending' }),
      Hostel.countDocuments({ verificationStatus: 'rejected' }),
      Room.countDocuments(),
      Enquiry.countDocuments(),
      Review.countDocuments(),
    ]);

    // 2. Hostels by Pune Area (for Recharts BarChart)
    const hostelsByArea = await Hostel.aggregate([
      { $group: { _id: '$area', count: { $sum: 1 } } },
      { $project: { area: '$_id', count: 1, _id: 0 } },
      { $sort: { count: -1 } },
      { $limit: 8 },
    ]);

    // 3. Hostels by Gender policy (for Recharts PieChart)
    const hostelsByGender = await Hostel.aggregate([
      { $group: { _id: '$gender', count: { $sum: 1 } } },
      { $project: { gender: '$_id', count: 1, _id: 0 } },
    ]);

    // 4. Rent ranges distribution
    const rentRanges = await Hostel.aggregate([
      {
        $bucket: {
          groupBy: '$rentFrom',
          boundaries: [0, 6000, 10000, 15000, 25000],
          default: 'Above ₹25k',
          output: {
            count: { $sum: 1 },
          },
        },
      },
    ]);

    const formattedRentRanges = rentRanges.map((r) => {
      let rangeLabel = 'Above ₹25,000';
      if (r._id === 0) rangeLabel = 'Under ₹6,000';
      else if (r._id === 6000) rangeLabel = '₹6,000 - ₹10,000';
      else if (r._id === 10000) rangeLabel = '₹10,000 - ₹15,000';
      else if (r._id === 15000) rangeLabel = '₹15,000 - ₹25,000';
      return {
        range: rangeLabel,
        count: r.count,
      };
    });

    // 5. Enquiries monthly trend
    const enquiriesByStatus = await Enquiry.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
      { $project: { status: '$_id', count: 1, _id: 0 } },
    ]);

    res.status(200).json({
      success: true,
      stats: {
        totalUsers,
        totalStudents,
        totalOwners,
        totalHostels,
        approvedHostels,
        pendingHostels,
        rejectedHostels,
        totalRooms,
        totalEnquiries,
        totalReviews,
      },
      charts: {
        hostelsByArea,
        hostelsByGender,
        rentRanges: formattedRentRanges,
        enquiriesByStatus,
      },
    });
  } catch (error) {
    next(error);
  }
};
