import College from '../models/College.js';

// @desc    Get all colleges for selector dropdown
// @route   GET /api/colleges
// @access  Public
export const getColleges = async (req, res, next) => {
  try {
    const colleges = await College.find().sort({ name: 1 });
    res.status(200).json({
      success: true,
      count: colleges.length,
      colleges,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single college
// @route   GET /api/colleges/:id
// @access  Public
export const getCollegeById = async (req, res, next) => {
  try {
    const college = await College.findById(req.params.id);
    if (!college) {
      return res.status(404).json({
        success: false,
        message: 'College not found',
      });
    }
    res.status(200).json({
      success: true,
      college,
    });
  } catch (error) {
    next(error);
  }
};
