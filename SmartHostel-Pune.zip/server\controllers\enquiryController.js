import Enquiry from '../models/Enquiry.js';
import Hostel from '../models/Hostel.js';
import { createNotification } from '../services/notificationService.js';

// @desc    Student submits an enquiry for a hostel
// @route   POST /api/enquiries
// @access  Private (Student)
export const createEnquiry = async (req, res, next) => {
  try {
    const { hostelId, roomType, moveInDate, durationMonths, message, phone } = req.body;

    const hostel = await Hostel.findById(hostelId);
    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    const enquiry = await Enquiry.create({
      hostelId,
      studentId: req.user.id,
      ownerId: hostel.ownerId,
      roomType: roomType || 'double',
      moveInDate: moveInDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      durationMonths: durationMonths ? Number(durationMonths) : 6,
      message: message || 'I am interested in booking a room and would like more details.',
      phone: phone || req.user.phone || '',
      status: 'pending',
    });

    // Notify hostel owner
    await createNotification({
      userId: hostel.ownerId,
      title: 'New Student Enquiry Received',
      message: `${req.user.name} enquired about ${hostel.name} (${roomType || 'room'}).`,
      link: '/dashboard/owner',
      type: 'enquiry',
    });

    res.status(201).json({
      success: true,
      message: 'Your enquiry was sent to the hostel owner successfully!',
      enquiry,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get student's own enquiries
// @route   GET /api/enquiries/student
// @access  Private (Student)
export const getStudentEnquiries = async (req, res, next) => {
  try {
    const enquiries = await Enquiry.find({ studentId: req.user.id })
      .populate('hostelId', 'name address area phone images rentFrom')
      .populate('ownerId', 'name email phone')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: enquiries.length,
      enquiries,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get enquiries for owner's hostels
// @route   GET /api/enquiries/owner
// @access  Private (Owner)
export const getOwnerEnquiries = async (req, res, next) => {
  try {
    const enquiries = await Enquiry.find({ ownerId: req.user.id })
      .populate('hostelId', 'name address area')
      .populate('studentId', 'name email phone avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: enquiries.length,
      enquiries,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Owner updates enquiry status (contacted / accepted / rejected / closed)
// @route   PATCH /api/enquiries/:id/status
// @access  Private (Owner)
export const updateEnquiryStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const allowedStatuses = ['pending', 'contacted', 'accepted', 'rejected', 'closed'];

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Status must be one of: ${allowedStatuses.join(', ')}`,
      });
    }

    const enquiry = await Enquiry.findById(req.params.id).populate('hostelId', 'name');

    if (!enquiry) {
      return res.status(404).json({ success: false, message: 'Enquiry not found' });
    }

    // Verify ownership
    if (enquiry.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this enquiry',
      });
    }

    enquiry.status = status;
    await enquiry.save();

    // Automatically notify student
    const statusMessages = {
      contacted: `Owner has reached out regarding your enquiry for ${enquiry.hostelId?.name || 'hostel'}.`,
      accepted: `Good news! Your enquiry for ${enquiry.hostelId?.name || 'hostel'} has been accepted.`,
      rejected: `Your enquiry for ${enquiry.hostelId?.name || 'hostel'} could not be accepted at this time.`,
      closed: `Your enquiry for ${enquiry.hostelId?.name || 'hostel'} has been marked as closed.`,
    };

    if (statusMessages[status]) {
      await createNotification({
        userId: enquiry.studentId,
        title: `Enquiry Update: ${status.toUpperCase()}`,
        message: statusMessages[status],
        link: '/enquiries',
        type: 'status_change',
      });
    }

    res.status(200).json({
      success: true,
      message: `Enquiry status updated to ${status}`,
      enquiry,
    });
  } catch (error) {
    next(error);
  }
};
