import Favorite from '../models/Favorite.js';
import Hostel from '../models/Hostel.js';

// @desc    Get logged in student's favorites
// @route   GET /api/favorites
// @access  Private (Student)
export const getFavorites = async (req, res, next) => {
  try {
    const favorites = await Favorite.find({ studentId: req.user.id })
      .populate({
        path: 'hostelId',
        populate: [{ path: 'rooms' }, { path: 'ownerId', select: 'name phone email' }],
      })
      .sort({ createdAt: -1 });

    // Filter out any orphaned favorites where hostel might have been deleted
    const validFavorites = favorites.filter((f) => f.hostelId !== null);

    res.status(200).json({
      success: true,
      count: validFavorites.length,
      favorites: validFavorites,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Add or toggle hostel in favorites
// @route   POST /api/favorites/:hostelId
// @access  Private (Student)
export const toggleFavorite = async (req, res, next) => {
  try {
    const hostelId = req.params.hostelId;
    const studentId = req.user.id;

    const hostel = await Hostel.findById(hostelId);
    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    const existing = await Favorite.findOne({ studentId, hostelId });

    if (existing) {
      await existing.deleteOne();
      return res.status(200).json({
        success: true,
        isFavorited: false,
        message: 'Removed from favorites',
      });
    }

    const favorite = await Favorite.create({ studentId, hostelId });

    res.status(201).json({
      success: true,
      isFavorited: true,
      message: 'Added to favorites',
      favorite,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Remove hostel from favorites
// @route   DELETE /api/favorites/:hostelId
// @access  Private (Student)
export const removeFavorite = async (req, res, next) => {
  try {
    const { hostelId } = req.params;
    await Favorite.findOneAndDelete({ studentId: req.user.id, hostelId });

    res.status(200).json({
      success: true,
      message: 'Removed from favorites',
    });
  } catch (error) {
    next(error);
  }
};
