import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';
import College from '../models/College.js';
import { calculateHostelMatch, calculateHaversineDistanceKm } from '../services/recommendationService.js';
import { createNotification } from '../services/notificationService.js';
import User from '../models/User.js';

// @desc    Get all approved hostels (or filtered)
// @route   GET /api/hostels
// @access  Public
export const getHostels = async (req, res, next) => {
  try {
    const { status, gender, area, limit = 20, page = 1 } = req.query;

    const query = { verificationStatus: status || 'approved' };
    if (gender) query.gender = gender;
    if (area) query.area = new RegExp(area, 'i');

    const skip = (Number(page) - 1) * Number(limit);

    const [hostels, total] = await Promise.all([
      Hostel.find(query)
        .populate('rooms')
        .populate('ownerId', 'name email phone')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      Hostel.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      count: hostels.length,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      hostels,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Find approved hostels nearby a coordinate using MongoDB $geoNear
// @route   GET /api/hostels/nearby
// @access  Public
export const getNearbyHostels = async (req, res, next) => {
  try {
    const { lat, lng, radius = 5 } = req.query;

    if (!lat || !lng) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both latitude and longitude query parameters',
      });
    }

    const latitude = parseFloat(lat);
    const longitude = parseFloat(lng);
    const radiusKm = parseFloat(radius);
    const maxDistanceMeters = radiusKm * 1000;

    // MongoDB $geoNear aggregation ensures live distance calculation directly from DB engine
    const pipeline = [
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [longitude, latitude],
          },
          distanceField: 'distanceMeters',
          maxDistance: maxDistanceMeters,
          query: { verificationStatus: 'approved' },
          spherical: true,
        },
      },
      {
        $addFields: {
          distanceKm: {
            $round: [{ $divide: ['$distanceMeters', 1000] }, 1],
          },
        },
      },
      {
        $lookup: {
          from: 'rooms',
          localField: '_id',
          foreignField: 'hostelId',
          as: 'rooms',
        },
      },
      {
        $lookup: {
          from: 'users',
          localField: 'ownerId',
          foreignField: '_id',
          pipeline: [{ $project: { name: 1, email: 1, phone: 1 } }],
          as: 'owner',
        },
      },
      {
        $addFields: {
          ownerId: { $arrayElemAt: ['$owner', 0] },
        },
      },
      {
        $project: {
          owner: 0,
        },
      },
      {
        $sort: { distanceKm: 1 },
      },
    ];

    const hostels = await Hostel.aggregate(pipeline);

    res.status(200).json({
      success: true,
      count: hostels.length,
      radiusKm,
      center: { lat: latitude, lng: longitude },
      hostels,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Multi-factor Search for Hostels (budget, distance, gender, roomType, amenities, minRating)
// @route   GET /api/hostels/search
// @access  Public
export const searchHostels = async (req, res, next) => {
  try {
    const {
      collegeId,
      lat,
      lng,
      budget,
      radius = 10,
      gender,
      roomType,
      amenities,
      minRating,
      sort = 'nearest',
      search,
    } = req.query;

    // Determine reference coordinate (from selected College or query lat/lng)
    let refLat = lat ? parseFloat(lat) : 18.5236; // Fergusson default
    let refLng = lng ? parseFloat(lng) : 73.8415;
    let collegeName = 'Fergusson College';

    if (collegeId) {
      const college = await College.findById(collegeId);
      if (college && college.location?.coordinates) {
        refLng = college.location.coordinates[0];
        refLat = college.location.coordinates[1];
        collegeName = college.name;
      }
    }

    // Build filter query for approved hostels
    const matchQuery = { verificationStatus: 'approved' };

    if (gender && gender !== 'all') {
      matchQuery.gender = gender;
    }

    if (search) {
      matchQuery.$or = [
        { name: { $regex: search, $options: 'i' } },
        { area: { $regex: search, $options: 'i' } },
        { address: { $regex: search, $options: 'i' } },
      ];
    }

    if (minRating) {
      matchQuery.rating = { $gte: parseFloat(minRating) };
    }

    if (budget) {
      matchQuery.rentFrom = { $lte: parseFloat(budget) };
    }

    if (amenities) {
      const amenitiesList = Array.isArray(amenities)
        ? amenities
        : amenities.split(',').map((a) => a.trim());
      if (amenitiesList.length > 0) {
        matchQuery.amenities = { $all: amenitiesList };
      }
    }

    // Use $geoNear to calculate distance from reference college
    const maxDistanceMeters = parseFloat(radius) * 1000;

    const pipeline = [
      {
        $geoNear: {
          near: {
            type: 'Point',
            coordinates: [refLng, refLat],
          },
          distanceField: 'distanceMeters',
          maxDistance: maxDistanceMeters,
          query: matchQuery,
          spherical: true,
        },
      },
      {
        $addFields: {
          distanceKm: {
            $round: [{ $divide: ['$distanceMeters', 1000] }, 1],
          },
        },
      },
      {
        $lookup: {
          from: 'rooms',
          localField: '_id',
          foreignField: 'hostelId',
          as: 'rooms',
        },
      },
      {
        $lookup: {
          from: 'users',
          localField: 'ownerId',
          foreignField: '_id',
          pipeline: [{ $project: { name: 1, email: 1, phone: 1 } }],
          as: 'owner',
        },
      },
      {
        $addFields: {
          ownerId: { $arrayElemAt: ['$owner', 0] },
        },
      },
      {
        $project: {
          owner: 0,
        },
      },
    ];

    let hostels = await Hostel.aggregate(pipeline);

    // Filter by roomType if specified
    if (roomType && roomType !== 'all') {
      hostels = hostels.filter((h) =>
        h.rooms && h.rooms.some((r) => r.roomType === roomType)
      );
    }

    // Calculate match recommendations if requested
    const amenitiesPrefList = amenities
      ? Array.isArray(amenities)
        ? amenities
        : amenities.split(',').map((a) => a.trim())
      : [];

    hostels = hostels.map((hostel) => {
      const rec = calculateHostelMatch(hostel, {
        budget: budget ? parseFloat(budget) : undefined,
        collegeLat: refLat,
        collegeLng: refLng,
        collegeName,
        radiusKm: parseFloat(radius),
        preferredAmenities: amenitiesPrefList,
        preferredRoomType: roomType !== 'all' ? roomType : 'double',
      });
      return {
        ...hostel,
        matchScore: rec.matchScore,
        matchReasons: rec.reasons,
      };
    });

    // Sorting
    if (sort === 'lowest_rent') {
      hostels.sort((a, b) => (a.rentFrom || 0) - (b.rentFrom || 0));
    } else if (sort === 'highest_rating') {
      hostels.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    } else if (sort === 'recommended') {
      hostels.sort((a, b) => b.matchScore - a.matchScore);
    } else {
      // Default: nearest
      hostels.sort((a, b) => a.distanceKm - b.distanceKm);
    }

    res.status(200).json({
      success: true,
      count: hostels.length,
      referenceCollege: {
        name: collegeName,
        lat: refLat,
        lng: refLng,
      },
      hostels,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get recommended hostels with explanation
// @route   GET /api/hostels/recommended
// @access  Public
export const getRecommendedHostels = async (req, res, next) => {
  try {
    const {
      budget = 10000,
      collegeId,
      lat,
      lng,
      roomType = 'double',
      amenities,
    } = req.query;

    let refLat = lat ? parseFloat(lat) : 18.5236;
    let refLng = lng ? parseFloat(lng) : 73.8415;
    let collegeName = 'Fergusson College';

    if (collegeId) {
      const college = await College.findById(collegeId);
      if (college && college.location?.coordinates) {
        refLng = college.location.coordinates[0];
        refLat = college.location.coordinates[1];
        collegeName = college.name;
      }
    }

    const preferredAmenities = amenities
      ? Array.isArray(amenities)
        ? amenities
        : amenities.split(',')
      : ['WiFi', 'Mess / Food', 'CCTV'];

    const hostels = await Hostel.find({ verificationStatus: 'approved' })
      .populate('rooms')
      .populate('ownerId', 'name email phone');

    const scoredHostels = hostels.map((hostel) => {
      const hObj = hostel.toObject();
      const rec = calculateHostelMatch(hObj, {
        budget: parseFloat(budget),
        collegeLat: refLat,
        collegeLng: refLng,
        collegeName,
        radiusKm: 6,
        preferredAmenities,
        preferredRoomType: roomType,
      });

      return {
        ...hObj,
        distanceKm: rec.distanceKm,
        matchScore: rec.matchScore,
        matchBreakdown: rec.breakdown,
        matchReasons: rec.reasons,
      };
    });

    // Sort descending by recommendation score
    scoredHostels.sort((a, b) => b.matchScore - a.matchScore);

    res.status(200).json({
      success: true,
      count: scoredHostels.length,
      referenceCollege: {
        name: collegeName,
        lat: refLat,
        lng: refLng,
      },
      hostels: scoredHostels.slice(0, 6), // Top 6 recommendations
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single hostel with rooms and reviews
// @route   GET /api/hostels/:id
// @access  Public
export const getHostelById = async (req, res, next) => {
  try {
    const hostel = await Hostel.findById(req.params.id)
      .populate('rooms')
      .populate('ownerId', 'name email phone avatar');

    if (!hostel) {
      return res.status(404).json({
        success: false,
        message: 'Hostel not found',
      });
    }

    // Default reference: Fergusson College
    const distanceKm = calculateHaversineDistanceKm(
      18.5236,
      73.8415,
      hostel.location.coordinates[1],
      hostel.location.coordinates[0]
    );

    res.status(200).json({
      success: true,
      distanceFromFergussonKm: distanceKm,
      hostel,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create new hostel (Owner only; starts as 'pending')
// @route   POST /api/hostels
// @access  Private (Owner only)
export const createHostel = async (req, res, next) => {
  try {
    const {
      name,
      description,
      address,
      area,
      city = 'Pune',
      gender,
      hostelType = 'hostel',
      phone,
      rentFrom,
      rentTo,
      amenities = [],
      rules = [],
      images = [],
      lat,
      lng,
    } = req.body;

    if (!lat || !lng) {
      return res.status(400).json({
        success: false,
        message: 'Latitude and Longitude are required for geospatial indexing',
      });
    }

    const hostel = await Hostel.create({
      ownerId: req.user.id,
      name,
      description,
      address,
      area,
      city,
      gender,
      hostelType,
      phone: phone || req.user.phone,
      rentFrom: Number(rentFrom),
      rentTo: Number(rentTo),
      amenities,
      rules,
      images: images.length > 0 ? images : [
        'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80',
      ],
      location: {
        type: 'Point',
        coordinates: [parseFloat(lng), parseFloat(lat)], // GeoJSON [lng, lat]
      },
      verificationStatus: 'pending', // Always starts as pending for admin approval
      isDemo: false,
    });

    // Notify admins of new pending hostel
    const admins = await User.find({ role: 'admin' });
    for (const admin of admins) {
      await createNotification({
        userId: admin._id,
        title: 'New Hostel Awaiting Verification',
        message: `Owner ${req.user.name} submitted "${hostel.name}" in ${hostel.area} for review.`,
        link: '/admin/hostels',
        type: 'hostel_approval',
      });
    }

    res.status(201).json({
      success: true,
      message: 'Hostel created successfully and submitted for Admin verification.',
      hostel,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update hostel (Owner only, own hostel)
// @route   PUT /api/hostels/:id
// @access  Private (Owner only)
export const updateHostel = async (req, res, next) => {
  try {
    let hostel = await Hostel.findById(req.params.id);

    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    // Verify ownership
    if (hostel.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this hostel listing',
      });
    }

    const updateData = { ...req.body };

    // If coordinates updated
    if (req.body.lat && req.body.lng) {
      updateData.location = {
        type: 'Point',
        coordinates: [parseFloat(req.body.lng), parseFloat(req.body.lat)],
      };
      delete updateData.lat;
      delete updateData.lng;
    }

    // Protect verificationStatus from being changed directly by owner
    if (req.user.role !== 'admin') {
      delete updateData.verificationStatus;
    }

    hostel = await Hostel.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
    }).populate('rooms');

    res.status(200).json({
      success: true,
      message: 'Hostel updated successfully',
      hostel,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete hostel
// @route   DELETE /api/hostels/:id
// @access  Private (Owner or Admin)
export const deleteHostel = async (req, res, next) => {
  try {
    const hostel = await Hostel.findById(req.params.id);

    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    if (hostel.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this hostel listing',
      });
    }

    // Remove associated rooms
    await Room.deleteMany({ hostelId: hostel._id });
    await hostel.deleteOne();

    res.status(200).json({
      success: true,
      message: 'Hostel and associated rooms deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get hostels owned by logged-in owner
// @route   GET /api/hostels/my/listings
// @access  Private (Owner only)
export const getMyListings = async (req, res, next) => {
  try {
    const hostels = await Hostel.find({ ownerId: req.user.id })
      .populate('rooms')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: hostels.length,
      hostels,
    });
  } catch (error) {
    next(error);
  }
};
