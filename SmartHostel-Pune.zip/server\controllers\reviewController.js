import Review from '../models/Review.js';
import Hostel from '../models/Hostel.js';

// @desc    Get all reviews for a hostel
// @route   GET /api/reviews/hostel/:hostelId
// @access  Public
export const getReviewsByHostel = async (req, res, next) => {
  try {
    const reviews = await Review.find({ hostelId: req.params.hostelId })
      .populate('studentId', 'name avatar')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: reviews.length,
      reviews,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Create a review (Student only, one per student per hostel)
// @route   POST /api/reviews/hostel/:hostelId
// @access  Private (Student only)
export const createReview = async (req, res, next) => {
  try {
    const { rating, cleanlinessRating, foodRating, securityRating, comment } = req.body;
    const hostelId = req.params.hostelId;

    const hostel = await Hostel.findById(hostelId);
    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    // Check if user already reviewed this hostel
    const existingReview = await Review.findOne({
      hostelId,
      studentId: req.user.id,
    });

    if (existingReview) {
      return res.status(400).json({
        success: false,
        message: 'You have already submitted a review for this hostel.',
      });
    }

    const review = await Review.create({
      hostelId,
      studentId: req.user.id,
      rating: Number(rating),
      cleanlinessRating: cleanlinessRating ? Number(cleanlinessRating) : Number(rating),
      foodRating: foodRating ? Number(foodRating) : Number(rating),
      securityRating: securityRating ? Number(securityRating) : Number(rating),
      comment,
    });

    const populatedReview = await Review.findById(review._id).populate('studentId', 'name avatar');

    res.status(201).json({
      success: true,
      message: 'Review submitted successfully',
      review: populatedReview,
    });
  } catch (error) {
    next(error);
  }
};
