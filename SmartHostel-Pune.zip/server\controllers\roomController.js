import Room from '../models/Room.js';
import Hostel from '../models/Hostel.js';

// @desc    Get all rooms for a hostel
// @route   GET /api/rooms/hostel/:hostelId
// @access  Public
export const getRoomsByHostel = async (req, res, next) => {
  try {
    const rooms = await Room.find({ hostelId: req.params.hostelId });
    res.status(200).json({
      success: true,
      count: rooms.length,
      rooms,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Add a room to hostel
// @route   POST /api/rooms/hostel/:hostelId
// @access  Private (Owner only)
export const createRoom = async (req, res, next) => {
  try {
    const hostel = await Hostel.findById(req.params.hostelId);
    if (!hostel) {
      return res.status(404).json({ success: false, message: 'Hostel not found' });
    }

    if (hostel.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to add rooms to this hostel',
      });
    }

    const { roomType, capacity, occupiedBeds = 0, rent, deposit, ac, attachedBathroom } = req.body;

    const room = await Room.create({
      hostelId: req.params.hostelId,
      roomType,
      capacity: Number(capacity),
      occupiedBeds: Number(occupiedBeds),
      rent: Number(rent),
      deposit: Number(deposit),
      ac: Boolean(ac),
      attachedBathroom: Boolean(attachedBathroom),
    });

    // Update rentFrom / rentTo on hostel if necessary
    const allRooms = await Room.find({ hostelId: hostel._id });
    const rents = allRooms.map((r) => r.rent);
    if (rents.length > 0) {
      hostel.rentFrom = Math.min(...rents);
      hostel.rentTo = Math.max(...rents);
      await hostel.save();
    }

    res.status(201).json({
      success: true,
      message: 'Room created successfully',
      room,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update room details (capacity, occupied beds, rent, deposit, etc.)
// @route   PUT /api/rooms/:id
// @access  Private (Owner only)
export const updateRoom = async (req, res, next) => {
  try {
    let room = await Room.findById(req.params.id);
    if (!room) {
      return res.status(404).json({ success: false, message: 'Room not found' });
    }

    const hostel = await Hostel.findById(room.hostelId);
    if (!hostel || (hostel.ownerId.toString() !== req.user.id && req.user.role !== 'admin')) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to modify this room',
      });
    }

    room = await Room.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    // Update rent bounds
    const allRooms = await Room.find({ hostelId: hostel._id });
    const rents = allRooms.map((r) => r.rent);
    if (rents.length > 0) {
      hostel.rentFrom = Math.min(...rents);
      hostel.rentTo = Math.max(...rents);
      await hostel.save();
    }

    res.status(200).json({
      success: true,
      message: 'Room updated successfully',
      room,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a room
// @route   DELETE /api/rooms/:id
// @access  Private (Owner only)
export const deleteRoom = async (req, res, next) => {
  try {
    const room = await Room.findById(req.params.id);
    if (!room) {
      return res.status(404).json({ success: false, message: 'Room not found' });
    }

    const hostel = await Hostel.findById(room.hostelId);
    if (!hostel || (hostel.ownerId.toString() !== req.user.id && req.user.role !== 'admin')) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this room',
      });
    }

    await room.deleteOne();

    // Recalculate rent bounds
    const allRooms = await Room.find({ hostelId: hostel._id });
    if (allRooms.length > 0) {
      const rents = allRooms.map((r) => r.rent);
      hostel.rentFrom = Math.min(...rents);
      hostel.rentTo = Math.max(...rents);
      await hostel.save();
    }

    res.status(200).json({
      success: true,
      message: 'Room removed successfully',
    });
  } catch (error) {
    next(error);
  }
};
