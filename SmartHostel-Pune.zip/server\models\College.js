import mongoose from 'mongoose';

const collegeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please provide college name'],
      trim: true,
    },
    city: {
      type: String,
      default: 'Pune',
      trim: true,
    },
    address: {
      type: String,
      required: [true, 'Please provide college address'],
      trim: true,
    },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
        required: true,
      },
      // Note: GeoJSON stores coordinates as [longitude, latitude]
      coordinates: {
        type: [Number],
        required: true,
      },
    },
  },
  {
    timestamps: true,
  }
);

// 2dsphere index for geospatial queries
collegeSchema.index({ location: '2dsphere' });

const College = mongoose.model('College', collegeSchema);
export default College;
