import mongoose from 'mongoose';

const enquirySchema = new mongoose.Schema(
  {
    hostelId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Hostel',
      required: [true, 'Hostel ID is required'],
    },
    studentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Student ID is required'],
    },
    ownerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Owner ID is required'],
    },
    roomType: {
      type: String,
      default: 'double',
    },
    moveInDate: {
      type: Date,
      required: [true, 'Please provide intended move-in date'],
    },
    durationMonths: {
      type: Number,
      default: 6,
      min: [1, 'Duration must be at least 1 month'],
    },
    message: {
      type: String,
      default: 'I am interested in this hostel and would like to schedule a visit.',
      maxlength: [500, 'Message cannot exceed 500 characters'],
    },
    phone: {
      type: String,
      required: [true, 'Contact phone number is required'],
    },
    status: {
      type: String,
      enum: ['pending', 'contacted', 'accepted', 'rejected', 'closed'],
      default: 'pending',
    },
  },
  {
    timestamps: true,
  }
);

const Enquiry = mongoose.model('Enquiry', enquirySchema);
export default Enquiry;
