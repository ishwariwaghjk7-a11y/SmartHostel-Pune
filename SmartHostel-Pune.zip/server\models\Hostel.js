import mongoose from 'mongoose';

const hostelSchema = new mongoose.Schema(
  {
    ownerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Owner reference is required'],
    },
    name: {
      type: String,
      required: [true, 'Please provide hostel name'],
      trim: true,
      maxlength: [120, 'Name cannot exceed 120 characters'],
    },
    description: {
      type: String,
      required: [true, 'Please provide hostel description'],
    },
    address: {
      type: String,
      required: [true, 'Please provide complete address'],
      trim: true,
    },
    area: {
      type: String,
      required: [true, 'Please specify Pune locality/area'],
      trim: true,
    },
    city: {
      type: String,
      default: 'Pune',
      trim: true,
    },
    gender: {
      type: String,
      enum: {
        values: ['male', 'female', 'coed'],
        message: 'Gender must be male, female, or coed',
      },
      required: [true, 'Please specify gender suitability'],
    },
    hostelType: {
      type: String,
      enum: ['hostel', 'pg', 'apartment'],
      default: 'hostel',
    },
    phone: {
      type: String,
      required: [true, 'Please provide contact phone number'],
    },
    rentFrom: {
      type: Number,
      required: [true, 'Please provide minimum monthly rent'],
      min: [0, 'Rent cannot be negative'],
    },
    rentTo: {
      type: Number,
      required: [true, 'Please provide maximum monthly rent'],
      min: [0, 'Rent cannot be negative'],
    },
    amenities: {
      type: [String],
      default: [],
    },
    rules: {
      type: [String],
      default: [],
    },
    images: {
      type: [String],
      default: [],
    },
    location: {
      type: {
        type: String,
        enum: ['Point'],
        default: 'Point',
        required: true,
      },
      // Note: GeoJSON stores [longitude, latitude]
      coordinates: {
        type: [Number],
        required: [true, 'Coordinates [longitude, latitude] are required'],
      },
    },
    rating: {
      type: Number,
      default: 0,
      min: [0, 'Rating cannot be less than 0'],
      max: [5, 'Rating cannot exceed 5'],
    },
    reviewCount: {
      type: Number,
      default: 0,
      min: [0, 'Review count cannot be negative'],
    },
    verificationStatus: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'suspended'],
      default: 'pending',
    },
    isDemo: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// GeoJSON 2dsphere index for distance calculations and $geoNear queries
hostelSchema.index({ location: '2dsphere' });
hostelSchema.index({ verificationStatus: 1 });
hostelSchema.index({ area: 1 });
hostelSchema.index({ gender: 1 });
hostelSchema.index({ rentFrom: 1, rentTo: 1 });

// Virtual population of rooms
hostelSchema.virtual('rooms', {
  ref: 'Room',
  localField: '_id',
  foreignField: 'hostelId',
  justOne: false,
});

const Hostel = mongoose.model('Hostel', hostelSchema);
export default Hostel;
