import mongoose from 'mongoose';
import Hostel from './Hostel.js';

const reviewSchema = new mongoose.Schema(
  {
    hostelId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Hostel',
      required: [true, 'Hostel ID is required'],
    },
    studentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Student ID is required'],
    },
    rating: {
      type: Number,
      min: [1, 'Rating must be at least 1'],
      max: [5, 'Rating cannot exceed 5'],
      required: [true, 'Overall rating is required'],
    },
    cleanlinessRating: {
      type: Number,
      min: 1,
      max: 5,
      default: 4,
    },
    foodRating: {
      type: Number,
      min: 1,
      max: 5,
      default: 4,
    },
    securityRating: {
      type: Number,
      min: 1,
      max: 5,
      default: 4,
    },
    comment: {
      type: String,
      required: [true, 'Please provide your review feedback'],
      trim: true,
      maxlength: [1000, 'Review cannot exceed 1000 characters'],
    },
  },
  {
    timestamps: true,
  }
);

// Prevent user from submitting more than one review per hostel
reviewSchema.index({ hostelId: 1, studentId: 1 }, { unique: true });

// Static method to calculate average rating and update Hostel document
reviewSchema.statics.calculateAverageRating = async function (hostelId) {
  const stats = await this.aggregate([
    {
      $match: { hostelId: new mongoose.Types.ObjectId(hostelId) },
    },
    {
      $group: {
        _id: '$hostelId',
        averageRating: { $avg: '$rating' },
        reviewCount: { $sum: 1 },
      },
    },
  ]);

  try {
    if (stats.length > 0) {
      await Hostel.findByIdAndUpdate(hostelId, {
        rating: Math.round(stats[0].averageRating * 10) / 10,
        reviewCount: stats[0].reviewCount,
      });
    } else {
      await Hostel.findByIdAndUpdate(hostelId, {
        rating: 0,
        reviewCount: 0,
      });
    }
  } catch (err) {
    console.error(`Error updating hostel ratings: ${err.message}`);
  }
};

// Recalculate average rating after review is saved or removed
reviewSchema.post('save', async function () {
  await this.constructor.calculateAverageRating(this.hostelId);
});

reviewSchema.post('findOneAndDelete', async function (doc) {
  if (doc) {
    await doc.constructor.calculateAverageRating(doc.hostelId);
  }
});

const Review = mongoose.model('Review', reviewSchema);
export default Review;
