import mongoose from 'mongoose';

const roomSchema = new mongoose.Schema(
  {
    hostelId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Hostel',
      required: [true, 'Hostel reference is required'],
    },
    roomType: {
      type: String,
      enum: {
        values: ['single', 'double', 'triple', 'four'],
        message: '{VALUE} is not a supported room type',
      },
      required: [true, 'Please specify room type'],
    },
    capacity: {
      type: Number,
      required: [true, 'Please specify room capacity'],
      min: [1, 'Capacity must be at least 1 bed'],
    },
    occupiedBeds: {
      type: Number,
      default: 0,
      min: [0, 'Occupied beds cannot be negative'],
    },
    rent: {
      type: Number,
      required: [true, 'Please specify monthly rent per bed/room'],
      min: [0, 'Rent cannot be negative'],
    },
    deposit: {
      type: Number,
      required: [true, 'Please specify security deposit amount'],
      min: [0, 'Deposit cannot be negative'],
    },
    ac: {
      type: Boolean,
      default: false,
    },
    attachedBathroom: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Virtual field: availableBeds = capacity - occupiedBeds
roomSchema.virtual('availableBeds').get(function () {
  return Math.max(0, this.capacity - (this.occupiedBeds || 0));
});

const Room = mongoose.model('Room', roomSchema);
export default Room;
