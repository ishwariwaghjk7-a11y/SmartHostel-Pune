import express from 'express';
import {
  getAllUsers,
  getAllHostels,
  updateHostelStatus,
  getAnalytics,
} from '../controllers/adminController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.use(protect);
router.use(authorize('admin'));

router.get('/users', getAllUsers);
router.get('/hostels', getAllHostels);
router.patch('/hostels/:id/status', updateHostelStatus);
router.get('/analytics', getAnalytics);

export default router;
