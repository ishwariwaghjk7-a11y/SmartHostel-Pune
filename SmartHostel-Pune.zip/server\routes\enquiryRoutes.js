import express from 'express';
import {
  createEnquiry,
  getStudentEnquiries,
  getOwnerEnquiries,
  updateEnquiryStatus,
} from '../controllers/enquiryController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.use(protect);

router.post('/', authorize('student'), createEnquiry);
router.get('/student', authorize('student'), getStudentEnquiries);
router.get('/owner', authorize('owner'), getOwnerEnquiries);
router.patch('/:id/status', authorize('owner', 'admin'), updateEnquiryStatus);

export default router;
