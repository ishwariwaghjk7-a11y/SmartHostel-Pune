import express from 'express';
import {
  getFavorites,
  toggleFavorite,
  removeFavorite,
} from '../controllers/favoriteController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.use(protect);
router.use(authorize('student'));

router.get('/', getFavorites);
router.post('/:hostelId', toggleFavorite);
router.delete('/:hostelId', removeFavorite);

export default router;
