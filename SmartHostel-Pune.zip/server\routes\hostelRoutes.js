import express from 'express';
import {
  getHostels,
  getNearbyHostels,
  searchHostels,
  getRecommendedHostels,
  getHostelById,
  createHostel,
  updateHostel,
  deleteHostel,
  getMyListings,
} from '../controllers/hostelController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

// Public routes
router.get('/', getHostels);
router.get('/nearby', getNearbyHostels);
router.get('/search', searchHostels);
router.get('/recommended', getRecommendedHostels);

// Owner-specific listings
router.get('/my/listings', protect, authorize('owner'), getMyListings);

// Hostel by ID
router.get('/:id', getHostelById);

// Owner protected CRUD
router.post('/', protect, authorize('owner'), createHostel);
router.put('/:id', protect, authorize('owner', 'admin'), updateHostel);
router.delete('/:id', protect, authorize('owner', 'admin'), deleteHostel);

export default router;
