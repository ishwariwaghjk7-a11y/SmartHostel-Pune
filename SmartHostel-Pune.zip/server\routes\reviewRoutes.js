import express from 'express';
import { getReviewsByHostel, createReview } from '../controllers/reviewController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/hostel/:hostelId', getReviewsByHostel);
router.post('/hostel/:hostelId', protect, authorize('student'), createReview);

export default router;
