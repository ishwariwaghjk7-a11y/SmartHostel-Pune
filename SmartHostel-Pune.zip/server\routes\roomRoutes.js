import express from 'express';
import {
  getRoomsByHostel,
  createRoom,
  updateRoom,
  deleteRoom,
} from '../controllers/roomController.js';
import { protect } from '../middleware/authMiddleware.js';
import { authorize } from '../middleware/roleMiddleware.js';

const router = express.Router();

router.get('/hostel/:hostelId', getRoomsByHostel);
router.post('/hostel/:hostelId', protect, authorize('owner'), createRoom);
router.put('/:id', protect, authorize('owner', 'admin'), updateRoom);
router.delete('/:id', protect, authorize('owner', 'admin'), deleteRoom);

export default router;
