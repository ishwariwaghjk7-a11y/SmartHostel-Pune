import mongoose from 'mongoose';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';

import User from '../models/User.js';
import College from '../models/College.js';
import Hostel from '../models/Hostel.js';
import Room from '../models/Room.js';
import Review from '../models/Review.js';
import Enquiry from '../models/Enquiry.js';
import Favorite from '../models/Favorite.js';
import Notification from '../models/Notification.js';

dotenv.config();

const seedDatabase = async () => {
  try {
    if (!process.env.MONGO_URI || process.env.MONGO_URI.includes('<username>')) {
      console.error('❌ Error: Valid MONGO_URI is missing in server/.env');
      console.error('Please update server/.env with your MongoDB Atlas connection string before seeding.');
      process.exit(1);
    }

    console.log('🔄 Connecting to MongoDB for seeding...');
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB successfully.');

    // 1. Clear existing collections
    console.log('🧹 Clearing existing collections...');
    await Promise.all([
      User.deleteMany({}),
      College.deleteMany({}),
      Hostel.deleteMany({}),
      Room.deleteMany({}),
      Review.deleteMany({}),
      Enquiry.deleteMany({}),
      Favorite.deleteMany({}),
      Notification.deleteMany({}),
    ]);

    // 2. Create Default College: Fergusson College
    console.log('🏛️ Creating Fergusson College...');
    const fergussonCollege = await College.create({
      name: 'Fergusson College',
      city: 'Pune',
      address: 'F.C. Road, Deccan Gymkhana, Pune 411004',
      location: {
        type: 'Point',
        coordinates: [73.8415, 18.5236], // [longitude, latitude]
      },
    });

    // 3. Create Users (Admin, 2 Owners, 3 Students)
    console.log('👥 Creating users (Admin, Owners, Students)...');
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = async (pwd) => await bcrypt.hash(pwd, salt);

    const admin = await User.create({
      name: 'Super Admin',
      email: 'admin@smarthostel.com',
      password: 'Admin@123',
      role: 'admin',
      phone: '+91 98230 11223',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    });

    const owner1 = await User.create({
      name: 'Rajesh Kulkarni',
      email: 'owner1@smarthostel.com',
      password: 'Owner@123',
      role: 'owner',
      phone: '+91 98501 22334',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    });

    const owner2 = await User.create({
      name: 'Sunita Deshpande',
      email: 'owner2@smarthostel.com',
      password: 'Owner@123',
      role: 'owner',
      phone: '+91 98812 33445',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    });

    const student1 = await User.create({
      name: 'Rohan Deshmukh',
      email: 'student1@smarthostel.com',
      password: 'Student@123',
      role: 'student',
      phone: '+91 99221 44556',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=200&q=80',
    });

    const student2 = await User.create({
      name: 'Ananya Patil',
      email: 'student2@smarthostel.com',
      password: 'Student@123',
      role: 'student',
      phone: '+91 97632 55667',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
    });

    const student3 = await User.create({
      name: 'Siddharth Joshi',
      email: 'student3@smarthostel.com',
      password: 'Student@123',
      role: 'student',
      phone: '+91 96573 66778',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    });

    // 4. Create 8 Hostels around Pune (6 Approved, 1 Pending, 1 Rejected)
    console.log('🏢 Creating 8 Pune hostels with realistic coordinates...');
    const hostelData = [
      {
        ownerId: owner1._id,
        name: 'Deccan Student Homes – Demo Listing',
        description: 'Prime accommodation in Deccan Gymkhana right next to Goodluck Cafe and walking distance to Fergusson College. Peaceful study environment with high-speed fiber internet and hygienic meals.',
        address: 'Lane 4, Prabhat Road, Near Goodluck Cafe, Deccan Gymkhana, Pune 411004',
        area: 'Deccan Gymkhana',
        city: 'Pune',
        gender: 'male',
        hostelType: 'hostel',
        phone: '+91 98501 22334',
        rentFrom: 7500,
        rentTo: 14000,
        amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Laundry', 'Power Backup', 'Study Room', 'Hot Water'],
        rules: ['Curfew 10:30 PM', 'No smoking or alcohol on premises', 'Visitors permitted in reception lounge only'],
        images: [
          'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8410, 18.5198], // ~0.4 km from FC
        },
        rating: 4.6,
        reviewCount: 3,
        verificationStatus: 'approved',
        isDemo: true,
      },
      {
        ownerId: owner1._id,
        name: 'FC Road Girls Luxury PG – Demo Listing',
        description: 'Secure, modern, and beautifully maintained girl student hostel right in the heart of F.C. Road. Biometric security, 24/7 warden, attached washrooms, and curated nutritious meals.',
        address: 'Opp. Starbucks, F.C. Road, Shivajinagar, Pune 411004',
        area: 'F.C. Road',
        city: 'Pune',
        gender: 'female',
        hostelType: 'pg',
        phone: '+91 98501 22334',
        rentFrom: 9000,
        rentTo: 18000,
        amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Laundry', 'Power Backup', 'Gym', 'Biometric Entry', 'Hot Water'],
        rules: ['Curfew 10:00 PM', 'Biometric check-in mandatory', 'Female visitors only allowed in rooms'],
        images: [
          'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8422, 18.5270], // ~0.4 km from FC
        },
        rating: 4.8,
        reviewCount: 3,
        verificationStatus: 'approved',
        isDemo: true,
      },
      {
        ownerId: owner1._id,
        name: 'Fergusson Scholars Residence – Demo Listing',
        description: 'Just 150 meters from Fergusson College main gate! Designed specifically for university students with dedicated quiet study spaces, AC rooms, high-speed WiFi, and wholesome Indian buffet.',
        address: 'Wadeshwar Lane, F.C. Road, Deccan, Pune 411004',
        area: 'F.C. Road',
        city: 'Pune',
        gender: 'coed',
        hostelType: 'hostel',
        phone: '+91 98501 22334',
        rentFrom: 8500,
        rentTo: 16500,
        amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Power Backup', 'Study Room', 'Hot Water'],
        rules: ['Separate wings for boys and girls', 'Quiet hours after 11:00 PM', 'ID card compulsory at gate'],
        images: [
          'https://images.unsplash.com/photo-1540518614846-7ede433c4ef7?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8405, 18.5245], // ~0.15 km from FC
        },
        rating: 4.5,
        reviewCount: 2,
        verificationStatus: 'approved',
        isDemo: true,
      },
      {
        ownerId: owner1._id,
        name: 'Shivajinagar Co-Living Space – Demo Listing',
        description: 'Vibrant modern co-living community close to Pune University road and Shivajinagar Railway Station. Includes recreational gaming zone, shared kitchen, weekly housekeeping, and gym.',
        address: 'Near Simla Office Chowk, Shivajinagar, Pune 411005',
        area: 'Shivajinagar',
        city: 'Pune',
        gender: 'coed',
        hostelType: 'apartment',
        phone: '+91 98501 22334',
        rentFrom: 11000,
        rentTo: 20000,
        amenities: ['WiFi', 'CCTV', 'Laundry', 'Power Backup', 'Gym', 'Hot Water', 'Study Room'],
        rules: ['No loud music past midnight', 'Maintain cleanliness in common kitchen', 'Smoking outside only'],
        images: [
          'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8490, 18.5312], // ~1.2 km from FC
        },
        rating: 4.3,
        reviewCount: 1,
        verificationStatus: 'approved',
        isDemo: true,
      },
      {
        ownerId: owner2._id,
        name: 'Law College Road Elite Hostel – Demo Listing',
        description: 'Situated in the quiet, prestigious tree-lined avenues of Law College Road. Excellent access to Fergusson, BMCC, and ILS Law College. Fully furnished rooms with balcony views.',
        address: 'Bhandarkar Institute Road, Near ILS, Pune 411004',
        area: 'Law College Road',
        city: 'Pune',
        gender: 'female',
        hostelType: 'hostel',
        phone: '+91 98812 33445',
        rentFrom: 9500,
        rentTo: 17000,
        amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Power Backup', 'Study Room', 'Hot Water'],
        rules: ['Curfew 10:00 PM', 'Visitors allowed during day in visitors room', 'No loud instruments'],
        images: [
          'https://images.unsplash.com/photo-1598928506311-c55ded91a20c?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8320, 18.5150], // ~1.4 km from FC
        },
        rating: 4.7,
        reviewCount: 2,
        verificationStatus: 'approved',
        isDemo: true,
      },
      {
        ownerId: owner2._id,
        name: 'SB Road Premium Boys Hostel – Demo Listing',
        description: 'Spacious accommodation on Senapati Bapat Road. Proximity to Pune University, ICC Trade Towers, and Deccan. Provides home-cooked vegetarian meals twice a day.',
        address: 'Behind JW Marriott, Senapati Bapat Road, Pune 411016',
        area: 'Senapati Bapat Road',
        city: 'Pune',
        gender: 'male',
        hostelType: 'hostel',
        phone: '+91 98812 33445',
        rentFrom: 6500,
        rentTo: 12000,
        amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Laundry', 'Hot Water'],
        rules: ['Curfew 11:00 PM', 'No parking of unauthorized vehicles', 'Strict anti-ragging policy'],
        images: [
          'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8310, 18.5350], // ~1.7 km from FC
        },
        rating: 4.1,
        reviewCount: 1,
        verificationStatus: 'approved',
        isDemo: true,
      },
      {
        ownerId: owner2._id,
        name: 'Erandwane Modern PG – Demo Listing',
        description: 'Newly constructed hostel building in Erandwane near Garware College metro station. Features state-of-the-art furnishings, modern elevator, and spacious study desks.',
        address: 'Near Garware College, Karve Road, Erandwane, Pune 411004',
        area: 'Erandwane',
        city: 'Pune',
        gender: 'coed',
        hostelType: 'pg',
        phone: '+91 98812 33445',
        rentFrom: 8000,
        rentTo: 15000,
        amenities: ['WiFi', 'Mess / Food', 'CCTV', 'Power Backup', 'Gym', 'Hot Water'],
        rules: ['ID verification mandatory', 'Curfew 10:30 PM'],
        images: [
          'https://images.unsplash.com/photo-1501183638710-841dd1904471?auto=format&fit=crop&w=800&q=80',
          'https://images.unsplash.com/photo-1502005229762-ee152da915ba?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8350, 18.5080], // ~1.9 km from FC
        },
        rating: 0,
        reviewCount: 0,
        verificationStatus: 'pending', // PENDING for Admin moderation demo!
        isDemo: true,
      },
      {
        ownerId: owner2._id,
        name: 'Kothrud Budget Stay – Demo Listing',
        description: 'Economical student living close to MIT WPU and Vanaz Metro. Ideal for students on a strict budget who want clean rooms with basic amenities.',
        address: 'Paud Road, Near Vanaz Corner, Kothrud, Pune 411038',
        area: 'Kothrud',
        city: 'Pune',
        gender: 'male',
        hostelType: 'hostel',
        phone: '+91 98812 33445',
        rentFrom: 4500,
        rentTo: 8500,
        amenities: ['WiFi', 'Hot Water', 'CCTV'],
        rules: ['Curfew 10:30 PM', 'No visitors allowed overnight'],
        images: [
          'https://images.unsplash.com/photo-1541123437800-1bb1317badc2?auto=format&fit=crop&w=800&q=80',
        ],
        location: {
          type: 'Point',
          coordinates: [73.8150, 18.5020], // ~3.5 km from FC
        },
        rating: 3.2,
        reviewCount: 1,
        verificationStatus: 'rejected', // REJECTED for Admin moderation demo!
        isDemo: true,
      },
    ];

    const createdHostels = await Hostel.create(hostelData);

    // 5. Create 2-3 Rooms per hostel
    console.log('🛏️ Creating room inventory with capacity and bed tracking...');
    const roomDocs = [];
    for (const hostel of createdHostels) {
      if (hostel.rentFrom <= 5000) {
        // Budget hostel: Triple and Four sharing
        roomDocs.push(
          {
            hostelId: hostel._id,
            roomType: 'triple',
            capacity: 3,
            occupiedBeds: 2,
            rent: hostel.rentFrom,
            deposit: hostel.rentFrom * 2,
            ac: false,
            attachedBathroom: true,
          },
          {
            hostelId: hostel._id,
            roomType: 'four',
            capacity: 4,
            occupiedBeds: 3,
            rent: 4500,
            deposit: 9000,
            ac: false,
            attachedBathroom: false,
          }
        );
      } else {
        // Standard & Luxury hostels: Single, Double, Triple
        roomDocs.push(
          {
            hostelId: hostel._id,
            roomType: 'single',
            capacity: 1,
            occupiedBeds: 0,
            rent: hostel.rentTo,
            deposit: hostel.rentTo * 2,
            ac: true,
            attachedBathroom: true,
          },
          {
            hostelId: hostel._id,
            roomType: 'double',
            capacity: 2,
            occupiedBeds: 1,
            rent: Math.round((hostel.rentFrom + hostel.rentTo) / 2),
            deposit: Math.round((hostel.rentFrom + hostel.rentTo)),
            ac: false,
            attachedBathroom: true,
          },
          {
            hostelId: hostel._id,
            roomType: 'triple',
            capacity: 3,
            occupiedBeds: 1,
            rent: hostel.rentFrom,
            deposit: hostel.rentFrom * 2,
            ac: false,
            attachedBathroom: false,
          }
        );
      }
    }
    await Room.create(roomDocs);

    // 6. Create ~10 Reviews with subratings
    console.log('⭐ Creating student reviews...');
    const reviews = [
      {
        hostelId: createdHostels[0]._id, // Deccan Student Homes
        studentId: student1._id,
        rating: 5,
        cleanlinessRating: 5,
        foodRating: 4,
        securityRating: 5,
        comment: 'Fantastic location! Walking to Fergusson College takes under 5 minutes. The mess food is genuinely homelike and Wi-Fi speed is excellent for study and assignments.',
      },
      {
        hostelId: createdHostels[0]._id,
        studentId: student2._id,
        rating: 4,
        cleanlinessRating: 4,
        foodRating: 4,
        securityRating: 5,
        comment: 'Very safe premises, helpful warden, and laundry service is very convenient during exam season.',
      },
      {
        hostelId: createdHostels[0]._id,
        studentId: student3._id,
        rating: 5,
        cleanlinessRating: 5,
        foodRating: 5,
        securityRating: 5,
        comment: 'Best student accommodation in Deccan. Good study atmosphere and zero disturbance.',
      },
      {
        hostelId: createdHostels[1]._id, // FC Road Girls Luxury PG
        studentId: student2._id,
        rating: 5,
        cleanlinessRating: 5,
        foodRating: 5,
        securityRating: 5,
        comment: 'Extremely safe with biometric entry. Rooms are spacious and modern. Right on FC Road so everything is nearby!',
      },
      {
        hostelId: createdHostels[1]._id,
        studentId: student1._id,
        rating: 4,
        cleanlinessRating: 5,
        foodRating: 4,
        securityRating: 5,
        comment: 'My sister stays here, top-notch security and very hygienic dining hall.',
      },
      {
        hostelId: createdHostels[2]._id, // Fergusson Scholars Residence
        studentId: student3._id,
        rating: 5,
        cleanlinessRating: 4,
        foodRating: 5,
        securityRating: 5,
        comment: 'Literally opposite FC gate! Saves so much commute time and energy. Power backup works reliably during monsoons.',
      },
      {
        hostelId: createdHostels[2]._id,
        studentId: student1._id,
        rating: 4,
        cleanlinessRating: 4,
        foodRating: 4,
        securityRating: 4,
        comment: 'Great peer circle and quiet library room. Highly recommended for Fergusson students.',
      },
      {
        hostelId: createdHostels[3]._id, // Shivajinagar Co-Living
        studentId: student3._id,
        rating: 4,
        cleanlinessRating: 4,
        foodRating: 4,
        securityRating: 4,
        comment: 'Nice co-living vibe and good recreation space. Close to Shivajinagar station.',
      },
      {
        hostelId: createdHostels[4]._id, // Law College Road
        studentId: student2._id,
        rating: 5,
        cleanlinessRating: 5,
        foodRating: 4,
        securityRating: 5,
        comment: 'Quiet, green locality on Law College Road. Very peaceful for evening study sessions.',
      },
      {
        hostelId: createdHostels[5]._id, // SB Road Premium Boys
        studentId: student1._id,
        rating: 4,
        cleanlinessRating: 4,
        foodRating: 4,
        securityRating: 4,
        comment: 'Well maintained building, gym equipment is in good shape, decent food.',
      },
    ];

    for (const r of reviews) {
      await Review.create(r);
    }

    // 7. Create 4 Enquiries
    console.log('📨 Creating demo enquiries...');
    await Enquiry.create([
      {
        hostelId: createdHostels[0]._id,
        studentId: student1._id,
        ownerId: owner1._id,
        roomType: 'double',
        moveInDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        durationMonths: 10,
        message: 'Hello, I am a 2nd year BSc student at Fergusson College looking for a double sharing room starting next week.',
        phone: student1.phone,
        status: 'accepted',
      },
      {
        hostelId: createdHostels[1]._id,
        studentId: student2._id,
        ownerId: owner1._id,
        roomType: 'single',
        moveInDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000),
        durationMonths: 12,
        message: 'Interested in AC single room. Would like to schedule an in-person visit this Saturday.',
        phone: student2.phone,
        status: 'contacted',
      },
      {
        hostelId: createdHostels[4]._id,
        studentId: student2._id,
        ownerId: owner2._id,
        roomType: 'double',
        moveInDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
        durationMonths: 6,
        message: 'Hi, are meals included on weekends as well?',
        phone: student2.phone,
        status: 'pending',
      },
      {
        hostelId: createdHostels[2]._id,
        studentId: student3._id,
        ownerId: owner1._id,
        roomType: 'triple',
        moveInDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        durationMonths: 10,
        message: 'Looking for immediate occupancy in triple sharing bed.',
        phone: student3.phone,
        status: 'pending',
      },
    ]);

    // 8. Create Favorites for students
    console.log('❤️ Creating favorites...');
    await Favorite.create([
      { studentId: student1._id, hostelId: createdHostels[0]._id },
      { studentId: student1._id, hostelId: createdHostels[2]._id },
      { studentId: student2._id, hostelId: createdHostels[1]._id },
      { studentId: student2._id, hostelId: createdHostels[4]._id },
    ]);

    // 9. Create Notifications
    console.log('🔔 Creating initial notifications...');
    await Notification.create([
      {
        userId: student1._id,
        title: 'Enquiry Accepted!',
        message: 'Good news! Your enquiry for Deccan Student Homes has been accepted by owner Rajesh Kulkarni.',
        link: '/enquiries',
        type: 'status_change',
        read: false,
      },
      {
        userId: owner1._id,
        title: 'New Student Enquiry',
        message: 'Rohan Deshmukh enquired about Deccan Student Homes (double room).',
        link: '/dashboard/owner',
        type: 'enquiry',
        read: true,
      },
      {
        userId: admin._id,
        title: 'Hostel Awaiting Verification',
        message: 'Erandwane Modern PG was submitted by Sunita Deshpande and is pending your review.',
        link: '/admin/hostels',
        type: 'hostel_approval',
        read: false,
      },
    ]);

    console.log('\n========================================================');
    console.log('🎉 SMART HOSTEL DATABASE SEEDED SUCCESSFULLY!');
    console.log('========================================================');
    console.log('Default College: Fergusson College, F.C. Road, Pune (18.5236, 73.8415)');
    console.log('Hostels Seeded: 8 (6 Approved, 1 Pending, 1 Rejected)');
    console.log('\nDEMO LOGIN CREDENTIALS:');
    console.log('--------------------------------------------------------');
    console.log('👑 ADMIN:');
    console.log('   Email:    admin@smarthostel.com');
    console.log('   Password: Admin@123');
    console.log('\n🏠 OWNER 1:');
    console.log('   Email:    owner1@smarthostel.com');
    console.log('   Password: Owner@123');
    console.log('\n🏠 OWNER 2:');
    console.log('   Email:    owner2@smarthostel.com');
    console.log('   Password: Owner@123');
    console.log('\n🎓 STUDENT 1:');
    console.log('   Email:    student1@smarthostel.com');
    console.log('   Password: Student@123');
    console.log('\n🎓 STUDENT 2:');
    console.log('   Email:    student2@smarthostel.com');
    console.log('   Password: Student@123');
    console.log('========================================================\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding Error:', error);
    process.exit(1);
  }
};

seedDatabase();
