import Notification from '../models/Notification.js';

export const createNotification = async ({
  userId,
  title,
  message,
  link = '',
  type = 'system',
}) => {
  try {
    const notification = await Notification.create({
      userId,
      title,
      message,
      link,
      type,
    });
    return notification;
  } catch (error) {
    console.error(`Error creating notification for user ${userId}:`, error.message);
    return null;
  }
};
