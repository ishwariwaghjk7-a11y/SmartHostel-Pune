/**
 * SmartHostel Recommendation Engine
 * =================================
 * Designed for viva presentation and academic transparency.
 * 
 * Formula:
 * matchScore = (budgetScore * 0.30) + 
 *              (distanceScore * 0.25) + 
 *              (amenitiesScore * 0.20) + 
 *              (ratingScore * 0.15) + 
 *              (roomPreferenceScore * 0.10)
 * 
 * Each individual factor is normalized to a 0 - 100 scale:
 * 1. Budget Score (30%):
 *    - 100% match if hostel starting rent <= student's target budget.
 *    - Graceful linear decay if up to 25% above budget.
 *    - 0% match if > 25% over budget.
 * 
 * 2. Distance Score (25%):
 *    - 100% match if within 1.0 km of reference college (e.g., Fergusson College).
 *    - Decays proportionally up to max search radius.
 * 
 * 3. Amenities Score (20%):
 *    - Proportion of user's requested amenities available in the hostel.
 * 
 * 4. Rating Score (15%):
 *    - Normalized from 5-star scale: (hostel.rating / 5) * 100.
 * 
 * 5. Room Preference Score (10%):
 *    - Evaluates whether the requested room sharing type has available beds.
 */

// Helper to calculate distance in kilometers between two GPS coordinates (Haversine formula)
export const calculateHaversineDistanceKm = (lat1, lon1, lat2, lon2) => {
  const R = 6371; // Earth's mean radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10; // Rounded to 1 decimal place
};

/**
 * Calculates match score and generates human-readable reasons for a hostel
 * @param {Object} hostel - Hostel document with populated rooms
 * @param {Object} preferences - Student preferences: { budget, collegeLat, collegeLng, collegeName, radiusKm, amenities, roomType }
 * @returns {Object} { matchScore: Number, reasons: Array<String>, distanceKm: Number }
 */
export const calculateHostelMatch = (hostel, preferences = {}) => {
  const {
    budget = 12000,
    collegeLat = 18.5236, // Default: Fergusson College lat
    collegeLng = 73.8415, // Default: Fergusson College lng
    collegeName = 'Fergusson College',
    radiusKm = 5,
    preferredAmenities = ['WiFi', 'Mess / Food', 'CCTV'],
    preferredRoomType = 'double',
  } = preferences;

  const reasons = [];

  // 1. Distance Calculation & Scoring (Weight: 25%)
  const hostelLng = hostel.location?.coordinates?.[0] || 73.84;
  const hostelLat = hostel.location?.coordinates?.[1] || 18.52;
  const distanceKm = calculateHaversineDistanceKm(collegeLat, collegeLng, hostelLat, hostelLng);

  let distanceScore = 0;
  if (distanceKm <= 1.0) {
    distanceScore = 100;
    reasons.push(`Just ${distanceKm} km from ${collegeName} (quick walking distance)`);
  } else if (distanceKm <= radiusKm) {
    distanceScore = Math.max(0, 100 - ((distanceKm - 1.0) / (radiusKm - 1.0)) * 70);
    reasons.push(`${distanceKm} km from ${collegeName}`);
  } else {
    distanceScore = Math.max(10, 100 - (distanceKm / radiusKm) * 80);
  }

  // 2. Budget Scoring (Weight: 30%)
  const minRent = hostel.rentFrom || 6000;
  let budgetScore = 0;
  if (minRent <= budget) {
    budgetScore = 100;
    reasons.push(`Fits your budget (₹${minRent.toLocaleString('en-IN')}/mo vs target ₹${Number(budget).toLocaleString('en-IN')})`);
  } else if (minRent <= budget * 1.25) {
    // Within 25% over budget
    const overBudgetPct = (minRent - budget) / (budget * 0.25);
    budgetScore = Math.max(20, Math.round(100 - overBudgetPct * 70));
    reasons.push(`Slightly above target budget (₹${minRent.toLocaleString('en-IN')}/mo)`);
  } else {
    budgetScore = 10;
  }

  // 3. Amenities Scoring (Weight: 20%)
  let amenitiesScore = 70; // default baseline if user selected no preference
  if (preferredAmenities && preferredAmenities.length > 0) {
    const hostelAmenities = hostel.amenities || [];
    const matchedAmenities = preferredAmenities.filter((a) =>
      hostelAmenities.some((ha) => ha.toLowerCase() === a.toLowerCase())
    );
    amenitiesScore = Math.round((matchedAmenities.length / preferredAmenities.length) * 100);
    if (matchedAmenities.length > 0) {
      reasons.push(`Features your requested amenities: ${matchedAmenities.slice(0, 3).join(', ')}`);
    }
  }

  // 4. Rating Scoring (Weight: 15%)
  const rating = hostel.rating || 4.0;
  const ratingScore = Math.min(100, Math.round((rating / 5) * 100));
  if (rating >= 4.2) {
    reasons.push(`Highly rated by students (${rating}★ from ${hostel.reviewCount || 1} reviews)`);
  } else if (rating >= 3.5) {
    reasons.push(`Positive student rating (${rating}★)`);
  }

  // 5. Room Preference Scoring (Weight: 10%)
  let roomPreferenceScore = 50;
  if (hostel.rooms && hostel.rooms.length > 0) {
    const matchingRoom = hostel.rooms.find(
      (r) => r.roomType?.toLowerCase() === preferredRoomType?.toLowerCase()
    );
    if (matchingRoom) {
      const available = matchingRoom.availableBeds ?? (matchingRoom.capacity - matchingRoom.occupiedBeds);
      if (available > 0) {
        roomPreferenceScore = 100;
        reasons.push(`${available} bed(s) ready in preferred ${preferredRoomType} room`);
      } else {
        roomPreferenceScore = 60;
        reasons.push(`Offers ${preferredRoomType} rooms (currently waiting list)`);
      }
    } else {
      roomPreferenceScore = 40;
    }
  } else {
    roomPreferenceScore = 70;
  }

  // Final Weighted Match Score Calculation
  const matchScore = Math.round(
    budgetScore * 0.30 +
    distanceScore * 0.25 +
    amenitiesScore * 0.20 +
    ratingScore * 0.15 +
    roomPreferenceScore * 0.10
  );

  return {
    matchScore: Math.min(99, Math.max(45, matchScore)), // normalized between 45% - 99% for realistic student display
    breakdown: {
      budgetScore,
      distanceScore,
      amenitiesScore,
      ratingScore,
      roomPreferenceScore,
    },
    reasons: reasons.slice(0, 4), // Top 3-4 clearest reasons for UI display
    distanceKm,
  };
};
